// ════════════════════════════════════════════════════════════════
//  evidence_receiver.js — Phase 6, Piece B (command-center side)
//
//  Receives the evidence packages the Jetson rsyncs to this PC, RE-VERIFIES
//  their SHA-256 seals, and exposes them to the dashboard. This is the
//  receiving end of the integrity chain the edge produces: the edge hashes
//  every file and writes file_hashes.json; here we recompute and compare, so
//  the command center can prove a clip/package is intact and untampered.
//
//  Adds these endpoints under /api/evidence (all additive — nothing existing
//  is changed):
//    GET  /api/evidence                 → list packages + verification status
//    GET  /api/evidence/:eventId        → one package's manifest + verify report
//    GET  /api/evidence/:eventId/verify → force a fresh re-verification
//    GET  /api/evidence/:eventId/clip   → stream the package's clip.mp4
//    GET  /api/evidence/stats           → counts by verification status
//
//  Mount in server/index.js exactly like report_llm:
//      const evidence = require('./evidence_receiver');
//      app.use('/api', evidence.router);
//      evidence.startWatching(broadcastToWS);   // optional live push
//
//  Config (env):
//    EVIDENCE_DIR   folder the Jetson rsyncs packages into.
//                   Default: /reports/../robot_data, override to your real path
//                   (e.g. the rsync target on this PC: /home/ai1/robot_data).
// ════════════════════════════════════════════════════════════════
'use strict';

const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const router = express.Router();

const EVIDENCE_DIR = process.env.EVIDENCE_DIR || '/evidence';

// ── helpers ───────────────────────────────────────────────────────
function sha256File(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('error', reject);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('end', () => resolve('sha256:' + hash.digest('hex')));
  });
}

function isPackageDir(dir) {
  // a package has at minimum a manifest + hashes
  try {
    return fs.existsSync(path.join(dir, 'upload_manifest.json')) &&
           fs.existsSync(path.join(dir, 'file_hashes.json'));
  } catch { return false; }
}

function listPackageDirs() {
  let entries;
  try {
    entries = fs.readdirSync(EVIDENCE_DIR, { withFileTypes: true });
  } catch (e) {
    return { dir: EVIDENCE_DIR, error: 'Evidence folder not found: ' + EVIDENCE_DIR, packages: [] };
  }
  const packages = entries
    .filter((d) => d.isDirectory())
    .map((d) => path.join(EVIDENCE_DIR, d.name))
    .filter(isPackageDir);
  return { dir: EVIDENCE_DIR, packages };
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

// ── core: re-verify a package against its recorded hashes ──────────
async function verifyPackage(pkgDir) {
  const hashesPath = path.join(pkgDir, 'file_hashes.json');
  if (!fs.existsSync(hashesPath)) {
    return { status: 'missing_hashes', checked: 0, mismatches: [] };
  }
  let recorded;
  try {
    recorded = readJson(hashesPath);
  } catch (e) {
    return { status: 'unreadable_hashes', checked: 0, mismatches: [], error: e.message };
  }

  const mismatches = [];
  let checked = 0;
  for (const [name, recordedHash] of Object.entries(recorded)) {
    const full = path.join(pkgDir, name);
    if (!fs.existsSync(full)) {
      mismatches.push({ file: name, reason: 'missing' });
      continue;
    }
    checked++;
    let actual;
    try {
      actual = await sha256File(full);
    } catch (e) {
      mismatches.push({ file: name, reason: 'read error: ' + e.message });
      continue;
    }
    if (actual !== recordedHash) {
      mismatches.push({ file: name, reason: 'hash mismatch' });
    }
  }
  const status = mismatches.length === 0 ? 'verified' : 'failed';
  return { status, checked, mismatches };
}

// summary record for one package (cached by mtime of the manifest)
const _cache = new Map(); // eventId -> { mtimeMs, record }

async function describePackage(pkgDir) {
  const manifestPath = path.join(pkgDir, 'upload_manifest.json');
  const st = fs.statSync(manifestPath);
  const eventId = path.basename(pkgDir);
  const hit = _cache.get(eventId);
  if (hit && hit.mtimeMs === st.mtimeMs) return hit.record;

  let manifest = {};
  try { manifest = readJson(manifestPath); } catch { /* leave empty */ }
  let event = {};
  try { event = readJson(path.join(pkgDir, 'event.json')); } catch { /* optional */ }

  const verification = await verifyPackage(pkgDir);
  const hasClip = fs.existsSync(path.join(pkgDir, 'clip.mp4'));

  const record = {
    event_id: eventId,
    risk_level: event.risk_level || manifest.risk_level || null,
    score: event.score != null ? event.score : (manifest.score != null ? manifest.score : null),
    reasons: event.reasons || [],
    vehicle_id: manifest.vehicle_id || event.vehicle_id || null,
    mission_id: manifest.mission_id || event.mission_id || null,
    created_utc: manifest.created_utc || null,
    has_clip: hasClip,
    manifest_sha256: manifest.manifest_sha256 || null,
    signed: !!(manifest.signature && manifest.signature.signed),
    verification,                       // { status, checked, mismatches }
    path: pkgDir,
  };
  _cache.set(eventId, { mtimeMs: st.mtimeMs, record });
  return record;
}

// ── routes ────────────────────────────────────────────────────────
router.get('/evidence/stats', async (req, res) => {
  const { packages, error } = listPackageDirs();
  if (error) return res.json({ error, stats: {} });
  const stats = { verified: 0, failed: 0, missing_hashes: 0, other: 0, total: packages.length };
  for (const dir of packages) {
    try {
      const rec = await describePackage(dir);
      const s = rec.verification.status;
      if (s in stats) stats[s]++; else stats.other++;
    } catch { stats.other++; }
  }
  res.json({ dir: EVIDENCE_DIR, stats });
});

router.get('/evidence', async (req, res) => {
  const { packages, error, dir } = listPackageDirs();
  if (error) return res.json({ dir, error, packages: [] });
  const out = [];
  for (const d of packages) {
    try { out.push(await describePackage(d)); } catch (e) { /* skip broken */ }
  }
  // newest first by created_utc when present
  out.sort((a, b) => String(b.created_utc).localeCompare(String(a.created_utc)));
  res.json({ dir, count: out.length, packages: out });
});

router.get('/evidence/:eventId', async (req, res) => {
  const safe = path.basename(req.params.eventId);
  const pkgDir = path.join(EVIDENCE_DIR, safe);
  if (!isPackageDir(pkgDir)) return res.status(404).json({ error: 'Package not found: ' + safe });
  try {
    const rec = await describePackage(pkgDir);
    let manifest = {};
    try { manifest = readJson(path.join(pkgDir, 'upload_manifest.json')); } catch {}
    res.json({ ...rec, manifest });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/evidence/:eventId/verify', async (req, res) => {
  const safe = path.basename(req.params.eventId);
  const pkgDir = path.join(EVIDENCE_DIR, safe);
  if (!isPackageDir(pkgDir)) return res.status(404).json({ error: 'Package not found: ' + safe });
  _cache.delete(safe); // force fresh
  try {
    const verification = await verifyPackage(pkgDir);
    res.json({ event_id: safe, verification });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/evidence/:eventId/clip', (req, res) => {
  const safe = path.basename(req.params.eventId);
  const clip = path.join(EVIDENCE_DIR, safe, 'clip.mp4');
  if (!fs.existsSync(clip)) return res.status(404).json({ error: 'No clip in package' });
  res.setHeader('Content-Type', 'video/mp4');
  fs.createReadStream(clip).pipe(res);
});

// ── optional: watch the folder and push new verified packages over WS ──
function startWatching(broadcastToWS) {
  if (!fs.existsSync(EVIDENCE_DIR)) {
    console.log('  ⚠️  [evidence] folder not found, watch disabled: ' + EVIDENCE_DIR);
    return;
  }
  const seen = new Set();
  // prime with what's already there so we only announce genuinely new arrivals
  try { listPackageDirs().packages.forEach((d) => seen.add(path.basename(d))); } catch {}

  setInterval(async () => {
    let pkgs;
    try { pkgs = listPackageDirs().packages; } catch { return; }
    for (const d of pkgs) {
      const id = path.basename(d);
      if (seen.has(id)) continue;
      seen.add(id);
      try {
        const rec = await describePackage(d);
        console.log('  📦 [evidence] new package ' + id + ' → ' + rec.verification.status);
        if (typeof broadcastToWS === 'function') {
          broadcastToWS({ type: 'evidence_package', data: rec });
        }
      } catch (e) { /* ignore */ }
    }
  }, 5000);
  console.log('  ✓ [evidence] watching ' + EVIDENCE_DIR + ' for new packages');
}

module.exports = { router, verifyPackage, describePackage, listPackageDirs, startWatching };
