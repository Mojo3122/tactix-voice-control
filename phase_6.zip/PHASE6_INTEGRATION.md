# Phase 6 — Command Center Integration

Phase 6 connects the edge mission controller to your existing TactixGlobalMCT dashboard.
Two pieces, both ADDITIVE — nothing in your dashboard or your five Jetson scripts changes.

The big finding: your dashboard already does almost all of the "receiving" work. Its
`POST /api/events` endpoint already dedupes, stores in TimescaleDB, publishes the live
Valkey alert, pushes over WebSocket to the operator UI, inserts into the AGE graph, and
escalates threat posture. So Phase 6 just (A) feeds that endpoint from the edge, and
(B) verifies the rsync'd evidence packages on arrival.

────────────────────────────────────────────────────────────────────────
PIECE A — Edge → dashboard event forwarding  (Jetson side, in the mission package)
────────────────────────────────────────────────────────────────────────
`tactix_mission/dashboard_forwarder.py` POSTs each elevated (yellow/red) event to the
dashboard's existing `/api/events`, mapped to its schema
(event_type, confidence, node_id, asset_id, asset_type, mission_id, payload, clip_id).
The dashboard then does the rest automatically.

It runs on the background executor (never blocks detection) and is best-effort: if the
dashboard is unreachable, the event is still saved locally and packaged — the dashboard is
a live mirror, not the system of record.

ENABLE IT (edit `config/mission_profile.yaml`):
    dashboard_forward:
      enabled: true
      base_url: "http://<DASHBOARD_PC_IP>:3001"
      node_id: "JETSON-EDGE-01"
      min_risk_level: "yellow"

Then run the mission node as usual — forwarding turns on automatically. No code changes.

────────────────────────────────────────────────────────────────────────
PIECE B — Package receiver + verifier  (dashboard side, ONE new file)
────────────────────────────────────────────────────────────────────────
`evidence_receiver.js` is a new Express router (same style as your `report_llm.js`). It
watches the folder the Jetson rsyncs evidence packages into, RE-VERIFIES each package's
SHA-256 seals (the receiving end of the integrity chain the edge produces), and exposes:

    GET  /api/evidence                 list packages + verification status
    GET  /api/evidence/:eventId        one package's manifest + verify report
    GET  /api/evidence/:eventId/verify force a fresh re-verification
    GET  /api/evidence/:eventId/clip   stream the package's clip.mp4
    GET  /api/evidence/stats           counts by verification status

INSTALL (2 steps, both additive — mirrors how report_llm is mounted in server/index.js):

 1. Copy `evidence_receiver.js` into your `server/` folder.

 2. In `server/index.js`, next to the existing
        const reportLLM = require('./report_llm');
        app.use('/api', reportLLM.router);
    add:
        const evidence = require('./evidence_receiver');
        app.use('/api', evidence.router);
        evidence.startWatching(broadcastToWS);   // optional: live WS push of new packages

 3. Point it at your rsync target folder via env (docker-compose.yml server service):
        EVIDENCE_DIR: /evidence
    and bind-mount the real folder, e.g.:
        volumes:
          - "/home/ai1/robot_data:/evidence:ro"
    (use wherever the Jetson rsyncs to — the bridge sends to ai1@…:/home/ai1/robot_data).

No existing route, table, or behaviour is touched. The new endpoints sit alongside the
others. `startWatching` is optional and only adds a `evidence_package` WebSocket message
type for new arrivals.

────────────────────────────────────────────────────────────────────────
HOW THE WHOLE LOOP NOW WORKS
────────────────────────────────────────────────────────────────────────
  Detection on Jetson
    → mission controller scores it (green/yellow/red)
    → YELLOW/RED:
        • forwards the event  → dashboard /api/events  → live Valkey alert + WS + posture
        • packages evidence (clip + telemetry + SHA-256) → rsync → command-center PC
    → evidence_receiver on the PC re-verifies the SHA-256 → /api/evidence (verified/failed)

The operator sees the live alert instantly (Piece A) and can pull the verified evidence
package with its clip moments later (Piece B). Integrity is provable end-to-end: sealed in
Python on the edge, re-checked in Node at the command center.

────────────────────────────────────────────────────────────────────────
VERIFY
────────────────────────────────────────────────────────────────────────
Edge (Piece A): `python -m unittest tactix_mission.tests.test_phase6 -v`
Dashboard (Piece B): mount a folder of real packages and GET /api/evidence — verified
packages report status "verified"; tampering flips a file to "hash mismatch".
