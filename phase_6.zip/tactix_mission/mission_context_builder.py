"""mission_context_builder.py — plan §23, §26.

Assembles the situational context the controller needs to turn a bare detection into a
contextual decision. Pulls together: mission identity, active playbook parameters
(night window, sensitive zones, thresholds), recent event history from mission memory,
and derived time-of-day flags (e.g. after_hours).

This is the piece that lets risk scoring be CONTEXTUAL without hardcoding: the scorer
asks "is this after hours / in a sensitive zone?" and the answers come from here, derived
from config + the live clock, not from constants baked into code.

Playbooks live in config/playbooks/<id>.yaml (optional). If a playbook file is absent,
sensible defaults from mission_profile.yaml are used so nothing crashes.
"""

from __future__ import annotations

import datetime as _dt
import os
from typing import Optional

from . import config_loader


def _parse_hhmm(s: str, default: tuple) -> tuple:
    try:
        h, m = s.split(":")
        return int(h), int(m)
    except Exception:
        return default


class MissionContextBuilder:
    def __init__(self, profile: Optional[dict] = None, memory=None):
        self.profile = profile if profile is not None else config_loader.load_yaml("mission_profile.yaml")
        self.memory = memory
        self.mission = self.profile.get("mission", {})
        self._playbook = self._load_playbook(self.mission.get("default_playbook"))

    # ---- playbook loading (optional file) ----
    def _load_playbook(self, playbook_id: Optional[str]) -> dict:
        if not playbook_id:
            return self._default_playbook()
        path = os.path.join(config_loader.config_dir(), "playbooks", f"{playbook_id}.yaml")
        if not os.path.exists(path):
            return self._default_playbook(playbook_id)
        try:
            import yaml
            with open(path, "r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or {}
            data.setdefault("playbook_id", playbook_id)
            return {**self._default_playbook(playbook_id), **data}
        except Exception:
            return self._default_playbook(playbook_id)

    @staticmethod
    def _default_playbook(playbook_id: str = "default") -> dict:
        # Night window default: 19:00 -> 06:00. Zones empty by default.
        return {
            "playbook_id": playbook_id,
            "night_window": {"start": "19:00", "end": "06:00"},
            "sensitive_zones": [],
            "gate_zones": [],
            "extra_risk_rules": [],
        }

    # ---- time-of-day derivation ----
    def is_after_hours(self, now: Optional[_dt.datetime] = None) -> bool:
        now = now or _dt.datetime.now()
        nw = self._playbook.get("night_window", {})
        sh, sm = _parse_hhmm(nw.get("start", "19:00"), (19, 0))
        eh, em = _parse_hhmm(nw.get("end", "06:00"), (6, 0))
        start = now.replace(hour=sh, minute=sm, second=0, microsecond=0)
        end = now.replace(hour=eh, minute=em, second=0, microsecond=0)
        if start <= end:
            return start <= now <= end
        # window crosses midnight (e.g. 19:00 -> 06:00)
        return now >= start or now <= end

    def zone_type_for(self, zone: Optional[str]) -> str:
        if not zone:
            return "general"
        if zone in (self._playbook.get("sensitive_zones") or []):
            return "sensitive"
        if zone in (self._playbook.get("gate_zones") or []):
            return "gate"
        return "general"

    # ---- recent history ----
    def recent_history(self, limit: int = 10) -> list:
        if not self.memory:
            return []
        return self.memory.recent_events(limit=limit,
                                         mission_id=self.mission.get("mission_id"))

    # ---- full context snapshot ----
    def build(self, now: Optional[_dt.datetime] = None) -> dict:
        now = now or _dt.datetime.now()
        recent = self.recent_history()
        red = sum(1 for e in recent if e.get("risk_level") == "red")
        yellow = sum(1 for e in recent if e.get("risk_level") == "yellow")
        return {
            "mission_id": self.mission.get("mission_id"),
            "vehicle_id": self.mission.get("vehicle_id"),
            "playbook_id": self._playbook.get("playbook_id"),
            "now_utc": now.astimezone(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "after_hours": self.is_after_hours(now),
            "sensitive_zones": self._playbook.get("sensitive_zones", []),
            "gate_zones": self._playbook.get("gate_zones", []),
            "recent_event_count": len(recent),
            "recent_red": red,
            "recent_yellow": yellow,
            "elevated_recently": (red + yellow) > 0,
        }

    def enrich_event(self, event: dict, now: Optional[_dt.datetime] = None) -> dict:
        """Annotate a raw detection event with derived context fields so the risk scorer
        can apply contextual rules. Returns a NEW dict (does not mutate the input).
        """
        out = dict(event)
        out.setdefault("after_hours", self.is_after_hours(now))
        zone = out.get("zone")
        if zone and "zone_type" not in out:
            out["zone_type"] = self.zone_type_for(zone)
        # repeat-sighting enrichment from track memory, if available
        if self.memory and out.get("track_key"):
            track = self.memory.get_track(out["track_key"])
            if track:
                out.setdefault("repeat_seen_count", track.get("seen_count", 1))
        return out

    @property
    def playbook(self) -> dict:
        return self._playbook
