"""dashboard_forwarder.py — Phase 6, Piece A.

Forwards a scored mission event to the command-center dashboard's EXISTING ingest
endpoint (POST /api/events on TactixGlobalMCT). The dashboard then does everything it
already does: Valkey dedup, TimescaleDB insert, live Valkey alert publish, WebSocket push
to the operator UI, AGE graph insert, and threat-posture escalation. We reuse all of it.

This adds NOTHING to the dashboard — it calls an endpoint that already exists. It maps our
event shape to the dashboard's required fields:
    event_id, timestamp, event_type, confidence, node_id, asset_id, asset_type,
    mission_id, payload, clip_id

Runs on the BACKGROUND executor (never blocks detection handling). Failures are logged and
dropped (the event is still saved locally + packaged); the dashboard is a best-effort live
mirror, not the system of record.
"""

from __future__ import annotations

from typing import Optional

from . import config_loader

try:
    import requests
    _HAVE_REQUESTS = True
except ImportError:
    _HAVE_REQUESTS = False

_RISK_ORDER = {"green": 0, "yellow": 1, "red": 2}


class DashboardForwarder:
    def __init__(self, profile: Optional[dict] = None):
        self.profile = profile if profile is not None else config_loader.load_yaml("mission_profile.yaml")
        cfg = self.profile.get("dashboard_forward", {}) or {}
        self.enabled = bool(cfg.get("enabled", False))
        self.base_url = (cfg.get("base_url", "http://127.0.0.1:3001")).rstrip("/")
        self.endpoint = cfg.get("events_endpoint", "/api/events")
        self.timeout = float(cfg.get("timeout_seconds", 4))
        self.node_id = cfg.get("node_id", "JETSON-EDGE-01")
        self.asset_type = cfg.get("asset_type", "vehicle")
        self.min_risk = cfg.get("min_risk_level", "yellow")
        self.event_type_map = cfg.get("event_type_map", {}) or {}
        self.mission_id = self.profile.get("mission", {}).get("mission_id", "mission")
        self.vehicle_id = self.profile.get("mission", {}).get("vehicle_id", "vehicle")

    def should_forward(self, risk_level: str) -> bool:
        if not self.enabled:
            return False
        return _RISK_ORDER.get(risk_level, 0) >= _RISK_ORDER.get(self.min_risk, 1)

    def build_payload(self, event_id: str, scored: dict, enriched: dict) -> dict:
        """Map our scored event to the dashboard's /api/events schema."""
        obj = enriched.get("object_type", "unknown")
        event_type = self.event_type_map.get(obj, f"{obj}_detected")
        # asset_id identifies the sensor/camera; fall back to the vehicle id
        asset_id = enriched.get("asset_id") or f"{self.vehicle_id}-cam"
        return {
            "event_id": event_id,
            "timestamp": enriched.get("timestamp_utc"),
            "event_type": event_type,
            "confidence": scored.get("confidence"),
            "node_id": self.node_id,
            "asset_id": asset_id,
            "asset_type": self.asset_type,
            "mission_id": self.mission_id,
            "clip_id": enriched.get("clip_id"),
            "payload": {
                "risk_level": scored.get("risk_level"),
                "score": scored.get("score"),
                "reasons": scored.get("reasons", []),
                "matched_rules": scored.get("matched_rules", []),
                "adjusted_confidence": scored.get("adjusted_confidence"),
                "object_type": obj,
                "object_color": enriched.get("object_color"),
                "zone": enriched.get("zone"),
                "zone_type": enriched.get("zone_type"),
                "after_hours": enriched.get("after_hours"),
                "posture": enriched.get("ptz"),
                "sensor": enriched.get("sensor"),
                "vehicle_id": self.vehicle_id,
            },
        }

    def forward(self, event_id: str, scored: dict, enriched: dict) -> dict:
        """POST the event to the dashboard. Returns a small result dict. Best-effort:
        never raises into the caller (intended to run on the background executor).
        """
        if not self.should_forward(scored.get("risk_level", "green")):
            return {"forwarded": False, "reason": "below min_risk_level or disabled"}
        if not _HAVE_REQUESTS:
            return {"forwarded": False, "reason": "requests not installed"}
        body = self.build_payload(event_id, scored, enriched)
        url = self.base_url + self.endpoint
        try:
            resp = requests.post(url, json=body, timeout=self.timeout)
        except Exception as e:
            return {"forwarded": False, "reason": f"request failed: {e}", "url": url}
        # 201 created, 409 duplicate are both "the dashboard has it"
        if resp.status_code in (201, 409):
            return {"forwarded": True, "http_status": resp.status_code, "event_id": event_id}
        try:
            msg = resp.json().get("error", resp.text[:200])
        except Exception:
            msg = resp.text[:200]
        return {"forwarded": False, "http_status": resp.status_code, "reason": msg}
