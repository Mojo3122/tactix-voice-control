"""demo_phase2.py — runnable walkthrough of Phase 2 (evidence + integrity + upload).

Run:  python -m tactix_mission.demo_phase2
Creates a real evidence package on disk under storage/evidence/demo_evt_*, hashes it,
queues it, "uploads" it (fake transport), and verifies the hashes. No network.
"""

import json
import os
import tempfile

from tactix_mission import (
    mission_memory as MM,
    risk_scorer as RS,
    evidence_packager as EP,
    evidence_integrity as EI,
    upload_queue as UQ,
    config_loader,
)


def main():
    # isolate demo state in a temp storage dir so we don't litter the real storage/
    tmp = tempfile.mkdtemp(prefix="tactix_demo2_")
    profile = json.loads(json.dumps(config_loader.load_yaml("mission_profile.yaml")))
    profile["paths"]["storage_root"] = tmp
    upload_cfg = config_loader.load_yaml("upload_config.yaml")

    mem = MM.MissionMemory(db_path=os.path.join(tmp, "mission_events.db"))
    scorer = RS.RiskScorer()
    packager = EP.EvidencePackager(profile=profile, upload_cfg=upload_cfg)
    queue = UQ.UploadQueue(mem, upload_cfg=upload_cfg)

    print("=" * 70)
    print("PHASE 2 DEMO — Evidence Package -> Hash -> Queue -> Upload -> Verify")
    print("=" * 70)
    print(f"(temp storage: {tmp})\n")

    # 1) a yellow detection event
    meta = {"object_type": "vehicle", "object_color": "white", "zone": "west_gate",
            "zone_type": "sensitive", "after_hours": True, "duration_sec": 96,
            "confidence": 0.87,
            "detections": [{"class": "vehicle", "track_id": "V3", "color": "white",
                            "confidence": 0.87}]}
    scored = scorer.score_event(meta)
    print(f"1) Scored event: {scored['risk_level'].upper()} (score {scored['score']})")
    print(f"   reasons: {scored['reasons']}")

    eid = mem.save_event({"mission_id": profile['mission']['mission_id'],
                          "risk_level": scored["risk_level"], "score": scored["score"],
                          "reasons": scored["reasons"], "event_json": meta})

    # 2) fake gallery clip to link in (stands in for the bridge's auto-record .mkv)
    clip = os.path.join(tmp, "auto_clip.mkv")
    with open(clip, "wb") as fh:
        fh.write(b"\x00\x01\x02 pretend video bytes " * 100)

    # 3) build the package
    pkg = packager.create_package(eid, scored, meta, clip_path=clip)
    print(f"\n2) Evidence package created at:\n   {pkg['package_path']}")
    print(f"   clip: {pkg['clip_action']}   files: {list(pkg['files'].values())}")
    print("   contents:")
    for f in sorted(os.listdir(pkg["package_path"])):
        size = os.path.getsize(os.path.join(pkg["package_path"], f))
        print(f"     - {f}  ({size} bytes)")

    manifest = pkg["manifest"]
    print(f"\n3) Manifest hash: {manifest['manifest_sha256'][:30]}...")
    print(f"   file hashes recorded: {len(manifest['file_hashes'])}")
    print(f"   signed: {manifest['signature']['signed']} "
          f"(signing enabled: {manifest['signature']['required']})")

    # 4) original clip still present (never deleted)
    print(f"\n4) Original gallery clip still on disk: {os.path.exists(clip)}  (must be True)")

    # 5) queue + upload (fake transport)
    queue.enqueue(eid, profile['mission']['mission_id'], pkg["package_path"])
    res = queue.process_pending()
    print(f"\n5) Upload queue result: {res[0]['status']}")
    print(f"   status counts: {queue.status_counts()}")

    # 6) verify integrity (this is what the command center will do)
    report = EI.verify_package(pkg["package_path"])
    print(f"\n6) Integrity verification: {report['status'].upper()} "
          f"({report['checked']} files checked, {len(report['mismatches'])} mismatches)")

    # 7) show tamper detection
    victim = os.path.join(pkg["package_path"], "event.json")
    with open(victim, "a") as fh:
        fh.write("\n# tampered\n")
    report2 = EI.verify_package(pkg["package_path"])
    print(f"\n7) After tampering with event.json -> verification: {report2['status'].upper()} "
          f"(this proves tamper detection works)")

    print("\n" + "=" * 70)
    mem.close()


if __name__ == "__main__":
    main()
