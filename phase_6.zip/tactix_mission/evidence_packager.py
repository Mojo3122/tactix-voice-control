"""evidence_packager.py — Ticket 6 (plan §5.7, §11, §11.1-11.3, §33).

Creates an evidence package folder for a yellow/red event:

    storage/evidence/<event_id>/
        clip.mp4              (LINKED from the existing gallery clip; never moved/deleted)
        snapshot_rgb.jpg      (if provided)
        snapshot_thermal.jpg  (if provided)
        event.json            (§11.1)
        telemetry.json        (§11.2)
        edge_summary.txt
        file_hashes.json      (§11.4 — every file hashed)
        upload_manifest.json  (§11.3 — includes manifest_sha256 + signature descriptor)
        manifest.sig          (optional, only if signing enabled)

Key safety rules honored:
  - missing clip does NOT crash (Ticket 6 acceptance) — package is still created.
  - the original gallery clip is LINKED (hardlink, else copy), never moved/deleted (§11.4).
  - manifest hash is computed AFTER file hashes are written (§11.4).

Reuses the existing system: the `clip` you pass in is the .mkv the bridge already wrote to
gallery/<mode>/auto-record/. The packager does not record anything itself.
"""

from __future__ import annotations

import json
import os
import shutil
import time
from typing import Optional

from . import config_loader
from . import evidence_integrity as integrity
from . import summary_generator as summaries


def _utcnow() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _link_or_copy(src: str, dst: str) -> str:
    """Hardlink src->dst (cheap, no extra disk) and fall back to copy across filesystems.
    Returns the action taken: 'linked' | 'copied' | 'missing'.
    """
    if not src or not os.path.isfile(src):
        return "missing"
    try:
        if os.path.exists(dst):
            os.remove(dst)
        os.link(src, dst)
        return "linked"
    except OSError:
        shutil.copy2(src, dst)
        return "copied"


class EvidencePackager:
    def __init__(self, profile: Optional[dict] = None, upload_cfg: Optional[dict] = None):
        self.profile = profile if profile is not None else config_loader.load_yaml("mission_profile.yaml")
        self.upload_cfg = upload_cfg if upload_cfg is not None else config_loader.load_yaml("upload_config.yaml")
        self.signing_cfg = self.upload_cfg.get("signing", {}) or {}
        self.evidence_root = config_loader.storage_path(
            self.profile.get("paths", {}).get("evidence_dir", "evidence"),
            profile=self.profile,
        )
        os.makedirs(self.evidence_root, exist_ok=True)
        ids = self.profile.get("mission", {})
        self.vehicle_id = ids.get("vehicle_id", "UNKNOWN-VEHICLE")
        self.device_id = ids.get("device_id", "UNKNOWN-DEVICE")
        self.mission_id = ids.get("mission_id", "UNKNOWN-MISSION")

    def create_package(self, event_id: str, scored: dict, event_meta: dict,
                       clip_path: str = "", snapshot_rgb: str = "",
                       snapshot_thermal: str = "",
                       telemetry: Optional[dict] = None) -> dict:
        """Build the package and return a result dict with package_path + manifest.

        scored      : output of risk_scorer.score_event(...)
        event_meta  : detection metadata (object_type, color, zone, detections, etc.)
        clip_path   : path to the existing gallery .mkv/.mp4 (linked in; may be missing)
        telemetry   : dict of telemetry fields (built by build_telemetry()), optional
        """
        pkg_dir = os.path.join(self.evidence_root, event_id)
        os.makedirs(pkg_dir, exist_ok=True)

        files_present = {}

        # 1) clip (link from gallery; missing must not crash)
        clip_action = _link_or_copy(clip_path, os.path.join(pkg_dir, "clip.mp4"))
        if clip_action != "missing":
            files_present["clip"] = "clip.mp4"

        # 2) snapshots (optional)
        if snapshot_rgb:
            if _link_or_copy(snapshot_rgb, os.path.join(pkg_dir, "snapshot_rgb.jpg")) != "missing":
                files_present["rgb_snapshot"] = "snapshot_rgb.jpg"
        if snapshot_thermal:
            if _link_or_copy(snapshot_thermal, os.path.join(pkg_dir, "snapshot_thermal.jpg")) != "missing":
                files_present["thermal_snapshot"] = "snapshot_thermal.jpg"

        # 3) event.json (§11.1)
        event_json = {
            "event_id": event_id,
            "mission_id": self.mission_id,
            "vehicle_id": self.vehicle_id,
            "timestamp_utc": event_meta.get("timestamp_utc") or _utcnow(),
            "event_type": event_meta.get("event_type", "detection_event"),
            "risk_level": scored.get("risk_level"),
            "score": scored.get("score"),
            "reasons": scored.get("reasons", []),
            "matched_rules": scored.get("matched_rules", []),
            "confidence": scored.get("confidence"),
            "adjusted_confidence": scored.get("adjusted_confidence"),
            "detections": event_meta.get("detections", []),
            "operator_action": event_meta.get("operator_action", ""),
            "recommended_action": event_meta.get("recommended_action", "command_center_review"),
        }
        self._write_json(pkg_dir, "event.json", event_json)
        files_present["event_json"] = "event.json"

        # 4) telemetry.json (§11.2)
        tele = telemetry or self.build_telemetry()
        self._write_json(pkg_dir, "telemetry.json", tele)
        files_present["telemetry_json"] = "telemetry.json"

        # 5) edge_summary.txt
        summary_text = summaries.edge_summary(scored, event_meta)
        with open(os.path.join(pkg_dir, "edge_summary.txt"), "w", encoding="utf-8") as fh:
            fh.write(summary_text + "\n")
        files_present["edge_summary"] = "edge_summary.txt"

        # 6) hash every file (§11.4) -> file_hashes.json
        file_hashes = integrity.hash_package_files(pkg_dir)

        # 7) build manifest (§11.3) referencing the file hashes
        manifest = {
            "schema_version": "1.1",
            "package_id": f"pkg_{event_id}",
            "event_id": event_id,
            "mission_id": self.mission_id,
            "vehicle_id": self.vehicle_id,
            "device_id": self.device_id,
            "playbook_id": self.profile.get("mission", {}).get("default_playbook", ""),
            "created_utc": _utcnow(),
            "risk_level": scored.get("risk_level"),
            "score": scored.get("score"),
            "upload_status": "pending",
            "files": files_present,
            "file_hashes": file_hashes,
        }

        # 8) manifest hash AFTER file hashes are written (§11.4)
        manifest["manifest_sha256"] = integrity.compute_manifest_hash(manifest)

        # 9) optional signing (off by default)
        sig_descriptor = integrity.sign_manifest(
            manifest["manifest_sha256"], self.signing_cfg, pkg_dir
        )
        manifest["signature"] = {
            "algorithm": self.signing_cfg.get("algorithm", "ed25519"),
            "key_id": self.signing_cfg.get("key_id", ""),
            "signature_file": "manifest.sig" if sig_descriptor.get("signed") else None,
            "required": bool(self.signing_cfg.get("enabled", False)),
            "signed": sig_descriptor.get("signed", False),
            "note": sig_descriptor.get("reason", ""),
        }

        # write the manifest last
        self._write_json(pkg_dir, "upload_manifest.json", manifest)

        return {
            "status": "success",
            "event_id": event_id,
            "package_path": pkg_dir,
            "manifest": manifest,
            "clip_action": clip_action,            # linked | copied | missing
            "files": files_present,
        }

    def build_telemetry(self, gps: Optional[dict] = None,
                        ptz: Optional[dict] = None,
                        sensor_mode: str = "rgb") -> dict:
        """Build a telemetry.json payload (§11.2). PTZ fields map to the existing
        /tactix/ptz/{pan,tilt,zoom}_actual topics; the live controller will pass current
        values in Phase 4/5. Defaults keep the package valid when values are unavailable.
        """
        return {
            "vehicle_id": self.vehicle_id,
            "timestamp_utc": _utcnow(),
            "gps": gps or {"lat": None, "lon": None, "accuracy_m": None},
            "ptz_position": ptz or {"pan": None, "tilt": None, "zoom": None},
            "sensor_mode": sensor_mode,
            "camera_id": f"front_ptz_{sensor_mode}",
            "network_status": {
                "upload_method": "cellular_or_station_sync",
                "signal_quality": "unknown",
            },
        }

    @staticmethod
    def _write_json(pkg_dir: str, name: str, data: dict):
        with open(os.path.join(pkg_dir, name), "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, sort_keys=True, default=str)
