"""demo_phase5.py — Phase 5 live-wiring demo against a MOCK bridge.

Run:  python -m tactix_mission.demo_phase5
Starts a tiny mock of your bridge (so no real system is needed), then shows the REAL
executor sending commands to bridge endpoints, and a detection trigger flowing through
the ROS2-free runner. Proves the wiring without touching your scripts or needing ROS2.

On the actual Jetson you do NOT run this — you run `python3 -m tactix_mission.mission_node`,
which talks to the real bridge on http://127.0.0.1:5000 and subscribes to real ROS2 topics.
"""

import json
import os
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

from tactix_mission import (
    bridge_executor as BE,
    mission_controller as MC,
    mission_node as MN,
    mission_memory as MM,
    config_loader,
)


class _Mock(BaseHTTPRequestHandler):
    seen = []
    def log_message(self, *a): pass
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}") if n else {}
        _Mock.seen.append((self.path, body))
        out = json.dumps({"ok": True, "message": f"mock {self.path}"}).encode()
        self.send_response(200); self.send_header("Content-Length", str(len(out)))
        self.end_headers(); self.wfile.write(out)


def main():
    srv = HTTPServer(("127.0.0.1", 0), _Mock)
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{port}"

    tmp = tempfile.mkdtemp(prefix="tactix_demo5_")
    profile = json.loads(json.dumps(config_loader.load_yaml("mission_profile.yaml")))
    profile["paths"]["storage_root"] = tmp
    mem = MM.MissionMemory(db_path=os.path.join(tmp, "m.db"))
    ctrl = MC.MissionController(profile=profile, memory=mem,
                               tool_executor=BE.BridgeExecutor(base_url=base))
    runner = MN.MissionNodeRunner(controller=ctrl, profile=profile)

    print("=" * 70)
    print("PHASE 5 DEMO — REAL wiring against a MOCK bridge")
    print("=" * 70)
    print(f"(mock bridge at {base})\n")

    print("OPERATOR COMMANDS -> real HTTP to bridge endpoints:")
    for cmd in ["scan 360", "scan my 3 o'clock", "switch to thermal", "track that car"]:
        res = ctrl.handle_command(cmd)
        path, body = _Mock.seen[-1]
        print(f"  '{cmd}'  ->  POST {path}  {body}   [{res['status']}]")

    print("\nDETECTION TRIGGER (as published on /awareness/auto_record_trigger):")
    for reason in ["weapon_rgb", "crouching_thermal"]:
        results = runner.on_auto_record_trigger(reason)
        for r in results:
            print(f"  '{reason}'  ->  {r['risk_level'].upper()} (score {r['score']}, "
                  f"packaged={r['packaged']})")

    print("\nTELEMETRY (as published on /tactix/ptz/*_actual):")
    runner.on_pan(15.0); runner.on_tilt(-3.0); runner.on_zoom(42.0)
    print(f"  current ptz: {runner._ptz}")

    print("\nENDPOINTS THE MISSION LAYER CALLED (all pre-existing on your bridge):")
    for path in sorted({p for p, _ in _Mock.seen}):
        print(f"  {path}")

    ctrl.shutdown()
    srv.shutdown()
    print("\n" + "=" * 70)


if __name__ == "__main__":
    main()
