"""reason_event_adapter.py — v1 risk input bridge (plan §9.2, §33).

The existing pipeline publishes reason STRINGS on /awareness/auto_record_trigger, e.g.
"weapon_rgb", "crouching_thermal", "weapon_rgb,crouching_rgb". It does NOT (yet) emit
per-detection confidences. This adapter converts those strings into the structured
events the data-driven risk_scorer expects, assigning a configurable nominal confidence
(mission_profile.yaml: reason_string_confidence) and detecting cross-sensor confirmation
when both RGB and thermal report the same object class.

This keeps risk scoring fully data-driven with ZERO change to the pipeline. When/if the
pipeline is later extended (additively) to emit real confidences, this adapter is simply
bypassed in favour of the richer event.
"""

from __future__ import annotations

from typing import Optional

from . import config_loader

# reason token -> (object_type, sensor, extra fields)
_TOKEN_MAP = {
    "weapon_rgb":      ("weapon", "rgb", {}),
    "weapon_thermal":  ("weapon", "thermal", {}),
    "crouching_rgb":   ("person", "rgb", {"posture": "crouching"}),
    "crouching_thermal": ("person", "thermal", {"posture": "crouching"}),
}


def reason_string_to_events(reason: str, profile: Optional[dict] = None) -> list:
    """Convert a comma-joined reason string into a list of structured events.

    Cross-sensor confirmation: if the same object_type appears from >=2 sensors, every
    resulting event for that object_type carries sensor_confirmations listing the sensors.
    """
    prof = profile if profile is not None else config_loader.load_yaml("mission_profile.yaml")
    nominal_conf = prof.get("reason_string_confidence", 0.85)

    tokens = [t.strip() for t in (reason or "").split(",") if t.strip()]
    parsed = []
    for tok in tokens:
        if tok in _TOKEN_MAP:
            obj, sensor, extra = _TOKEN_MAP[tok]
            parsed.append((tok, obj, sensor, extra))

    # group sensors per object_type for cross-sensor confirmation
    sensors_by_obj: dict = {}
    for _tok, obj, sensor, _extra in parsed:
        sensors_by_obj.setdefault(obj, set()).add(sensor)

    events = []
    for tok, obj, sensor, extra in parsed:
        confirmations = sorted(sensors_by_obj.get(obj, set()))
        ev = {
            "object_type": obj,
            "confidence": nominal_conf,
            "sensor": sensor,
            "sensor_confirmations": confirmations if len(confirmations) >= 2 else [],
            "source_reason_token": tok,
        }
        ev.update(extra)
        events.append(ev)
    return events
