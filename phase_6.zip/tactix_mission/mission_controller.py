"""mission_controller.py — Phase 4 (plan §4, §20, §22, §24).

The single orchestrator that ties every phase together into one object — the "nervous
system" that sits on top of the existing pipeline. It runs two main flows:

  handle_command(text, source)   — operator voice/UI command:
      normalize -> permission check -> (approval gate) -> execute via registry ->
      log to mission memory + transcript

  handle_detection(event)        — a detection event from the pipeline:
      enrich with mission context -> risk score -> log -> if yellow/red:
      package evidence + queue upload (BOTH on the background executor, never blocking) ->
      build edge summary

Still fully standalone: tool execution is FAKE (Phase 1 registry), uploads are FAKE
(Phase 2 queue), nothing touches ROS2/Flask or the existing scripts. Phase 5 swaps the
registry executor and upload transport for real adapters — the controller logic here does
not change.

Design choices:
  - Realtime path (command parse, permission, fake execute, score) runs inline and fast.
  - Slow path (evidence packaging, hashing, upload) is submitted to the bounded executor
    so the controller never stalls the caller (§24.2).
  - An optional approval_callback(tool, params, prompt) -> bool lets approval-gated tools
    be driven deterministically in tests / by a real operator prompt later. If absent,
    approval-required tools are NOT executed (fail-safe) and reported as 'awaiting_approval'.
"""

from __future__ import annotations

import time
from typing import Callable, Optional

from . import config_loader
from . import intent_normalizer as IN
from . import tool_registry as TR
from . import permission_engine as PE
from . import mission_memory as MM
from . import risk_scorer as RS
from . import summary_generator as SG
from . import evidence_packager as EP
from . import upload_queue as UQ
from . import mission_context_builder as MCB
from . import bounded_async_executor as BAE
from . import health_monitor as HM
from . import capability_manifest as CM


def _utcnow() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class MissionController:
    def __init__(self,
                 profile: Optional[dict] = None,
                 memory: Optional[MM.MissionMemory] = None,
                 registry: Optional[TR.ToolRegistry] = None,
                 tool_executor: Optional[Callable] = None,
                 upload_transport: Optional[Callable] = None,
                 approval_callback: Optional[Callable] = None,
                 clip_stability_waiter: Optional[Callable] = None,
                 dashboard_forwarder=None,
                 start_executor: bool = True):
        self.profile = profile if profile is not None else config_loader.load_yaml("mission_profile.yaml")
        self.mission_id = self.profile.get("mission", {}).get("mission_id", "mission")

        # core components (shared configs => no drift)
        self.registry = registry or TR.ToolRegistry()
        self.permissions = PE.PermissionEngine(registry=self.registry)
        self.memory = memory or MM.MissionMemory(profile=self.profile)
        self.scorer = RS.RiskScorer()
        self.context = MCB.MissionContextBuilder(profile=self.profile, memory=self.memory)
        self.packager = EP.EvidencePackager(profile=self.profile)
        self.upload_cfg = config_loader.load_yaml("upload_config.yaml")
        self.uploads = UQ.UploadQueue(self.memory, upload_cfg=self.upload_cfg,
                                      transport=upload_transport)
        self.executor = BAE.BoundedAsyncExecutor(workers=2, max_queue=64)
        self.health = HM.HealthMonitor(profile=self.profile, memory=self.memory,
                                       executor=self.executor, upload_queue=self.uploads)

        # injectable hooks (Phase 5 will pass real ones)
        self._tool_executor = tool_executor          # None => fake registry execution
        self._approval_callback = approval_callback   # None => fail-safe no-execute
        # Optional: clip_stability_waiter(clip_path) -> bool, called on the BACKGROUND
        # thread before packaging so the clip is fully written before it is hashed.
        self._clip_stability_waiter = clip_stability_waiter
        # Optional Phase 6: forwards events to the command-center dashboard /api/events.
        self._dashboard_forwarder = dashboard_forwarder

        if start_executor:
            self.executor.start()

    # ---- lifecycle ----
    def shutdown(self, timeout: float = 5.0):
        self.executor.shutdown(drain=True, timeout=timeout)
        self.memory.close()

    def write_capability_manifest(self) -> str:
        return CM.CapabilityManifest(registry=self.registry, profile=self.profile).write()

    # ====================================================================
    # FLOW 1 — operator command
    # ====================================================================
    def handle_command(self, text: str, source: str = "voice") -> dict:
        intent = IN.normalize(text, source=source)
        self.memory.append_transcript(self.mission_id, "command_received",
                                      {"text": text, "source": source, "intent": intent})

        if intent["intent"] == "unknown":
            result = {"status": "rejected", "reason": "unknown command", "intent": intent}
            self._log_command_event(intent, result, tool=None)
            return result

        tool = intent["intent"]

        # internal (no external tool) intents handled directly
        if tool in ("summarize_patrol", "summarize_last_minutes"):
            return self._handle_summary_intent(intent)
        if tool == "mark_false_alarm":
            return self._handle_mark_false_alarm(intent)

        # permission gate
        decision = self.permissions.check(tool)
        self.memory.append_transcript(self.mission_id, "tool_permission_checked",
                                      {"tool": tool, "decision": decision.level})

        if decision.level == PE.BLOCKED:
            result = {"status": "blocked", "tool": tool, "reason": "blocked by policy"}
            self._log_command_event(intent, result, tool)
            return result

        if decision.level == PE.APPROVAL_REQUIRED:
            prompt = SG.approval_prompt(tool, intent["parameters"])
            approved = False
            if self._approval_callback:
                try:
                    approved = bool(self._approval_callback(tool, intent["parameters"], prompt))
                except Exception:
                    approved = False
            if not approved:
                result = {"status": "awaiting_approval", "tool": tool, "prompt": prompt}
                self._log_command_event(intent, result, tool)
                return result
            # approved -> fall through to execute

        # execute (fake in Phase 1/4; real executor injected in Phase 5)
        exec_result = self.registry.execute(tool, intent["parameters"],
                                             executor=self._tool_executor)
        self.memory.append_transcript(self.mission_id, "tool_execution_completed",
                                      {"tool": tool, "result": exec_result})
        result = {"status": exec_result.get("status", "success"),
                  "tool": tool, "execution": exec_result, "intent": intent}
        self._log_command_event(intent, result, tool)
        return result

    def _handle_summary_intent(self, intent: dict) -> dict:
        if intent["intent"] == "summarize_last_minutes":
            minutes = int(intent["parameters"].get("minutes", 5))
            events = self.memory.recent_events(limit=200, mission_id=self.mission_id)
            # naive time filter omitted (no per-event epoch here); use recent N
            window = events
            label = f"last {minutes} minutes"
        else:
            window = self.memory.recent_events(limit=200, mission_id=self.mission_id)
            label = "patrol"
        roll = SG.patrol_summary(window, mission_id=self.mission_id)
        self.memory.save_summary(self.mission_id, roll["window_start_utc"],
                                 roll["window_end_utc"], roll["green_count"],
                                 roll["yellow_count"], roll["red_count"],
                                 roll["summary_text"])
        return {"status": "success", "tool": intent["intent"],
                "summary": roll["summary_text"], "window": label, "counts": roll}

    def _handle_mark_false_alarm(self, intent: dict) -> dict:
        latest = self.memory.latest_event(mission_id=self.mission_id)
        if not latest:
            return {"status": "rejected", "reason": "no event to mark"}
        self.memory.set_operator_action(latest["event_id"], "false_alarm")
        self.memory.append_transcript(self.mission_id, "operator_action",
                                      {"event_id": latest["event_id"], "action": "false_alarm"})
        return {"status": "success", "tool": "mark_false_alarm",
                "event_id": latest["event_id"]}

    def _log_command_event(self, intent: dict, result: dict, tool: Optional[str]):
        self.memory.save_event({
            "mission_id": self.mission_id,
            "source": intent.get("source"),
            "intent": intent.get("intent"),
            "tool_name": tool,
            "risk_level": None,
            "event_json": {"type": "command", "intent": intent, "result_status": result.get("status")},
        })

    # ====================================================================
    # FLOW 2 — detection event
    # ====================================================================
    def handle_detection(self, event: dict, clip_path: str = "",
                         snapshot_rgb: str = "", snapshot_thermal: str = "",
                         now=None, suppress_packaging: bool = False) -> dict:
        # 1) enrich with mission context (after_hours / zone_type / repeat count)
        enriched = self.context.enrich_event(event, now=now)

        # 2) score (realtime, inline, fast)
        scored = self.scorer.score_event(enriched)

        # 3) track memory (repeat sightings) if a track key is present
        if enriched.get("track_key"):
            self.memory.upsert_track(enriched["track_key"], self.mission_id,
                                     enriched.get("object_type", "unknown"),
                                     object_color=enriched.get("object_color", ""),
                                     last_zone=enriched.get("zone", ""))

        # 4) persist the scored event
        event_id = self.memory.save_event({
            "mission_id": self.mission_id,
            "source": "pipeline",
            "intent": "detection",
            "risk_level": scored["risk_level"],
            "score": scored["score"],
            "confidence": scored["confidence"],
            "adjusted_confidence": scored["adjusted_confidence"],
            "reasons": scored["reasons"],
            "matched_rules": scored["matched_rules"],
            "event_json": enriched,
        })

        summary = SG.edge_summary(scored, enriched)
        response = {
            "status": "handled",
            "event_id": event_id,
            "risk_level": scored["risk_level"],
            "score": scored["score"],
            "reasons": scored["reasons"],
            "summary": summary,
            "packaged": False,
        }

        # 5) elevated events -> package + queue, BOTH on the background executor.
        #    suppress_packaging (Phase 5.1 cooldown) logs+scores the event but skips the
        #    heavy package/upload to avoid dozens of near-identical packages.
        if scored["risk_level"] in ("yellow", "red") and not suppress_packaging:
            response["packaged"] = True
            accepted = self.executor.submit(
                self._package_and_queue, event_id, scored, enriched,
                clip_path, snapshot_rgb, snapshot_thermal,
                name=f"package_{event_id}")
            response["background_accepted"] = accepted
            self.memory.append_transcript(self.mission_id, "evidence_packaging_queued",
                                          {"event_id": event_id, "accepted": accepted})

        # 6) Phase 6: forward elevated events to the command-center dashboard on the
        #    background executor (best-effort live mirror). The dashboard has its own
        #    dedup, so forwarding even cooldown-suppressed events is safe and desirable
        #    (the operator should see every alert, even if we only PACKAGE one per window).
        if (self._dashboard_forwarder is not None
                and self._dashboard_forwarder.should_forward(scored["risk_level"])):
            fwd_accepted = self.executor.submit(
                self._forward_to_dashboard, event_id, scored, enriched,
                name=f"forward_{event_id}")
            response["dashboard_forward_accepted"] = fwd_accepted

        return response

    def _package_and_queue(self, event_id, scored, enriched,
                           clip_path, snapshot_rgb, snapshot_thermal):
        """Runs on a background worker (never blocks realtime)."""
        # Wait for the clip to finish writing before hashing it, so the recorded hash
        # matches the FINAL clip (the bridge records ~5s clips with ffmpeg). If the clip
        # never stabilizes / stays empty, drop it from the package rather than ship a
        # hash that will fail verification.
        if clip_path and self._clip_stability_waiter is not None:
            try:
                if not self._clip_stability_waiter(clip_path):
                    clip_path = ""  # unstable/empty -> omit clip; package still valid
            except Exception:
                clip_path = ""
        pkg = self.packager.create_package(
            event_id, scored, enriched,
            clip_path=clip_path, snapshot_rgb=snapshot_rgb,
            snapshot_thermal=snapshot_thermal)
        # link package path back onto the event row
        self.memory.save_event({
            "event_id": event_id, "mission_id": self.mission_id,
            "risk_level": scored["risk_level"], "score": scored["score"],
            "reasons": scored["reasons"], "matched_rules": scored["matched_rules"],
            "confidence": scored["confidence"], "adjusted_confidence": scored["adjusted_confidence"],
            "evidence_package_path": pkg["package_path"], "event_json": enriched,
        })
        # queue upload (approval-gated in real ops; here it just enqueues)
        self.uploads.enqueue(event_id, self.mission_id, pkg["package_path"])
        return pkg

    def _forward_to_dashboard(self, event_id, scored, enriched):
        """Runs on a background worker — POST the event to the dashboard /api/events."""
        try:
            result = self._dashboard_forwarder.forward(event_id, scored, enriched)
            self.memory.append_transcript(self.mission_id, "dashboard_forward",
                                          {"event_id": event_id, "result": result})
            return result
        except Exception as e:
            return {"forwarded": False, "reason": str(e)}

    # ---- convenience ----
    def process_uploads_once(self) -> list:
        """One pass of the upload queue (caller schedules cadence)."""
        return self.uploads.process_pending()

    def health_report(self) -> dict:
        return self.health.report()
