"""intent_normalizer.py — Ticket 1 (plan §6, §18.1).

Converts raw voice/UI command strings into structured intent JSON using simple phrase
matching, regex, and dictionaries. NO heavy local LLM (plan §5.2). Unknown commands
return intent="unknown" so the controller can reject them cleanly (Ticket 1 acceptance).

Output schema:
    {
      "intent": <str>,
      "source": "voice" | "ui" | <caller-supplied>,
      "parameters": { ... },
      "requires_approval": <bool>   # hint only; permission_engine is authoritative
    }
"""

from __future__ import annotations

import re
from typing import Optional

# Supported v1 intents (plan §6.3). Order matters: more specific patterns first.
SUPPORTED_INTENTS = [
    "scan_360",
    "scan_direction",
    "switch_rgb",
    "switch_thermal",
    "track_object",
    "stop_tracking",
    "save_clip",
    "share_latest_clip",
    "summarize_patrol",
    "summarize_last_minutes",
    "mark_false_alarm",
]

# Intents whose default requires_approval hint is True (mirrors permissions.yaml; the
# permission_engine remains the source of truth at execution time).
_APPROVAL_HINT = {"share_latest_clip"}

# Clock directions: "2 o'clock", "2 oclock", "2 o clock", "two o'clock"
_CLOCK_WORDS = {
    "twelve": 12, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11,
}
_CLOCK_RE = re.compile(
    r"\b(?:(1[0-2]|[1-9])|(" + "|".join(_CLOCK_WORDS) + r"))\s*o[\s'`]*clock\b"
)

# Person/vehicle index words for tracking: "person one".."person 5", "car two"
_INDEX_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "1": 1, "2": 2, "3": 3, "4": 4, "5": 5,
}
_TRACK_RE = re.compile(
    r"\btrack\b.*?\b(person|people|car|vehicle)\b\s*(one|two|three|four|five|[1-5])?"
)

# "last N minutes" / "past 5 minutes"
_MINUTES_RE = re.compile(r"\b(?:last|past)\s+(\d{1,3})\s*min")


def _result(intent: str, source: str, parameters: dict) -> dict:
    return {
        "intent": intent,
        "source": source,
        "parameters": parameters,
        "requires_approval": intent in _APPROVAL_HINT,
    }


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip().lower())


def _parse_clock(text: str) -> Optional[str]:
    m = _CLOCK_RE.search(text)
    if not m:
        return None
    if m.group(1):
        hour = int(m.group(1))
    else:
        hour = _CLOCK_WORDS[m.group(2)]
    return f"{hour}_oclock"


def normalize(command: str, source: str = "voice") -> dict:
    """Normalize a raw command string into structured intent JSON.

    Always returns a dict; unknown commands yield intent="unknown".
    """
    text = _norm(command)
    if not text:
        return _result("unknown", source, {"raw": command})

    # --- mode switches ---
    if re.search(r"\b(switch|go|change).*(thermal|infrared|ir)\b", text) or text == "thermal":
        return _result("switch_thermal", source, {"mode": "thermal"})
    if re.search(r"\b(switch|go|change).*(rgb|colou?r|visible|normal)\b", text) or text == "rgb":
        return _result("switch_rgb", source, {"mode": "rgb"})

    # --- stop tracking (before track_object, since both contain object words) ---
    if re.search(r"\b(stop|cancel|end|halt)\b.*\b(track|tracking|follow)\b", text) \
       or re.search(r"\b(stop|cancel)\b.*\b(it|that|target)\b", text):
        return _result("stop_tracking", source, {})

    # --- scan direction (must come before scan_360 if a clock is present) ---
    clock = _parse_clock(text)
    if "scan" in text and clock:
        mode = "thermal" if re.search(r"\bthermal\b", text) else "rgb"
        return _result("scan_direction", source, {"direction": clock, "mode": mode})

    # --- scan 360 ---
    if re.search(r"\bscan\b", text) and re.search(r"\b(360|three\s*sixty|full|around|all\s*round)\b", text):
        return _result("scan_360", source, {})
    if text in ("scan", "scan 360", "do a scan", "start scan"):
        return _result("scan_360", source, {})

    # --- track object ---
    tm = _TRACK_RE.search(text)
    if tm:
        obj_word = tm.group(1)
        obj_type = "vehicle" if obj_word in ("car", "vehicle") else "person"
        idx_word = tm.group(2)
        params = {"object_type": obj_type}
        if idx_word:
            params["index"] = _INDEX_WORDS[idx_word]
        return _result("track_object", source, params)
    if re.search(r"\btrack\b.*\b(that|this|it)\b", text):
        return _result("track_object", source, {"object_type": "unknown"})

    # --- share latest clip ---
    if re.search(r"\b(send|share|upload|push)\b.*\b(clip|video|footage|recording)\b", text):
        recipient = "command" if re.search(r"\b(command|hq|base|center|centre|control)\b", text) else "command"
        return _result("share_latest_clip", source, {"recipient": recipient})

    # --- summaries ---
    mm = _MINUTES_RE.search(text)
    if mm and re.search(r"\b(summar|recap|report)\b", text):
        return _result("summarize_last_minutes", source, {"minutes": int(mm.group(1))})
    if re.search(r"\b(summar|recap|report)\b.*\b(patrol|mission|shift)\b", text) \
       or text in ("summarize patrol", "summarise patrol", "patrol summary"):
        return _result("summarize_patrol", source, {})

    # --- mark false alarm ---
    if re.search(r"\b(false\s*alarm|mark.*false|disregard|nothing\s*there|all\s*clear)\b", text):
        return _result("mark_false_alarm", source, {})

    # --- save clip ---
    if re.search(r"\b(save|record|capture)\b.*\b(clip|this|that|video|footage)\b", text) \
       or text in ("save clip", "record", "start recording"):
        return _result("save_clip", source, {})

    return _result("unknown", source, {"raw": command})
