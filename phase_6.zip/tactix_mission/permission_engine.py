"""permission_engine.py — Ticket 3 (plan §8, §27).

Resolves every tool to exactly one of: auto | approval_required | blocked, and logs
every decision. Hard safety blocks (permissions.yaml: hard_blocked) can NEVER be
overridden by registry, playbook, site profile, or operator command (§27.1 rank 1).

Resolution order (fail-safe):
    1. hard_blocked list           -> "blocked" (cannot be overridden)
    2. permissions.permissions map -> explicit level
    3. registry tool's permission  -> declared level
    4. default_permission          -> "approval_required" (never silent auto)
"""

from __future__ import annotations

import time
from typing import Optional

from . import config_loader

AUTO = "auto"
APPROVAL_REQUIRED = "approval_required"
BLOCKED = "blocked"
_VALID = {AUTO, APPROVAL_REQUIRED, BLOCKED}


class PermissionDecision:
    __slots__ = ("tool", "level", "reason", "source", "timestamp_utc")

    def __init__(self, tool, level, reason, source):
        self.tool = tool
        self.level = level
        self.reason = reason
        self.source = source  # which config layer decided
        self.timestamp_utc = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    def to_dict(self) -> dict:
        return {
            "tool": self.tool,
            "level": self.level,
            "reason": self.reason,
            "source": self.source,
            "timestamp_utc": self.timestamp_utc,
        }

    def __repr__(self):
        return f"<PermissionDecision {self.tool}={self.level} ({self.source})>"


class PermissionEngine:
    def __init__(self, permissions: Optional[dict] = None,
                 registry=None, logger=None):
        self.cfg = permissions if permissions is not None else config_loader.load_yaml("permissions.yaml")
        self.hard_blocked = set(self.cfg.get("hard_blocked", []) or [])
        self.explicit = self.cfg.get("permissions", {}) or {}
        self.default = self.cfg.get("default_permission", APPROVAL_REQUIRED)
        self.registry = registry          # optional ToolRegistry for layer 3
        self._logger = logger              # optional callable(dict) for audit
        self.decisions: list = []          # in-memory decision log

    def check(self, tool: str) -> PermissionDecision:
        # 1. hard safety block — highest precedence, never overridable
        if tool in self.hard_blocked:
            return self._record(tool, BLOCKED, "hard safety block", "hard_blocked")

        # 2. explicit permissions map
        if tool in self.explicit:
            lvl = self.explicit[tool]
            if lvl not in _VALID:
                lvl = self.default
                return self._record(tool, lvl, f"invalid level in permissions.yaml; using default", "default")
            return self._record(tool, lvl, "explicit permission policy", "permissions.yaml")

        # 3. registry-declared permission
        if self.registry is not None and self.registry.has_tool(tool):
            lvl = (self.registry.get(tool) or {}).get("permission")
            if lvl in _VALID:
                return self._record(tool, lvl, "registry-declared permission", "tool_registry.yaml")

        # 4. fail-safe default
        return self._record(tool, self.default, "no explicit policy; fail-safe default", "default")

    def is_allowed_now(self, tool: str) -> bool:
        """Convenience: True only for auto. approval_required/blocked are not allowed now."""
        return self.check(tool).level == AUTO

    def _record(self, tool, level, reason, source) -> PermissionDecision:
        d = PermissionDecision(tool, level, reason, source)
        self.decisions.append(d)
        if self._logger:
            try:
                self._logger(d.to_dict())
            except Exception:
                pass
        return d
