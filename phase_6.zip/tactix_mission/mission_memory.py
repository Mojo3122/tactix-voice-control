"""mission_memory.py — Ticket 4 (plan §10, §25.1).

SQLite mission memory: mission_events, track_memory, mission_summaries, upload_queue,
and mission_transcript (§25.1 for replay/recovery). This is mission memory, NOT raw
frame storage (§5.6). Separate DB from the existing RecordingLogDB — the existing
scripts are not touched.

Ticket 4 acceptance: events survive restart and store raw JSON.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
import uuid
from typing import Optional

from . import config_loader

_SCHEMA = """
CREATE TABLE IF NOT EXISTS mission_events (
    event_id TEXT PRIMARY KEY,
    mission_id TEXT,
    timestamp_utc TEXT,
    source TEXT,
    intent TEXT,
    tool_name TEXT,
    risk_level TEXT,
    score INTEGER,
    confidence REAL,
    adjusted_confidence REAL,
    reasons_json TEXT,
    matched_rules_json TEXT,
    event_json TEXT,
    evidence_package_path TEXT,
    operator_action TEXT
);

CREATE TABLE IF NOT EXISTS track_memory (
    track_key TEXT PRIMARY KEY,
    mission_id TEXT,
    object_type TEXT,
    object_color TEXT,
    first_seen_utc TEXT,
    last_seen_utc TEXT,
    seen_count INTEGER,
    last_zone TEXT,
    metadata_json TEXT
);

CREATE TABLE IF NOT EXISTS mission_summaries (
    summary_id TEXT PRIMARY KEY,
    mission_id TEXT,
    window_start_utc TEXT,
    window_end_utc TEXT,
    green_count INTEGER,
    yellow_count INTEGER,
    red_count INTEGER,
    summary_text TEXT
);

CREATE TABLE IF NOT EXISTS upload_queue (
    package_id TEXT PRIMARY KEY,
    event_id TEXT,
    mission_id TEXT,
    package_path TEXT,
    status TEXT,
    retry_count INTEGER,
    created_utc TEXT,
    last_attempt_utc TEXT,
    uploaded_utc TEXT,
    error_message TEXT
);

CREATE TABLE IF NOT EXISTS mission_transcript (
    transcript_id TEXT PRIMARY KEY,
    mission_id TEXT,
    timestamp_utc TEXT,
    event_type TEXT,
    payload_json TEXT
);
"""


def _utcnow() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


class MissionMemory:
    def __init__(self, db_path: Optional[str] = None, profile: Optional[dict] = None):
        if db_path is None:
            prof = profile if profile is not None else config_loader.load_yaml("mission_profile.yaml")
            db_name = prof.get("paths", {}).get("mission_db", "mission_events.db")
            db_path = config_loader.storage_path(db_name, profile=prof)
        self.db_path = db_path
        os.makedirs(os.path.dirname(os.path.abspath(self.db_path)), exist_ok=True)
        # Re-entrant lock serializes ALL access to the single connection. The mission
        # controller writes from the main ROS2 thread AND from background executor
        # threads (evidence packaging); SQLite connections are not safe to share across
        # threads without this. The lock + connection-as-context-manager (with self._conn:)
        # gives atomic commit/rollback and prevents the "no transaction is active" /
        # "not an error" failures seen under concurrent live load.
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.db_path, timeout=30.0, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            try:
                self._conn.execute("PRAGMA journal_mode=WAL;")
                self._conn.execute("PRAGMA busy_timeout=30000;")
            except sqlite3.Error:
                pass
            with self._conn:
                self._conn.executescript(_SCHEMA)

    def close(self):
        try:
            self._conn.close()
        except Exception:
            pass

    # ---- mission events ----
    def save_event(self, event: dict) -> str:
        """Persist a scored/handled event. Returns event_id.

        Expected keys (all optional except generated ones): mission_id, source, intent,
        tool_name, risk_level, score, confidence, adjusted_confidence, reasons (list),
        matched_rules (list), event_json (dict or str), evidence_package_path,
        operator_action.
        """
        event_id = event.get("event_id") or _new_id("evt")
        reasons = event.get("reasons", [])
        matched = event.get("matched_rules", [])
        raw = event.get("event_json", event)
        raw_str = raw if isinstance(raw, str) else json.dumps(raw, default=str)
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT OR REPLACE INTO mission_events
                   (event_id, mission_id, timestamp_utc, source, intent, tool_name,
                    risk_level, score, confidence, adjusted_confidence, reasons_json,
                    matched_rules_json, event_json, evidence_package_path, operator_action)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    event_id,
                    event.get("mission_id"),
                    event.get("timestamp_utc") or _utcnow(),
                    event.get("source"),
                    event.get("intent"),
                    event.get("tool_name"),
                    event.get("risk_level"),
                    event.get("score"),
                    event.get("confidence"),
                    event.get("adjusted_confidence"),
                    json.dumps(reasons, default=str),
                    json.dumps(matched, default=str),
                    raw_str,
                    event.get("evidence_package_path"),
                    event.get("operator_action"),
                ),
            )
        return event_id

    def set_operator_action(self, event_id: str, action: str) -> bool:
        with self._lock, self._conn:
            cur = self._conn.execute(
                "UPDATE mission_events SET operator_action=? WHERE event_id=?",
                (action, event_id),
            )
            return cur.rowcount > 0

    def recent_events(self, limit: int = 20, mission_id: Optional[str] = None) -> list:
        with self._lock:
            if mission_id:
                rows = self._conn.execute(
                    "SELECT * FROM mission_events WHERE mission_id=? ORDER BY timestamp_utc DESC LIMIT ?",
                    (mission_id, limit),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT * FROM mission_events ORDER BY timestamp_utc DESC LIMIT ?",
                    (limit,),
                ).fetchall()
        return [dict(r) for r in rows]

    def events_by_risk(self, levels=("yellow", "red"), limit: int = 50,
                       mission_id: Optional[str] = None) -> list:
        ph = ",".join("?" for _ in levels)
        params = list(levels)
        sql = f"SELECT * FROM mission_events WHERE risk_level IN ({ph})"
        if mission_id:
            sql += " AND mission_id=?"
            params.append(mission_id)
        sql += " ORDER BY timestamp_utc DESC LIMIT ?"
        params.append(limit)
        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def latest_event(self, mission_id: Optional[str] = None) -> Optional[dict]:
        ev = self.recent_events(limit=1, mission_id=mission_id)
        return ev[0] if ev else None

    # ---- track memory ----
    def upsert_track(self, track_key: str, mission_id: str, object_type: str,
                     object_color: str = "", last_zone: str = "",
                     metadata: Optional[dict] = None) -> dict:
        now = _utcnow()
        with self._lock, self._conn:
            existing = self._conn.execute(
                "SELECT * FROM track_memory WHERE track_key=?", (track_key,)
            ).fetchone()
            if existing:
                seen = (existing["seen_count"] or 0) + 1
                self._conn.execute(
                    """UPDATE track_memory SET last_seen_utc=?, seen_count=?, last_zone=?,
                       object_color=COALESCE(NULLIF(?, ''), object_color),
                       metadata_json=? WHERE track_key=?""",
                    (now, seen, last_zone or existing["last_zone"], object_color,
                     json.dumps(metadata or {}, default=str), track_key),
                )
            else:
                seen = 1
                self._conn.execute(
                    """INSERT INTO track_memory
                       (track_key, mission_id, object_type, object_color, first_seen_utc,
                        last_seen_utc, seen_count, last_zone, metadata_json)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    (track_key, mission_id, object_type, object_color, now, now, seen,
                     last_zone, json.dumps(metadata or {}, default=str)),
                )
        return {"track_key": track_key, "seen_count": seen}

    def get_track(self, track_key: str) -> Optional[dict]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM track_memory WHERE track_key=?", (track_key,)
            ).fetchone()
        return dict(row) if row else None

    # ---- summaries ----
    def save_summary(self, mission_id: str, window_start: str, window_end: str,
                     green: int, yellow: int, red: int, text: str) -> str:
        sid = _new_id("sum")
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT INTO mission_summaries
                   (summary_id, mission_id, window_start_utc, window_end_utc,
                    green_count, yellow_count, red_count, summary_text)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (sid, mission_id, window_start, window_end, green, yellow, red, text),
            )
        return sid

    # ---- upload queue (rows; the worker logic lives in upload_queue.py, Phase 2) ----
    def enqueue_upload(self, event_id: str, mission_id: str, package_path: str) -> str:
        pkg_id = _new_id("pkg")
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT INTO upload_queue
                   (package_id, event_id, mission_id, package_path, status, retry_count,
                    created_utc, last_attempt_utc, uploaded_utc, error_message)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (pkg_id, event_id, mission_id, package_path, "pending", 0,
                 _utcnow(), None, None, None),
            )
        return pkg_id

    def pending_uploads(self) -> list:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM upload_queue WHERE status IN ('pending','failed') ORDER BY created_utc",
            ).fetchall()
        return [dict(r) for r in rows]

    # ---- transcript (replay/recovery, §25) ----
    def append_transcript(self, mission_id: str, event_type: str, payload: dict) -> str:
        tid = _new_id("tr")
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT INTO mission_transcript
                   (transcript_id, mission_id, timestamp_utc, event_type, payload_json)
                   VALUES (?,?,?,?,?)""",
                (tid, mission_id, _utcnow(), event_type, json.dumps(payload, default=str)),
            )
        return tid

    def transcript(self, mission_id: Optional[str] = None, limit: int = 200) -> list:
        with self._lock:
            if mission_id:
                rows = self._conn.execute(
                    "SELECT * FROM mission_transcript WHERE mission_id=? ORDER BY timestamp_utc LIMIT ?",
                    (mission_id, limit),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT * FROM mission_transcript ORDER BY timestamp_utc LIMIT ?", (limit,)
                ).fetchall()
        return [dict(r) for r in rows]
