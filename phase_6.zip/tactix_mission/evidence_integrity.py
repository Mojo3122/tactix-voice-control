"""evidence_integrity.py — Tickets 15, 16 (plan §5.11, §11.4).

Chain-of-custody integrity for evidence packages:
  - SHA-256 every file in a package and write file_hashes.json
  - compute the manifest hash AFTER file hashes are written
  - optionally sign the manifest with a device key (off by default in v1)
  - expose verification helpers the command center (MCT) reuses

No external crypto dependency is required for hashing (stdlib hashlib). Signing uses
PyNaCl/cryptography ONLY if signing.enabled is true AND the library is installed; if not,
the package is still hashed and marked unsigned (graceful, never crashes).
"""

from __future__ import annotations

import hashlib
import json
import os
from typing import Optional

from . import config_loader

_CHUNK = 1024 * 1024  # 1 MB streaming read (keeps memory flat for big clips)


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(_CHUNK), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def hash_package_files(package_dir: str, exclude=("file_hashes.json", "manifest.sig")) -> dict:
    """Hash every regular file in the package dir (non-recursive), excluding integrity
    artifacts themselves. Returns {filename: 'sha256:...'} and writes file_hashes.json.
    """
    hashes = {}
    for name in sorted(os.listdir(package_dir)):
        if name in exclude:
            continue
        full = os.path.join(package_dir, name)
        if os.path.isfile(full):
            hashes[name] = sha256_file(full)
    out = os.path.join(package_dir, "file_hashes.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(hashes, fh, indent=2, sort_keys=True)
    return hashes


def compute_manifest_hash(manifest: dict) -> str:
    """Deterministic hash of the manifest content (sorted keys, compact)."""
    payload = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha256_bytes(payload)


def sign_manifest(manifest_hash: str, signing_cfg: dict, package_dir: str) -> dict:
    """Optionally sign the manifest hash. Returns a signature descriptor dict.

    Never raises on missing key/lib — returns a descriptor with required/available flags
    so the packager and MCT can reason about trust level.
    """
    if not signing_cfg.get("enabled", False):
        return {"signed": False, "required": False, "reason": "signing disabled"}

    key_path = signing_cfg.get("private_key_path", "")
    if not key_path or not os.path.exists(key_path):
        return {"signed": False, "required": True, "reason": "private key not found"}

    try:
        # Lazy import; only needed when signing is actually enabled.
        from nacl.signing import SigningKey  # type: ignore
        with open(key_path, "rb") as fh:
            sk = SigningKey(fh.read())
        sig = sk.sign(manifest_hash.encode("utf-8")).signature
        sig_path = os.path.join(package_dir, "manifest.sig")
        with open(sig_path, "wb") as fh:
            fh.write(sig)
        return {
            "signed": True,
            "required": True,
            "algorithm": signing_cfg.get("algorithm", "ed25519"),
            "key_id": signing_cfg.get("key_id", ""),
            "signature_file": "manifest.sig",
        }
    except ImportError:
        return {"signed": False, "required": True, "reason": "PyNaCl not installed"}
    except Exception as e:  # pragma: no cover - defensive
        return {"signed": False, "required": True, "reason": f"signing error: {e}"}


# ---- verification (reused by the command center / MCT in Phase 6) --------------------
def verify_package(package_dir: str) -> dict:
    """Recompute hashes and compare to file_hashes.json. Returns a verification report.

    status: 'verified' | 'failed' | 'missing_hashes'
    Per §11.6: failures remain reviewable but are clearly marked not trusted.
    """
    hashes_path = os.path.join(package_dir, "file_hashes.json")
    if not os.path.exists(hashes_path):
        return {"status": "missing_hashes", "mismatches": [], "checked": 0}

    with open(hashes_path, "r", encoding="utf-8") as fh:
        recorded = json.load(fh)

    mismatches = []
    checked = 0
    for name, recorded_hash in recorded.items():
        full = os.path.join(package_dir, name)
        if not os.path.isfile(full):
            mismatches.append({"file": name, "reason": "missing"})
            continue
        checked += 1
        actual = sha256_file(full)
        if actual != recorded_hash:
            mismatches.append({"file": name, "reason": "hash mismatch"})

    status = "verified" if not mismatches else "failed"
    return {"status": status, "mismatches": mismatches, "checked": checked}


def load_signing_config(cfg: Optional[dict] = None) -> dict:
    data = cfg if cfg is not None else config_loader.load_yaml("upload_config.yaml")
    return data.get("signing", {}) or {}
