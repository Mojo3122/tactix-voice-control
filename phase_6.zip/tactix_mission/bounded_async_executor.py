"""bounded_async_executor.py — plan §17, §24.2, §24.3.

Runs slow/background work (evidence packaging, hashing, uploads, summaries) OFF the
realtime path so the mission layer can never starve the camera/inference loop or the
PTZ control loop. This is the core resource-safety guarantee for the Jetson.

Design:
  - A fixed, small pool of worker threads (default 2) — bounded CPU use.
  - A BOUNDED queue (default 64). When full, new background work is REJECTED (returns
    False) rather than queued without limit (§24.3 — backpressure, no unbounded growth).
  - Realtime work never goes here; it runs inline in the caller. This executor is only
    for background/approval_gated/blocking-tolerant tasks.
  - Graceful shutdown drains in-flight tasks up to a timeout.

It is intentionally thread-based (not asyncio) so it composes with the existing
synchronous ROS2/Flask code without forcing an event loop into your pipeline.
"""

from __future__ import annotations

import queue
import threading
import time
import traceback
from typing import Callable, Optional


class _Task:
    __slots__ = ("fn", "args", "kwargs", "name", "enqueued_at", "on_done", "on_error")

    def __init__(self, fn, args, kwargs, name, on_done, on_error):
        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        self.name = name
        self.enqueued_at = time.time()
        self.on_done = on_done
        self.on_error = on_error


class BoundedAsyncExecutor:
    def __init__(self, workers: int = 2, max_queue: int = 64, name: str = "tactix-bg"):
        self.workers = max(1, workers)
        self.max_queue = max(1, max_queue)
        self._q: "queue.Queue[_Task]" = queue.Queue(maxsize=self.max_queue)
        self._threads: list = []
        self._running = False
        self._name = name
        # lightweight metrics (read by health_monitor)
        self._lock = threading.Lock()
        self.submitted = 0
        self.completed = 0
        self.failed = 0
        self.rejected = 0
        self._max_seen_depth = 0

    # ---- lifecycle ----
    def start(self):
        if self._running:
            return
        self._running = True
        for i in range(self.workers):
            t = threading.Thread(target=self._worker_loop, name=f"{self._name}-{i}", daemon=True)
            t.start()
            self._threads.append(t)

    def shutdown(self, drain: bool = True, timeout: float = 5.0):
        """Stop accepting work; optionally wait for the queue to drain."""
        if drain:
            deadline = time.time() + timeout
            while not self._q.empty() and time.time() < deadline:
                time.sleep(0.02)
        self._running = False
        # unblock workers
        for _ in self._threads:
            try:
                self._q.put_nowait(None)  # poison pill
            except queue.Full:
                pass
        for t in self._threads:
            t.join(timeout=1.0)
        self._threads = []

    # ---- submit ----
    def submit(self, fn: Callable, *args, name: str = "task",
               on_done: Optional[Callable] = None,
               on_error: Optional[Callable] = None, **kwargs) -> bool:
        """Queue background work. Returns True if accepted, False if rejected (queue full
        or executor not running). NEVER blocks the caller — realtime safe.
        """
        if not self._running:
            return False
        task = _Task(fn, args, kwargs, name, on_done, on_error)
        try:
            self._q.put_nowait(task)
        except queue.Full:
            with self._lock:
                self.rejected += 1
            return False
        with self._lock:
            self.submitted += 1
            depth = self._q.qsize()
            if depth > self._max_seen_depth:
                self._max_seen_depth = depth
        return True

    # ---- worker ----
    def _worker_loop(self):
        while self._running:
            try:
                task = self._q.get(timeout=0.2)
            except queue.Empty:
                continue
            if task is None:  # poison pill
                self._q.task_done()
                break
            try:
                result = task.fn(*task.args, **task.kwargs)
                with self._lock:
                    self.completed += 1
                if task.on_done:
                    try:
                        task.on_done(result)
                    except Exception:
                        pass
            except Exception as e:  # background task failure must not kill the worker
                with self._lock:
                    self.failed += 1
                if task.on_error:
                    try:
                        task.on_error(e)
                    except Exception:
                        pass
                else:
                    # last-resort: don't crash; record to stderr-style trace
                    traceback.print_exc()
            finally:
                self._q.task_done()

    # ---- introspection ----
    def stats(self) -> dict:
        with self._lock:
            return {
                "running": self._running,
                "workers": self.workers,
                "queue_depth": self._q.qsize(),
                "max_queue": self.max_queue,
                "max_seen_depth": self._max_seen_depth,
                "submitted": self.submitted,
                "completed": self.completed,
                "failed": self.failed,
                "rejected": self.rejected,
            }

    @property
    def is_running(self) -> bool:
        return self._running
