"""clip_finder.py — Phase 5.1.

Finds the auto-record clip that goes with a detection event by locating the NEWEST file
in the matching gallery/<mode>/auto-record/ folder (the bridge already wrote it there).
This avoids any timing/endpoint coupling with the bridge — it just reads files on disk.

A clip is only returned if it is "fresh" (modified within freshness_seconds of now), so a
stale clip from an earlier detection is never wrongly attached. If nothing fresh is found,
returns None and the package is still created without a clip (never blocks).
"""

from __future__ import annotations

import os
import time
from typing import Optional

from . import config_loader

_VIDEO_EXTS = (".mkv", ".mp4", ".avi", ".mov")


class ClipFinder:
    def __init__(self, profile: Optional[dict] = None):
        self.profile = profile if profile is not None else config_loader.load_yaml("mission_profile.yaml")
        edge = self.profile.get("edge_sources", {})
        self.gallery_base = edge.get("record_gallery_base",
                                     "/home/tds-jetson3/cam/workflow_29_04_2026/gallery")
        self.auto_sub = edge.get("auto_record_subfolder", "auto-record")
        clip_cfg = self.profile.get("clip_link", {})
        self.enabled = clip_cfg.get("enabled", True)
        self.freshness = float(clip_cfg.get("freshness_seconds", 20))
        self.stability_wait = float(clip_cfg.get("stability_wait_seconds", 8.0))
        self.stability_poll = float(clip_cfg.get("stability_poll_seconds", 0.5))
        self.stability_quiet = float(clip_cfg.get("stability_quiet_seconds", 1.0))
        self.sensor_to_mode = clip_cfg.get("sensor_to_mode", {"rgb": "RGB", "thermal": "thermal"})

    def folder_for_sensor(self, sensor: str) -> Optional[str]:
        mode = self.sensor_to_mode.get((sensor or "").lower())
        if not mode:
            return None
        return os.path.join(self.gallery_base, mode, self.auto_sub)

    def newest_fresh_clip(self, sensor: str, now: Optional[float] = None) -> Optional[str]:
        """Return the path to the newest fresh video file for this sensor, or None."""
        if not self.enabled:
            return None
        folder = self.folder_for_sensor(sensor)
        if not folder or not os.path.isdir(folder):
            return None
        now = now if now is not None else time.time()
        newest_path = None
        newest_mtime = -1.0
        try:
            for name in os.listdir(folder):
                if not name.lower().endswith(_VIDEO_EXTS):
                    continue
                full = os.path.join(folder, name)
                if not os.path.isfile(full):
                    continue
                mtime = os.path.getmtime(full)
                if mtime > newest_mtime:
                    newest_mtime = mtime
                    newest_path = full
        except OSError:
            return None
        if newest_path is None:
            return None
        # freshness gate
        if self.freshness > 0 and (now - newest_mtime) > self.freshness:
            return None
        return newest_path

    def wait_until_stable(self, path: str) -> bool:
        """Block until the file size stops changing (and is non-empty), or until
        stability_wait_seconds elapses. Returns True if the file is stable & non-empty.

        This is what prevents hashing a clip while ffmpeg is still writing it (which
        produced the sha256-of-empty-bytes mismatch). Safe to call from a background
        worker — it only sleeps, never touches the realtime path.
        """
        if not path or not os.path.isfile(path):
            return False
        deadline = time.time() + self.stability_wait
        last_size = -1
        last_change = time.time()
        while time.time() < deadline:
            try:
                size = os.path.getsize(path)
            except OSError:
                return False
            if size != last_size:
                last_size = size
                last_change = time.time()
            elif size > 0 and (time.time() - last_change) >= self.stability_quiet:
                return True  # size unchanged for the quiet window and non-empty -> done
            time.sleep(self.stability_poll)
        # timed out: accept only if it ended up non-empty
        try:
            return os.path.getsize(path) > 0
        except OSError:
            return False
