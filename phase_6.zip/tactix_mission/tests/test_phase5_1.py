"""test_phase5_1.py — Phase 5.1 tests (per-reason cooldown + clip linking).

Run:  python -m unittest tactix_mission.tests.test_phase5_1 -v
"""

import json
import os
import sys
import tempfile
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from tactix_mission import (
    mission_node as MN,
    mission_controller as MC,
    mission_memory as MM,
    clip_finder as CF,
    config_loader,
)


def _profile(tmp, **over):
    prof = json.loads(json.dumps(config_loader.load_yaml("mission_profile.yaml")))
    prof["paths"]["storage_root"] = tmp
    prof.update(over)
    return prof


def _runner(tmp, profile):
    mem = MM.MissionMemory(db_path=os.path.join(tmp, "m.db"))
    finder = CF.ClipFinder(profile=profile)
    ctrl = MC.MissionController(profile=profile, memory=mem,
                                clip_stability_waiter=finder.wait_until_stable)
    return MN.MissionNodeRunner(controller=ctrl, profile=profile)


class TestClipFinder(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        # build a fake gallery/RGB/auto-record with a clip
        self.gallery = os.path.join(self.tmp, "gallery")
        self.rgb_auto = os.path.join(self.gallery, "RGB", "auto-record")
        os.makedirs(self.rgb_auto, exist_ok=True)
        self.clip = os.path.join(self.rgb_auto, "20260611_clip1.mkv")
        with open(self.clip, "wb") as f:
            f.write(b"video")
        prof = _profile(self.tmp)
        prof["edge_sources"]["record_gallery_base"] = self.gallery
        self.finder = CF.ClipFinder(profile=prof)

    def test_finds_fresh_clip(self):
        path = self.finder.newest_fresh_clip("rgb")
        self.assertEqual(path, self.clip)

    def test_stale_clip_rejected(self):
        old = time.time() - 9999
        os.utime(self.clip, (old, old))
        self.assertIsNone(self.finder.newest_fresh_clip("rgb"))

    def test_unknown_sensor_none(self):
        self.assertIsNone(self.finder.newest_fresh_clip("lidar"))

    def test_missing_folder_none(self):
        self.assertIsNone(self.finder.newest_fresh_clip("thermal"))  # no thermal folder


class TestCooldown(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.profile = _profile(self.tmp, event_cooldown_seconds=8)
        self.runner = _runner(self.tmp, self.profile)

    def tearDown(self):
        self.runner.shutdown()

    def test_repeated_reason_suppressed_within_cooldown(self):
        first = self.runner.on_auto_record_trigger("weapon_rgb")
        # immediate repeat of a DIFFERENT string content to bypass the 2s dedup,
        # but same reason token -> should be cooldown-suppressed for packaging
        time.sleep(0.01)
        self.runner._last_trigger = ""  # bypass identical-string dedup
        second = self.runner.on_auto_record_trigger("weapon_rgb")
        self.assertTrue(first[0]["packaged"])
        self.assertFalse(second[0]["packaged"])
        self.assertTrue(second[0]["cooldown_suppressed"])

    def test_event_still_logged_when_suppressed(self):
        self.runner.on_auto_record_trigger("weapon_rgb")
        self.runner._last_trigger = ""
        self.runner.on_auto_record_trigger("weapon_rgb")
        # both events should be in the DB even though only one packaged
        events = self.runner.controller.memory.recent_events(limit=10)
        self.assertGreaterEqual(len(events), 2)

    def test_different_reasons_not_suppressed(self):
        r1 = self.runner.on_auto_record_trigger("weapon_rgb")
        self.runner._last_trigger = ""
        r2 = self.runner.on_auto_record_trigger("crouching_thermal")
        self.assertTrue(r1[0]["packaged"])
        self.assertTrue(r2[0]["packaged"])  # different reason token -> own cooldown

    def test_cooldown_zero_disables(self):
        prof = _profile(self.tmp, event_cooldown_seconds=0)
        runner = _runner(self.tmp, prof)
        runner.on_auto_record_trigger("weapon_rgb")
        runner._last_trigger = ""
        second = runner.on_auto_record_trigger("weapon_rgb")
        self.assertTrue(second[0]["packaged"])  # no suppression when cooldown is 0
        runner.shutdown()


class TestClipLinkedIntoPackage(unittest.TestCase):
    def test_clip_appears_in_package(self):
        tmp = tempfile.mkdtemp()
        gallery = os.path.join(tmp, "gallery")
        rgb_auto = os.path.join(gallery, "RGB", "auto-record")
        os.makedirs(rgb_auto, exist_ok=True)
        clip = os.path.join(rgb_auto, "clip.mkv")
        with open(clip, "wb") as f:
            f.write(b"video-bytes")
        prof = _profile(tmp)
        prof["edge_sources"]["record_gallery_base"] = gallery
        runner = _runner(tmp, prof)
        results = runner.on_auto_record_trigger("weapon_rgb")
        self.assertTrue(results[0]["clip_linked"])
        # wait for background packaging
        deadline = time.time() + 3
        while time.time() < deadline:
            s = runner.controller.executor.stats()
            if s["submitted"] == s["completed"] + s["failed"] and s["queue_depth"] == 0:
                break
            time.sleep(0.02)
        ev = runner.controller.memory.recent_events(limit=1)[0]
        pkg = ev["evidence_package_path"]
        self.assertTrue(pkg and os.path.exists(os.path.join(pkg, "clip.mp4")))
        runner.shutdown()


if __name__ == "__main__":
    unittest.main(verbosity=2)


class TestClipStability(unittest.TestCase):
    """Phase 5.2: clip must be fully written (stable, non-empty) before hashing."""
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        prof = _profile(self.tmp)
        prof["clip_link"]["stability_wait_seconds"] = 3.0
        prof["clip_link"]["stability_poll_seconds"] = 0.05
        prof["clip_link"]["stability_quiet_seconds"] = 0.2
        self.finder = CF.ClipFinder(profile=prof)

    def test_empty_file_not_stable(self):
        p = os.path.join(self.tmp, "empty.mkv")
        open(p, "wb").close()  # 0 bytes
        # with a short wait, an always-empty file must be rejected
        self.assertFalse(self.finder.wait_until_stable(p))

    def test_growing_then_stable(self):
        import threading as _th
        p = os.path.join(self.tmp, "growing.mkv")
        open(p, "wb").close()
        def writer():
            for i in range(5):
                time.sleep(0.1)
                with open(p, "ab") as f:
                    f.write(b"x" * 1000)
            # then stop -> file becomes stable
        t = _th.Thread(target=writer); t.start()
        ok = self.finder.wait_until_stable(p)
        t.join()
        self.assertTrue(ok)
        self.assertGreater(os.path.getsize(p), 0)

    def test_stable_hash_matches_final(self):
        # a fully-written file is stable immediately and its size is non-zero
        p = os.path.join(self.tmp, "done.mkv")
        with open(p, "wb") as f:
            f.write(b"complete video bytes" * 50)
        self.assertTrue(self.finder.wait_until_stable(p))


class TestUnstableClipOmittedFromPackage(unittest.TestCase):
    """If the clip never stabilizes, the package is still built WITHOUT a bad-hash clip."""
    def test_empty_clip_omitted(self):
        tmp = tempfile.mkdtemp()
        gallery = os.path.join(tmp, "gallery")
        rgb_auto = os.path.join(gallery, "RGB", "auto-record")
        os.makedirs(rgb_auto, exist_ok=True)
        empty = os.path.join(rgb_auto, "empty.mkv")
        open(empty, "wb").close()  # stays 0 bytes
        prof = _profile(tmp)
        prof["edge_sources"]["record_gallery_base"] = gallery
        prof["clip_link"]["stability_wait_seconds"] = 0.5
        prof["clip_link"]["stability_poll_seconds"] = 0.05
        prof["clip_link"]["stability_quiet_seconds"] = 0.1
        runner = _runner(tmp, prof)
        runner.on_auto_record_trigger("weapon_rgb")
        deadline = time.time() + 4
        while time.time() < deadline:
            s = runner.controller.executor.stats()
            if s["submitted"] == s["completed"] + s["failed"] and s["queue_depth"] == 0:
                break
            time.sleep(0.02)
        ev = runner.controller.memory.recent_events(limit=1)[0]
        pkg = ev["evidence_package_path"]
        # package exists, but the empty clip was omitted (no clip.mp4)
        self.assertTrue(pkg and os.path.isdir(pkg))
        self.assertFalse(os.path.exists(os.path.join(pkg, "clip.mp4")))
        runner.shutdown()
