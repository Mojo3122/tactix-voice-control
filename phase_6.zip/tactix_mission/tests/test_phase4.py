"""test_phase4.py — Phase 4 tests (plan §16.1, §20, §29 parity).

Run:  python -m unittest tactix_mission.tests.test_phase4 -v

Includes PARITY tests (§29): the wired-together controller must produce the same
decisions (intent, permission level, risk level) as calling the individual modules
directly. This guards against the controller silently diverging from the proven pieces.
"""

import json
import os
import sys
import tempfile
import threading
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from tactix_mission import (
    mission_controller as MC,
    intent_normalizer as IN,
    permission_engine as PE,
    tool_registry as TR,
    risk_scorer as RS,
    mission_context_builder as MCB,
    mission_memory as MM,
    config_loader,
)


def _ctrl(tmp, **kwargs):
    profile = json.loads(json.dumps(config_loader.load_yaml("mission_profile.yaml")))
    profile["paths"]["storage_root"] = tmp
    mem = MM.MissionMemory(db_path=os.path.join(tmp, "mission_events.db"))
    return MC.MissionController(profile=profile, memory=mem, **kwargs)


def _wait_executor_idle(ctrl, timeout=3.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        s = ctrl.executor.stats()
        if s["queue_depth"] == 0 and s["submitted"] == (s["completed"] + s["failed"]):
            return True
        time.sleep(0.02)
    return False


class TestCommandFlow(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.ctrl = _ctrl(self.tmp)

    def tearDown(self):
        self.ctrl.shutdown()

    def test_auto_command_executes(self):
        res = self.ctrl.handle_command("scan my 2 o'clock")
        self.assertEqual(res["status"], "success")
        self.assertEqual(res["tool"], "scan_direction")
        self.assertTrue(res["execution"]["fake"])

    def test_unknown_command_rejected(self):
        res = self.ctrl.handle_command("what's the weather")
        self.assertEqual(res["status"], "rejected")

    def test_blocked_command(self):
        # there is no direct intent for delete_evidence; simulate via registry path
        decision = self.ctrl.permissions.check("delete_evidence")
        self.assertEqual(decision.level, "blocked")

    def test_approval_required_without_callback_awaits(self):
        res = self.ctrl.handle_command("send latest clip to command")
        self.assertEqual(res["status"], "awaiting_approval")
        self.assertEqual(res["tool"], "share_latest_clip")

    def test_approval_required_with_yes_executes(self):
        ctrl = _ctrl(tempfile.mkdtemp(), approval_callback=lambda t, p, prompt: True)
        res = ctrl.handle_command("send latest clip to command")
        self.assertEqual(res["status"], "success")
        ctrl.shutdown()

    def test_summary_intent(self):
        self.ctrl.handle_command("scan 360")
        res = self.ctrl.handle_command("summarize patrol")
        self.assertEqual(res["status"], "success")
        self.assertIn("counts", res)

    def test_mark_false_alarm(self):
        self.ctrl.handle_command("scan 360")
        res = self.ctrl.handle_command("mark false alarm")
        self.assertEqual(res["status"], "success")


class TestDetectionFlow(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.ctrl = _ctrl(self.tmp)

    def tearDown(self):
        self.ctrl.shutdown()

    def test_green_detection_not_packaged(self):
        res = self.ctrl.handle_detection({"object_type": "vehicle", "confidence": 0.9})
        self.assertEqual(res["risk_level"], "green")
        self.assertFalse(res["packaged"])

    def test_red_detection_packaged_in_background(self):
        res = self.ctrl.handle_detection({"object_type": "weapon", "confidence": 0.95})
        self.assertEqual(res["risk_level"], "red")
        self.assertTrue(res["packaged"])
        self.assertTrue(res.get("background_accepted"))
        self.assertTrue(_wait_executor_idle(self.ctrl))
        # package path recorded + upload queued
        ev = self.ctrl.memory.recent_events(limit=1)[0]
        self.assertTrue(ev["evidence_package_path"])
        self.assertGreaterEqual(sum(self.ctrl.uploads.status_counts().values()), 1)

    def test_detection_does_not_block_caller(self):
        # handle_detection should return quickly even though packaging is heavy
        t0 = time.time()
        self.ctrl.handle_detection({"object_type": "weapon", "confidence": 0.95})
        elapsed_ms = (time.time() - t0) * 1000
        self.assertLess(elapsed_ms, 200)  # generous bound; packaging is off-thread
        _wait_executor_idle(self.ctrl)

    def test_after_hours_vehicle_yellow_via_context(self):
        import datetime as dt
        night = dt.datetime(2026, 1, 1, 23, 0)
        res = self.ctrl.handle_detection(
            {"object_type": "vehicle", "zone": "equipment_yard", "duration_sec": 96,
             "confidence": 0.87}, now=night)
        # equipment_yard is sensitive in the demo playbook + after hours => yellow
        self.assertEqual(res["risk_level"], "yellow")
        _wait_executor_idle(self.ctrl)


class TestParityWithModules(unittest.TestCase):
    """§29 — controller decisions must match the standalone modules."""
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.ctrl = _ctrl(self.tmp)

    def tearDown(self):
        self.ctrl.shutdown()

    def test_intent_parity(self):
        for cmd in ["scan my 2 o'clock", "switch to thermal", "track that car",
                    "send latest clip to command", "summarize patrol"]:
            module_intent = IN.normalize(cmd)["intent"]
            self.ctrl.handle_command(cmd)
            tr = self.ctrl.memory.transcript(self.ctrl.mission_id)
            # the most recent command_received transcript should carry the same intent
            received = [t for t in tr if t["event_type"] == "command_received"]
            last = json.loads(received[-1]["payload_json"])
            self.assertEqual(last["intent"]["intent"], module_intent, f"mismatch for {cmd!r}")

    def test_permission_parity(self):
        reg = TR.ToolRegistry()
        eng = PE.PermissionEngine(registry=reg)
        for tool in ["scan_360", "share_latest_clip", "delete_evidence"]:
            self.assertEqual(self.ctrl.permissions.check(tool).level, eng.check(tool).level)

    def test_risk_parity(self):
        builder = MCB.MissionContextBuilder(profile=self.ctrl.profile)
        scorer = RS.RiskScorer()
        import datetime as dt
        night = dt.datetime(2026, 1, 1, 23, 0)
        raw = {"object_type": "vehicle", "zone": "equipment_yard", "duration_sec": 96,
               "confidence": 0.87}
        module_level = scorer.score_event(builder.enrich_event(raw, now=night))["risk_level"]
        ctrl_res = self.ctrl.handle_detection(dict(raw), now=night)
        self.assertEqual(ctrl_res["risk_level"], module_level)
        _wait_executor_idle(self.ctrl)


class TestControllerHealthAndManifest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.ctrl = _ctrl(self.tmp)

    def tearDown(self):
        self.ctrl.shutdown()

    def test_health_report(self):
        rep = self.ctrl.health_report()
        self.assertIn(rep["overall"], ("ok", "degraded", "unhealthy"))

    def test_capability_manifest_written(self):
        path = self.ctrl.write_capability_manifest()
        self.assertTrue(os.path.exists(path))


class TestRealExecutorInjection(unittest.TestCase):
    """Proves Phase 5 can swap in a real executor without changing controller logic."""
    def test_injected_executor_used(self):
        tmp = tempfile.mkdtemp()
        calls = {}
        def fake_http(name, params, spec):
            calls["name"] = name
            calls["endpoint"] = spec.get("endpoint")
            return {"status": "success", "message": f"REAL CALL {spec.get('endpoint')}"}
        ctrl = _ctrl(tmp, tool_executor=fake_http)
        res = ctrl.handle_command("scan 360")
        self.assertEqual(res["status"], "success")
        self.assertEqual(calls["endpoint"], "/scan")
        self.assertIn("REAL CALL", res["execution"]["message"])
        ctrl.shutdown()


if __name__ == "__main__":
    unittest.main(verbosity=2)


class TestConcurrentDetections(unittest.TestCase):
    """Regression: many concurrent detections must not corrupt SQLite (live-load bug)."""
    def test_no_concurrency_errors_under_load(self):
        import threading as _th
        tmp = tempfile.mkdtemp()
        ctrl = _ctrl(tmp)
        errors = []
        def fire(i):
            try:
                obj = {"object_type": "weapon" if i % 3 == 0 else "person",
                       "posture": "crouching", "confidence": 0.9}
                ctrl.handle_detection(obj)
            except Exception as e:
                errors.append(repr(e))
        threads = [_th.Thread(target=fire, args=(i,)) for i in range(120)]
        for t in threads: t.start()
        for t in threads: t.join()
        _wait_executor_idle(ctrl, timeout=5.0)
        self.assertEqual(errors, [], f"concurrency errors: {errors[:3]}")
        self.assertEqual(len(ctrl.memory.recent_events(limit=500)), 120)
        ctrl.shutdown()
