"""test_phase1.py — Phase 1 unit + integration tests (plan §16.1, §14, §15 acceptance).

Run with:  python -m pytest tactix_mission/tests/test_phase1.py -v
       or:  python -m unittest tactix_mission.tests.test_phase1 -v

Covers each Ticket's acceptance criteria plus the high/low-confidence, cross-sensor,
and repeated-sighting risk cases (§9.4), and the three first workflows (§14).
"""

import os
import sys
import tempfile
import unittest

# allow running as a plain script too
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from tactix_mission import (
    intent_normalizer as IN,
    tool_registry as TR,
    permission_engine as PE,
    mission_memory as MM,
    risk_scorer as RS,
    summary_generator as SG,
    reason_event_adapter as REA,
)


class TestIntentNormalizer(unittest.TestCase):
    def test_scan_direction(self):
        r = IN.normalize("Scan my 2 o'clock")
        self.assertEqual(r["intent"], "scan_direction")
        self.assertEqual(r["parameters"]["direction"], "2_oclock")

    def test_scan_direction_word(self):
        r = IN.normalize("eagle scan my two oclock")
        self.assertEqual(r["intent"], "scan_direction")
        self.assertEqual(r["parameters"]["direction"], "2_oclock")

    def test_scan_360(self):
        self.assertEqual(IN.normalize("Scan 360")["intent"], "scan_360")
        self.assertEqual(IN.normalize("do a full scan around")["intent"], "scan_360")

    def test_switch_modes(self):
        self.assertEqual(IN.normalize("switch to thermal")["intent"], "switch_thermal")
        self.assertEqual(IN.normalize("go back to rgb")["intent"], "switch_rgb")

    def test_track_and_stop(self):
        r = IN.normalize("track that vehicle")
        self.assertEqual(r["intent"], "track_object")
        self.assertEqual(r["parameters"]["object_type"], "vehicle")
        r2 = IN.normalize("track person two")
        self.assertEqual(r2["parameters"]["index"], 2)
        self.assertEqual(IN.normalize("stop tracking")["intent"], "stop_tracking")

    def test_share_clip_requires_approval_hint(self):
        r = IN.normalize("send latest clip to command")
        self.assertEqual(r["intent"], "share_latest_clip")
        self.assertTrue(r["requires_approval"])

    def test_summaries(self):
        self.assertEqual(IN.normalize("summarize patrol")["intent"], "summarize_patrol")
        r = IN.normalize("give me a recap of the last 5 minutes")
        self.assertEqual(r["intent"], "summarize_last_minutes")
        self.assertEqual(r["parameters"]["minutes"], 5)

    def test_false_alarm_and_save(self):
        self.assertEqual(IN.normalize("mark this as false alarm")["intent"], "mark_false_alarm")
        self.assertEqual(IN.normalize("save clip")["intent"], "save_clip")

    def test_unknown(self):
        self.assertEqual(IN.normalize("what's the weather")["intent"], "unknown")
        self.assertEqual(IN.normalize("")["intent"], "unknown")


class TestToolRegistry(unittest.TestCase):
    def setUp(self):
        self.reg = TR.ToolRegistry()

    def test_known_lookup(self):
        self.assertTrue(self.reg.has_tool("scan_360"))
        md = self.reg.metadata("scan_360")
        self.assertEqual(md["permission"], "auto")
        self.assertIn("endpoint", md)

    def test_unknown_rejected(self):
        res = self.reg.execute("nonexistent_tool")
        self.assertEqual(res["status"], "rejected")

    def test_blocked_type(self):
        res = self.reg.execute("delete_evidence")
        self.assertEqual(res["status"], "blocked")

    def test_fake_execution(self):
        res = self.reg.execute("scan_direction", {"direction": "2_oclock"})
        self.assertEqual(res["status"], "success")
        self.assertTrue(res["fake"])
        self.assertIn("2_oclock", res["message"])

    def test_custom_executor(self):
        def fake_http(name, params, spec):
            return {"status": "success", "message": f"HTTP {spec.get('endpoint')}"}
        res = self.reg.execute("scan_360", {}, executor=fake_http)
        self.assertEqual(res["message"], "HTTP /scan")
        self.assertEqual(res["tool"], "scan_360")


class TestPermissionEngine(unittest.TestCase):
    def setUp(self):
        self.reg = TR.ToolRegistry()
        self.eng = PE.PermissionEngine(registry=self.reg)

    def test_levels(self):
        self.assertEqual(self.eng.check("scan_360").level, "auto")
        self.assertEqual(self.eng.check("share_latest_clip").level, "approval_required")
        self.assertEqual(self.eng.check("delete_evidence").level, "blocked")

    def test_hard_block_not_overridable(self):
        # even if someone sets delete_evidence to auto in the explicit map, hard_blocked wins
        eng = PE.PermissionEngine(
            permissions={"hard_blocked": ["delete_evidence"],
                         "permissions": {"delete_evidence": "auto"},
                         "default_permission": "approval_required"},
            registry=self.reg,
        )
        self.assertEqual(eng.check("delete_evidence").level, "blocked")

    def test_unknown_defaults_failsafe(self):
        self.assertEqual(self.eng.check("totally_unknown_tool").level, "approval_required")

    def test_decisions_logged(self):
        self.eng.check("scan_360")
        self.eng.check("share_latest_clip")
        self.assertEqual(len(self.eng.decisions), 2)


class TestMissionMemory(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.tmp.close()
        self.mem = MM.MissionMemory(db_path=self.tmp.name)

    def tearDown(self):
        self.mem.close()
        os.unlink(self.tmp.name)

    def test_save_and_survive_restart(self):
        eid = self.mem.save_event({
            "mission_id": "m1", "risk_level": "yellow", "score": 50,
            "reasons": ["after hours"], "event_json": {"object_type": "vehicle"},
        })
        self.mem.close()
        mem2 = MM.MissionMemory(db_path=self.tmp.name)  # reopen = restart
        rows = mem2.recent_events()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["event_id"], eid)
        self.assertIn("vehicle", rows[0]["event_json"])  # raw JSON stored
        mem2.close()

    def test_risk_filter_and_operator_action(self):
        self.mem.save_event({"mission_id": "m1", "risk_level": "green", "score": 0})
        y = self.mem.save_event({"mission_id": "m1", "risk_level": "yellow", "score": 40})
        self.assertEqual(len(self.mem.events_by_risk()), 1)
        self.assertTrue(self.mem.set_operator_action(y, "false_alarm"))

    def test_track_repeat_count(self):
        self.mem.upsert_track("V3", "m1", "vehicle", object_color="white", last_zone="gate")
        self.mem.upsert_track("V3", "m1", "vehicle", last_zone="gate")
        self.mem.upsert_track("V3", "m1", "vehicle", last_zone="gate")
        self.assertEqual(self.mem.get_track("V3")["seen_count"], 3)

    def test_transcript(self):
        self.mem.append_transcript("m1", "tool_execution_started", {"tool": "scan_360"})
        self.assertEqual(len(self.mem.transcript("m1")), 1)


class TestRiskScorer(unittest.TestCase):
    def setUp(self):
        self.scorer = RS.RiskScorer()

    def test_high_confidence_weapon_red(self):
        r = self.scorer.score_event({"object_type": "weapon", "confidence": 0.9})
        self.assertEqual(r["risk_level"], "red")
        self.assertIn("high_confidence_weapon_like_object", r["matched_rules"])

    def test_low_confidence_weapon_not_downgraded(self):
        # weapon is high-risk class -> not downgraded purely for low confidence
        r = self.scorer.score_event({"object_type": "weapon", "confidence": 0.4})
        self.assertIn("low_confidence_weapon_review", r["matched_rules"])
        self.assertEqual(r["risk_level"], "yellow")

    def test_after_hours_vehicle_near_gate_yellow(self):
        r = self.scorer.score_event({
            "object_type": "vehicle", "zone_type": "sensitive", "after_hours": True,
            "duration_sec": 96, "confidence": 0.87,
        })
        self.assertEqual(r["risk_level"], "yellow")
        self.assertIn("vehicle_after_hours_sensitive_zone", r["matched_rules"])

    def test_normal_vehicle_green(self):
        r = self.scorer.score_event({"object_type": "vehicle", "confidence": 0.9})
        self.assertEqual(r["risk_level"], "green")

    def test_cross_sensor_bonus_recorded(self):
        r = self.scorer.score_event({
            "object_type": "weapon", "confidence": 0.6,
            "sensor_confirmations": ["rgb", "thermal"],
        })
        self.assertIsNotNone(r["adjusted_confidence"])
        self.assertGreater(r["adjusted_confidence"], 0.6)

    def test_repeated_vehicle_near_gate(self):
        r = self.scorer.score_event({
            "object_type": "vehicle", "zone_type": "gate",
            "repeat_seen_count": 3, "time_window_minutes": 10, "confidence": 0.7,
        })
        self.assertIn("repeated_vehicle_near_gate", r["matched_rules"])

    def test_no_hardcoded_zone_names_in_module(self):
        # §9.4 acceptance: risk_scorer.py must not hardcode site/zone names.
        import inspect
        src = inspect.getsource(RS)
        for forbidden in ("west_gate", "equipment_yard", "restricted_storage"):
            self.assertNotIn(forbidden, src)


class TestSummaryGenerator(unittest.TestCase):
    def test_edge_summary_has_reason_and_recommendation(self):
        scored = {"risk_level": "yellow", "reasons": ["after hours", "near sensitive zone"]}
        meta = {"object_type": "vehicle", "object_color": "white", "zone": "west_gate"}
        s = SG.edge_summary(scored, meta)
        self.assertIn("after hours", s)
        self.assertIn("review", s.lower())
        self.assertIn("white vehicle", s)

    def test_approval_prompt(self):
        p = SG.approval_prompt("share_latest_clip")
        self.assertIn("Approve", p)

    def test_patrol_summary_counts(self):
        events = [{"risk_level": "red"}, {"risk_level": "yellow"}, {"risk_level": "green"}]
        out = SG.patrol_summary(events, mission_id="m1")
        self.assertEqual((out["red_count"], out["yellow_count"], out["green_count"]), (1, 1, 1))


class TestReasonEventAdapter(unittest.TestCase):
    def test_single_token(self):
        evs = REA.reason_string_to_events("weapon_rgb")
        self.assertEqual(len(evs), 1)
        self.assertEqual(evs[0]["object_type"], "weapon")
        self.assertEqual(evs[0]["sensor"], "rgb")

    def test_cross_sensor_weapon(self):
        evs = REA.reason_string_to_events("weapon_rgb,weapon_thermal")
        for e in evs:
            self.assertEqual(sorted(e["sensor_confirmations"]), ["rgb", "thermal"])


# ---- §14 First Three Workflows (integration, all fake-mode, no hardware) -------------
class TestFirstThreeWorkflows(unittest.TestCase):
    def setUp(self):
        self.reg = TR.ToolRegistry()
        self.eng = PE.PermissionEngine(registry=self.reg)
        self.scorer = RS.RiskScorer()
        self.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.tmp.close()
        self.mem = MM.MissionMemory(db_path=self.tmp.name)

    def tearDown(self):
        self.mem.close()
        os.unlink(self.tmp.name)

    def test_workflow_scan_direction(self):
        # "Scan my 2 o'clock" -> intent -> permission auto -> execute via registry -> log
        intent = IN.normalize("Scan my 2 o'clock")
        self.assertEqual(intent["intent"], "scan_direction")
        decision = self.eng.check("scan_direction")
        self.assertEqual(decision.level, "auto")
        result = self.reg.execute("scan_direction", intent["parameters"])
        self.assertEqual(result["status"], "success")
        eid = self.mem.save_event({
            "mission_id": "m1", "source": intent["source"], "intent": intent["intent"],
            "tool_name": "scan_direction", "event_json": result,
        })
        self.assertIsNotNone(self.mem.recent_events()[0])
        self.assertEqual(self.mem.recent_events()[0]["event_id"], eid)

    def test_workflow_yellow_event_package(self):
        # white vehicle near sensitive zone after hours 96s -> yellow -> saved -> summary
        event = {
            "object_type": "vehicle", "object_color": "white", "zone": "west_gate",
            "zone_type": "sensitive", "after_hours": True, "duration_sec": 96,
            "repeat_seen_count": 3, "confidence": 0.87,
        }
        scored = self.scorer.score_event(event)
        self.assertEqual(scored["risk_level"], "yellow")
        self.assertTrue(scored["reasons"])
        summary = SG.edge_summary(scored, event)
        eid = self.mem.save_event({
            "mission_id": "m1", "risk_level": scored["risk_level"], "score": scored["score"],
            "reasons": scored["reasons"], "matched_rules": scored["matched_rules"],
            "confidence": scored["confidence"], "adjusted_confidence": scored["adjusted_confidence"],
            "event_json": {**event, "edge_summary": summary},
        })
        # queryable
        yellows = self.mem.events_by_risk(("yellow",))
        self.assertEqual(len(yellows), 1)
        self.assertEqual(yellows[0]["event_id"], eid)

    def test_workflow_share_latest_clip_needs_approval(self):
        intent = IN.normalize("send latest clip to command")
        self.assertEqual(intent["intent"], "share_latest_clip")
        decision = self.eng.check("share_latest_clip")
        self.assertEqual(decision.level, "approval_required")
        # Without approval, controller must NOT execute. Simulate the gate:
        if decision.level == "auto":
            self.fail("share_latest_clip must not be auto")
        # rejection path logs a no-send
        self.mem.append_transcript("m1", "tool_permission_checked",
                                   {"tool": "share_latest_clip", "decision": decision.level})
        # approval path: only after approval do we execute
        result = self.reg.execute("share_latest_clip", intent["parameters"])
        self.assertEqual(result["status"], "success")  # fake send AFTER (simulated) approval


if __name__ == "__main__":
    unittest.main(verbosity=2)
