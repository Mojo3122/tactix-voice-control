"""test_phase2.py — Phase 2 tests (plan §16.1, §15 Tickets 6/7/15/16, §11.4).

Run:  python -m unittest tactix_mission.tests.test_phase2 -v
"""

import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from tactix_mission import (
    mission_memory as MM,
    risk_scorer as RS,
    evidence_packager as EP,
    evidence_integrity as EI,
    upload_queue as UQ,
    config_loader,
)


def _profile_with_storage(tmpdir):
    """A mission profile whose storage_root is an absolute temp dir (isolated test state)."""
    prof = config_loader.load_yaml("mission_profile.yaml")
    prof = json.loads(json.dumps(prof))  # deep copy
    prof["paths"]["storage_root"] = tmpdir
    return prof


class TestEvidenceIntegrity(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()

    def test_hash_and_verify_roundtrip(self):
        with open(os.path.join(self.dir, "a.txt"), "w") as fh:
            fh.write("hello")
        with open(os.path.join(self.dir, "b.txt"), "w") as fh:
            fh.write("world")
        hashes = EI.hash_package_files(self.dir)
        self.assertEqual(len(hashes), 2)
        self.assertTrue(all(v.startswith("sha256:") for v in hashes.values()))
        report = EI.verify_package(self.dir)
        self.assertEqual(report["status"], "verified")
        self.assertEqual(report["checked"], 2)

    def test_verify_detects_tamper(self):
        p = os.path.join(self.dir, "a.txt")
        with open(p, "w") as fh:
            fh.write("original")
        EI.hash_package_files(self.dir)
        with open(p, "w") as fh:        # tamper after hashing
            fh.write("TAMPERED")
        report = EI.verify_package(self.dir)
        self.assertEqual(report["status"], "failed")
        self.assertTrue(any(m["reason"] == "hash mismatch" for m in report["mismatches"]))

    def test_manifest_hash_deterministic(self):
        m = {"a": 1, "b": [1, 2, 3]}
        self.assertEqual(EI.compute_manifest_hash(m), EI.compute_manifest_hash({"b": [1, 2, 3], "a": 1}))

    def test_signing_disabled_returns_unsigned(self):
        desc = EI.sign_manifest("sha256:abc", {"enabled": False}, self.dir)
        self.assertFalse(desc["signed"])


class TestEvidencePackager(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.profile = _profile_with_storage(self.tmp)
        self.upload_cfg = config_loader.load_yaml("upload_config.yaml")
        self.packager = EP.EvidencePackager(profile=self.profile, upload_cfg=self.upload_cfg)
        self.scorer = RS.RiskScorer()

    def _yellow_event(self):
        meta = {"object_type": "vehicle", "object_color": "white", "zone": "west_gate",
                "zone_type": "sensitive", "after_hours": True, "duration_sec": 96,
                "confidence": 0.87,
                "detections": [{"class": "vehicle", "track_id": "V3", "confidence": 0.87}]}
        scored = self.scorer.score_event(meta)
        return scored, meta

    def test_package_created_with_all_core_files(self):
        scored, meta = self._yellow_event()
        # make a fake clip to link in
        clip = os.path.join(self.tmp, "fake_clip.mkv")
        with open(clip, "wb") as fh:
            fh.write(b"\x00\x01\x02fakevideo")
        res = self.packager.create_package("evt_001", scored, meta, clip_path=clip)
        self.assertEqual(res["status"], "success")
        pkg = res["package_path"]
        for f in ("event.json", "telemetry.json", "edge_summary.txt",
                  "file_hashes.json", "upload_manifest.json", "clip.mp4"):
            self.assertTrue(os.path.exists(os.path.join(pkg, f)), f"missing {f}")

    def test_missing_clip_does_not_crash(self):
        scored, meta = self._yellow_event()
        res = self.packager.create_package("evt_002", scored, meta, clip_path="/no/such/clip.mkv")
        self.assertEqual(res["status"], "success")
        self.assertEqual(res["clip_action"], "missing")
        # clip.mp4 absent, but the rest of the package exists
        pkg = res["package_path"]
        self.assertFalse(os.path.exists(os.path.join(pkg, "clip.mp4")))
        self.assertTrue(os.path.exists(os.path.join(pkg, "event.json")))

    def test_manifest_has_hashes_and_manifest_hash(self):
        scored, meta = self._yellow_event()
        res = self.packager.create_package("evt_003", scored, meta)
        manifest = res["manifest"]
        self.assertIn("file_hashes", manifest)
        self.assertTrue(manifest["manifest_sha256"].startswith("sha256:"))
        self.assertGreaterEqual(len(manifest["file_hashes"]), 3)

    def test_package_verifies_clean(self):
        scored, meta = self._yellow_event()
        res = self.packager.create_package("evt_004", scored, meta)
        report = EI.verify_package(res["package_path"])
        self.assertEqual(report["status"], "verified")

    def test_original_clip_not_deleted(self):
        scored, meta = self._yellow_event()
        clip = os.path.join(self.tmp, "keep_me.mkv")
        with open(clip, "wb") as fh:
            fh.write(b"data")
        self.packager.create_package("evt_005", scored, meta, clip_path=clip)
        self.assertTrue(os.path.exists(clip), "original gallery clip must NOT be deleted")


class TestUploadQueue(unittest.TestCase):
    def setUp(self):
        self.dbf = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.dbf.close()
        self.mem = MM.MissionMemory(db_path=self.dbf.name)
        self.cfg = config_loader.load_yaml("upload_config.yaml")
        self.q = UQ.UploadQueue(self.mem, upload_cfg=self.cfg)

    def tearDown(self):
        self.mem.close()
        os.unlink(self.dbf.name)

    def test_enqueue_and_successful_upload(self):
        self.q.enqueue("evt_1", "m1", "/tmp/evidence/evt_1")
        results = self.q.process_pending()
        self.assertEqual(results[0]["status"], "uploaded")
        self.assertEqual(self.q.status_counts().get("uploaded"), 1)

    def test_failed_upload_retries_then_dead(self):
        # path with __FAIL__ always fails via the fake transport
        self.q.enqueue("evt_2", "m1", "/tmp/evidence/__FAIL__evt_2")
        last = None
        for _ in range(self.q.max_attempts + 1):
            res = self.q.process_pending()
            if res:
                last = res[0]
        # after max_attempts, it should be 'dead' and not retried further
        self.assertIn(last["status"], ("failed", "dead"))
        self.assertEqual(self.q.status_counts().get("uploaded", 0), 0)

    def test_no_package_silently_dropped(self):
        self.q.enqueue("evt_3", "m1", "/tmp/evidence/__FAIL__evt_3")
        for _ in range(self.q.max_attempts + 2):
            self.q.process_pending()
        # the row still exists (as failed/dead), never deleted
        counts = self.q.status_counts()
        self.assertGreaterEqual(sum(counts.values()), 1)

    def test_backoff_grows(self):
        b1 = self.q.backoff_for(1)
        b2 = self.q.backoff_for(2)
        b3 = self.q.backoff_for(3)
        self.assertLess(b1, b2)
        self.assertLess(b2, b3)
        self.assertLessEqual(b3, self.q.max_backoff)


class TestPhase2EndToEnd(unittest.TestCase):
    """Yellow event -> package -> queue -> upload -> verify (all local, no network)."""
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.profile = _profile_with_storage(self.tmp)
        self.upload_cfg = config_loader.load_yaml("upload_config.yaml")
        self.dbf = os.path.join(self.tmp, "mission_events.db")
        self.mem = MM.MissionMemory(db_path=self.dbf)
        self.scorer = RS.RiskScorer()
        self.packager = EP.EvidencePackager(profile=self.profile, upload_cfg=self.upload_cfg)
        self.q = UQ.UploadQueue(self.mem, upload_cfg=self.upload_cfg)

    def test_full_flow(self):
        meta = {"object_type": "vehicle", "object_color": "white", "zone": "west_gate",
                "zone_type": "sensitive", "after_hours": True, "duration_sec": 96,
                "confidence": 0.87}
        scored = self.scorer.score_event(meta)
        self.assertEqual(scored["risk_level"], "yellow")
        eid = self.mem.save_event({
            "mission_id": "m1", "risk_level": scored["risk_level"], "score": scored["score"],
            "reasons": scored["reasons"], "event_json": meta,
        })
        pkg = self.packager.create_package(eid, scored, meta)
        self.mem.save_event({"event_id": eid, "mission_id": "m1",
                             "risk_level": scored["risk_level"],
                             "evidence_package_path": pkg["package_path"],
                             "event_json": meta})
        self.q.enqueue(eid, "m1", pkg["package_path"])
        res = self.q.process_pending()
        self.assertEqual(res[0]["status"], "uploaded")
        report = EI.verify_package(pkg["package_path"])
        self.assertEqual(report["status"], "verified")


if __name__ == "__main__":
    unittest.main(verbosity=2)
