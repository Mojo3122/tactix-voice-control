"""test_phase6.py — Phase 6 Piece A tests (dashboard forwarder).

Run:  python -m unittest tactix_mission.tests.test_phase6 -v

Uses a mock /api/events server to verify the forwarder maps fields correctly and only
forwards at/above min_risk_level.
"""

import json
import os
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from tactix_mission import (
    dashboard_forwarder as DF,
    mission_controller as MC,
    mission_memory as MM,
    config_loader,
)

try:
    import requests  # noqa
    HAVE_REQUESTS = True
except ImportError:
    HAVE_REQUESTS = False


class _MockDash(BaseHTTPRequestHandler):
    received = []
    def log_message(self, *a): pass
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}") if n else {}
        _MockDash.received.append({"path": self.path, "body": body})
        out = json.dumps({"event_id": body.get("event_id"), "status": "created"}).encode()
        self.send_response(201)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)


def _start():
    srv = HTTPServer(("127.0.0.1", 0), _MockDash)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


def _profile(enabled=True, base=None, min_risk="yellow"):
    p = json.loads(json.dumps(config_loader.load_yaml("mission_profile.yaml")))
    p["dashboard_forward"]["enabled"] = enabled
    p["dashboard_forward"]["min_risk_level"] = min_risk
    if base:
        p["dashboard_forward"]["base_url"] = base
    return p


@unittest.skipUnless(HAVE_REQUESTS, "requests not installed")
class TestDashboardForwarder(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv, cls.port = _start()
        cls.base = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        _MockDash.received.clear()

    def test_forwards_red_event(self):
        fwd = DF.DashboardForwarder(profile=_profile(base=self.base))
        scored = {"risk_level": "red", "score": 90, "confidence": 0.95,
                  "reasons": ["weapon"], "matched_rules": ["r"], "adjusted_confidence": 0.95}
        r = fwd.forward("evt_1", scored, {"object_type": "weapon", "timestamp_utc": "2026-01-01T00:00:00Z"})
        self.assertTrue(r["forwarded"])
        body = _MockDash.received[-1]["body"]
        self.assertEqual(_MockDash.received[-1]["path"], "/api/events")
        self.assertEqual(body["event_type"], "weapon_detected")
        self.assertEqual(body["event_id"], "evt_1")
        self.assertEqual(body["asset_type"], "vehicle")
        self.assertEqual(body["payload"]["risk_level"], "red")

    def test_green_not_forwarded(self):
        fwd = DF.DashboardForwarder(profile=_profile(base=self.base, min_risk="yellow"))
        r = fwd.forward("evt_2", {"risk_level": "green", "confidence": 0.9}, {"object_type": "vehicle"})
        self.assertFalse(r["forwarded"])
        self.assertEqual(len(_MockDash.received), 0)

    def test_disabled_not_forwarded(self):
        fwd = DF.DashboardForwarder(profile=_profile(enabled=False, base=self.base))
        self.assertFalse(fwd.should_forward("red"))

    def test_duplicate_409_counts_as_forwarded(self):
        # mock always returns 201; emulate 409 path via should_forward + mapping only
        fwd = DF.DashboardForwarder(profile=_profile(base=self.base))
        self.assertTrue(fwd.should_forward("yellow"))
        self.assertTrue(fwd.should_forward("red"))
        self.assertFalse(fwd.should_forward("green"))


@unittest.skipUnless(HAVE_REQUESTS, "requests not installed")
class TestControllerForwards(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv, cls.port = _start()
        cls.base = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        _MockDash.received.clear()
        self.tmp = tempfile.mkdtemp()
        profile = _profile(base=self.base)
        profile["paths"]["storage_root"] = self.tmp
        mem = MM.MissionMemory(db_path=os.path.join(self.tmp, "m.db"))
        fwd = DF.DashboardForwarder(profile=profile)
        self.ctrl = MC.MissionController(profile=profile, memory=mem, dashboard_forwarder=fwd)

    def tearDown(self):
        self.ctrl.shutdown()

    def test_red_detection_forwarded_to_dashboard(self):
        import time
        self.ctrl.handle_detection({"object_type": "weapon", "confidence": 0.95})
        # wait for background forward
        deadline = time.time() + 3
        while time.time() < deadline:
            if _MockDash.received:
                break
            time.sleep(0.02)
        self.assertTrue(any(r["path"] == "/api/events" for r in _MockDash.received))


if __name__ == "__main__":
    unittest.main(verbosity=2)
