"""test_phase5.py — Phase 5 tests (plan §22, §29 parity for the real path).

Spins up a tiny mock HTTP server that mimics the bridge's endpoints, then verifies:
  - BridgeExecutor hits the correct endpoint with the correct body for each tool
  - the controller, given the real executor, routes tool calls to the bridge
  - the ROS2-free MissionNodeRunner converts a reason string into scored detections
  - RealUploadTransport posts to /upload/run

Run:  python -m unittest tactix_mission.tests.test_phase5 -v

Skips gracefully if 'requests' is not installed.
"""

import json
import os
import sys
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from tactix_mission import (
    bridge_executor as BE,
    real_upload_transport as RUT,
    mission_node as MN,
    mission_controller as MC,
    mission_memory as MM,
    config_loader,
)

try:
    import requests  # noqa
    HAVE_REQUESTS = True
except ImportError:
    HAVE_REQUESTS = False


# ---- a tiny mock bridge that records what it received -------------------------------
class _MockBridgeHandler(BaseHTTPRequestHandler):
    received = []  # class-level capture

    def log_message(self, *a):
        pass  # silence

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            return json.loads(raw or b"{}")
        except Exception:
            return {}

    def do_POST(self):
        body = self._read_body()
        _MockBridgeHandler.received.append({"path": self.path, "body": body})
        resp = {"ok": True, "message": f"mock {self.path}", "mode": body.get("mode")}
        out = json.dumps(resp).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)


def _start_mock_server():
    server = HTTPServer(("127.0.0.1", 0), _MockBridgeHandler)
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    return server, port


@unittest.skipUnless(HAVE_REQUESTS, "requests not installed")
class TestBridgeExecutor(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server, cls.port = _start_mock_server()
        cls.base = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def setUp(self):
        _MockBridgeHandler.received.clear()
        self.ex = BE.BridgeExecutor(base_url=self.base)

    def _spec(self, name):
        from tactix_mission import tool_registry as TR
        return TR.ToolRegistry().get(name) or {}

    def test_scan_360_hits_scan(self):
        r = self.ex("scan_360", {}, self._spec("scan_360"))
        self.assertEqual(r["status"], "success")
        self.assertEqual(_MockBridgeHandler.received[-1]["path"], "/scan")

    def test_scan_direction_sends_pan_value(self):
        r = self.ex("scan_direction", {"direction": "3_oclock"}, self._spec("scan_direction"))
        rec = _MockBridgeHandler.received[-1]
        self.assertEqual(rec["path"], "/set_pan")
        self.assertEqual(rec["body"]["value"], 90)  # 3_oclock -> 90 deg from mission_profile

    def test_switch_thermal_body(self):
        self.ex("switch_thermal", {}, self._spec("switch_thermal"))
        rec = _MockBridgeHandler.received[-1]
        self.assertEqual(rec["path"], "/set_video_mode")
        self.assertEqual(rec["body"]["mode"], "thermal")

    def test_track_object_voice_command(self):
        self.ex("track_object", {"object_type": "vehicle", "index": 2}, self._spec("track_object"))
        rec = _MockBridgeHandler.received[-1]
        self.assertEqual(rec["path"], "/voice_command")
        self.assertIn("vehicle", rec["body"]["command"])

    def test_save_clip_record(self):
        self.ex("save_clip", {}, self._spec("save_clip"))
        self.assertEqual(_MockBridgeHandler.received[-1]["path"], "/record")

    def test_share_latest_clip_forces_upload(self):
        self.ex("share_latest_clip", {}, self._spec("share_latest_clip"))
        rec = _MockBridgeHandler.received[-1]
        self.assertEqual(rec["path"], "/upload/run")
        self.assertTrue(rec["body"]["force"])


@unittest.skipUnless(HAVE_REQUESTS, "requests not installed")
class TestControllerWithRealExecutor(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server, cls.port = _start_mock_server()
        cls.base = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def setUp(self):
        _MockBridgeHandler.received.clear()
        self.tmp = tempfile.mkdtemp()
        profile = json.loads(json.dumps(config_loader.load_yaml("mission_profile.yaml")))
        profile["paths"]["storage_root"] = self.tmp
        mem = MM.MissionMemory(db_path=os.path.join(self.tmp, "m.db"))
        self.ctrl = MC.MissionController(profile=profile, memory=mem,
                                         tool_executor=BE.BridgeExecutor(base_url=self.base))

    def tearDown(self):
        self.ctrl.shutdown()

    def test_command_routes_to_bridge(self):
        res = self.ctrl.handle_command("scan 360")
        self.assertEqual(res["status"], "success")
        self.assertFalse(res["execution"]["fake"])
        self.assertEqual(_MockBridgeHandler.received[-1]["path"], "/scan")

    def test_thermal_command_routes(self):
        self.ctrl.handle_command("switch to thermal")
        self.assertEqual(_MockBridgeHandler.received[-1]["path"], "/set_video_mode")


@unittest.skipUnless(HAVE_REQUESTS, "requests not installed")
class TestRealUploadTransport(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server, cls.port = _start_mock_server()
        cls.base = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def test_upload_posts_to_run(self):
        _MockBridgeHandler.received.clear()
        t = RUT.RealUploadTransport(base_url=self.base)
        ok, err = t("/some/package/path")
        self.assertTrue(ok)
        self.assertEqual(_MockBridgeHandler.received[-1]["path"], "/upload/run")


class TestMissionNodeRunner(unittest.TestCase):
    """ROS2-free: detection-event wiring works without a bridge or ROS2."""
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        profile = json.loads(json.dumps(config_loader.load_yaml("mission_profile.yaml")))
        profile["paths"]["storage_root"] = self.tmp
        mem = MM.MissionMemory(db_path=os.path.join(self.tmp, "m.db"))
        # fake executor so no network needed
        ctrl = MC.MissionController(profile=profile, memory=mem)
        self.runner = MN.MissionNodeRunner(controller=ctrl, profile=profile)

    def tearDown(self):
        self.runner.shutdown()

    def test_weapon_trigger_scores_red(self):
        results = self.runner.on_auto_record_trigger("weapon_rgb")
        self.assertTrue(results)
        self.assertEqual(results[0]["risk_level"], "red")

    def test_dedup_repeated_trigger(self):
        first = self.runner.on_auto_record_trigger("weapon_rgb")
        second = self.runner.on_auto_record_trigger("weapon_rgb")  # within window
        self.assertTrue(first)
        self.assertEqual(second, [])  # deduped

    def test_telemetry_updates(self):
        self.runner.on_pan(12.5)
        self.runner.on_zoom(40.0)
        self.assertEqual(self.runner._ptz["pan"], 12.5)
        self.assertEqual(self.runner._ptz["zoom"], 40.0)

    def test_cross_sensor_trigger(self):
        results = self.runner.on_auto_record_trigger("weapon_rgb,weapon_thermal")
        # both events present; risk red either way
        self.assertTrue(all(r["risk_level"] == "red" for r in results))


if __name__ == "__main__":
    unittest.main(verbosity=2)
