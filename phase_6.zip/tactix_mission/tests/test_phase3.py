"""test_phase3.py — Phase 3 tests (plan §21.1, §23, §24.2/3, §28).

Run:  python -m unittest tactix_mission.tests.test_phase3 -v
"""

import datetime as dt
import os
import sys
import tempfile
import threading
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from tactix_mission import (
    mission_memory as MM,
    capability_manifest as CM,
    mission_context_builder as MCB,
    bounded_async_executor as BAE,
    health_monitor as HM,
    upload_queue as UQ,
    config_loader,
)


class TestCapabilityManifest(unittest.TestCase):
    def test_build_contains_tools_and_permissions(self):
        man = CM.CapabilityManifest().build()
        self.assertGreater(man["tool_count"], 0)
        names = [t["name"] for t in man["tools"]]
        self.assertIn("scan_360", names)
        # resolved permission levels present
        scan = next(t for t in man["tools"] if t["name"] == "scan_360")
        self.assertEqual(scan["permission"], "auto")
        share = next(t for t in man["tools"] if t["name"] == "share_latest_clip")
        self.assertEqual(share["permission"], "approval_required")

    def test_blocked_tool_marked_unavailable(self):
        man = CM.CapabilityManifest().build()
        de = next((t for t in man["tools"] if t["name"] == "delete_evidence"), None)
        self.assertIsNotNone(de)
        self.assertFalse(de["available"])

    def test_permission_summary_counts(self):
        man = CM.CapabilityManifest().build()
        s = man["permission_summary"]
        self.assertEqual(sum(s.values()), man["tool_count"])

    def test_write_manifest(self):
        tmp = tempfile.mkdtemp()
        path = os.path.join(tmp, "cap.json")
        out = CM.CapabilityManifest().write(path=path)
        self.assertTrue(os.path.exists(out))


class TestMissionContextBuilder(unittest.TestCase):
    def setUp(self):
        self.builder = MCB.MissionContextBuilder()

    def test_after_hours_night_window(self):
        # default window 19:00-06:00
        night = dt.datetime(2026, 1, 1, 23, 0, 0)
        day = dt.datetime(2026, 1, 1, 12, 0, 0)
        self.assertTrue(self.builder.is_after_hours(night))
        self.assertFalse(self.builder.is_after_hours(day))

    def test_zone_type_default_general(self):
        self.assertEqual(self.builder.zone_type_for("unknown_zone"), "general")
        self.assertEqual(self.builder.zone_type_for(None), "general")

    def test_enrich_event_adds_context(self):
        night = dt.datetime(2026, 1, 1, 23, 0, 0)
        ev = {"object_type": "vehicle", "zone": "somewhere"}
        enriched = self.builder.enrich_event(ev, now=night)
        self.assertIn("after_hours", enriched)
        self.assertTrue(enriched["after_hours"])
        self.assertIn("zone_type", enriched)
        # original not mutated
        self.assertNotIn("after_hours", ev)

    def test_build_snapshot(self):
        ctx = self.builder.build(now=dt.datetime(2026, 1, 1, 23, 0))
        self.assertIn("after_hours", ctx)
        self.assertIn("playbook_id", ctx)


class TestBoundedAsyncExecutor(unittest.TestCase):
    def test_runs_task_off_thread(self):
        ex = BAE.BoundedAsyncExecutor(workers=2, max_queue=8)
        ex.start()
        result_box = {}
        done = threading.Event()
        def work(x):
            return x * 2
        def on_done(r):
            result_box["r"] = r
            done.set()
        accepted = ex.submit(work, 21, name="double", on_done=on_done)
        self.assertTrue(accepted)
        self.assertTrue(done.wait(timeout=2.0))
        self.assertEqual(result_box["r"], 42)
        ex.shutdown()

    def test_queue_full_rejects(self):
        # 1 worker, queue size 1, block the worker so the queue fills
        ex = BAE.BoundedAsyncExecutor(workers=1, max_queue=1)
        ex.start()
        gate = threading.Event()
        def blocker():
            gate.wait(timeout=2.0)
        ex.submit(blocker, name="blocker")     # occupies the worker
        time.sleep(0.1)
        # fill the single queue slot
        first = ex.submit(blocker, name="q1")
        # now at least one further submit should be rejected (bounded, no unbounded growth)
        rejected_any = False
        for _ in range(5):
            if not ex.submit(lambda: None, name="overflow"):
                rejected_any = True
                break
        self.assertTrue(rejected_any)
        gate.set()
        ex.shutdown()
        self.assertGreaterEqual(ex.stats()["rejected"], 1)

    def test_task_exception_does_not_kill_worker(self):
        ex = BAE.BoundedAsyncExecutor(workers=1, max_queue=4)
        ex.start()
        errs = {}
        ev = threading.Event()
        def boom():
            raise ValueError("expected")
        ex.submit(boom, name="boom", on_error=lambda e: (errs.__setitem__("e", e), ev.set()))
        self.assertTrue(ev.wait(timeout=2.0))
        # worker still alive: a subsequent task completes
        ev2 = threading.Event()
        ex.submit(lambda: None, name="after", on_done=lambda r: ev2.set())
        self.assertTrue(ev2.wait(timeout=2.0))
        ex.shutdown()
        self.assertEqual(ex.stats()["failed"], 1)

    def test_submit_after_shutdown_rejected(self):
        ex = BAE.BoundedAsyncExecutor(workers=1, max_queue=4)
        ex.start()
        ex.shutdown()
        self.assertFalse(ex.submit(lambda: None, name="late"))


class TestHealthMonitor(unittest.TestCase):
    def setUp(self):
        self.dbf = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.dbf.close()
        self.mem = MM.MissionMemory(db_path=self.dbf.name)

    def tearDown(self):
        self.mem.close()
        os.unlink(self.dbf.name)

    def test_report_ok_baseline(self):
        ex = BAE.BoundedAsyncExecutor(workers=1, max_queue=8)
        ex.start()
        q = UQ.UploadQueue(self.mem)
        mon = HM.HealthMonitor(memory=self.mem, executor=ex, upload_queue=q, min_free_mb=1.0)
        rep = mon.report()
        self.assertIn(rep["overall"], ("ok", "degraded"))  # disk could be tight in CI
        self.assertIn("disk", rep["checks"])
        self.assertIn("executor", rep["checks"])
        ex.shutdown()

    def test_db_check_detects_closed(self):
        mon = HM.HealthMonitor(memory=self.mem)
        self.assertEqual(mon.check_db()["status"], "ok")
        self.mem.close()
        self.assertEqual(mon.check_db()["status"], "unhealthy")

    def test_executor_degraded_when_stopped(self):
        ex = BAE.BoundedAsyncExecutor(workers=1, max_queue=8)  # not started
        mon = HM.HealthMonitor(executor=ex)
        self.assertEqual(mon.check_executor()["status"], "unhealthy")

    def test_disk_unhealthy_with_huge_threshold(self):
        mon = HM.HealthMonitor(memory=self.mem, min_free_mb=10**12)  # impossible free space
        self.assertIn(mon.check_disk()["status"], ("degraded", "unhealthy"))


class TestPhase3Integration(unittest.TestCase):
    """context -> scorer-ready event, and background packaging via executor."""
    def test_context_enriched_event_scores_yellow(self):
        from tactix_mission import risk_scorer as RS
        builder = MCB.MissionContextBuilder()
        night = dt.datetime(2026, 1, 1, 23, 0)
        raw = {"object_type": "vehicle", "zone": "yard", "zone_type": "sensitive",
               "duration_sec": 96, "confidence": 0.87}
        enriched = builder.enrich_event(raw, now=night)
        scored = RS.RiskScorer().score_event(enriched)
        self.assertEqual(scored["risk_level"], "yellow")

    def test_background_packaging_does_not_block(self):
        from tactix_mission import risk_scorer as RS, evidence_packager as EP
        import json
        tmp = tempfile.mkdtemp()
        prof = json.loads(json.dumps(config_loader.load_yaml("mission_profile.yaml")))
        prof["paths"]["storage_root"] = tmp
        packager = EP.EvidencePackager(profile=prof,
                                       upload_cfg=config_loader.load_yaml("upload_config.yaml"))
        scored = RS.RiskScorer().score_event({"object_type": "weapon", "confidence": 0.9})
        ex = BAE.BoundedAsyncExecutor(workers=2, max_queue=8)
        ex.start()
        done = threading.Event()
        box = {}
        ex.submit(packager.create_package, "evt_bg", scored,
                  {"object_type": "weapon"}, name="package",
                  on_done=lambda r: (box.__setitem__("r", r), done.set()))
        self.assertTrue(done.wait(timeout=3.0))
        self.assertEqual(box["r"]["status"], "success")
        ex.shutdown()


if __name__ == "__main__":
    unittest.main(verbosity=2)
