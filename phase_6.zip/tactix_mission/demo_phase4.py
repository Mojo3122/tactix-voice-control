"""demo_phase4.py — the whole mission controller running end-to-end (fake mode).

Run:  python -m tactix_mission.demo_phase4
Shows a short "patrol": operator commands + detection events flowing through ONE
MissionController object — normalize, permission, execute, context, score, background
package + queue, summarize, health. No ROS2, no network, no change to existing scripts.
"""

import datetime as dt
import json
import os
import tempfile
import time

from tactix_mission import mission_controller as MC, mission_memory as MM, config_loader


def banner(t):
    print("\n" + "=" * 70 + f"\n{t}\n" + "=" * 70)


def main():
    tmp = tempfile.mkdtemp(prefix="tactix_demo4_")
    profile = json.loads(json.dumps(config_loader.load_yaml("mission_profile.yaml")))
    profile["paths"]["storage_root"] = tmp
    mem = MM.MissionMemory(db_path=os.path.join(tmp, "mission_events.db"))

    # approve clip-sharing automatically for the demo (operator says yes)
    ctrl = MC.MissionController(profile=profile, memory=mem,
                               approval_callback=lambda t, p, prompt: True)

    banner("PHASE 4 DEMO — Full Mission Controller (one object, all phases)")
    print(f"vehicle: {profile['mission']['vehicle_id']}  mission: {ctrl.mission_id}")

    banner("OPERATOR COMMANDS")
    for cmd in ["scan my 2 o'clock", "switch to thermal", "track that car",
                "send latest clip to command"]:
        res = ctrl.handle_command(cmd)
        tool = res.get("tool", "-")
        extra = res.get("execution", {}).get("message", res.get("prompt", res.get("reason", "")))
        print(f"  '{cmd}'\n      -> {res['status']} [{tool}] {extra}")

    banner("DETECTION EVENTS")
    night = dt.datetime(2026, 1, 1, 23, 15)
    events = [
        {"object_type": "vehicle", "confidence": 0.9, "zone": "open_road"},          # green
        {"object_type": "vehicle", "zone": "equipment_yard", "duration_sec": 96,     # yellow
         "confidence": 0.87, "track_key": "V3", "object_color": "white"},
        {"object_type": "weapon", "confidence": 0.95},                                # red
    ]
    for ev in events:
        res = ctrl.handle_detection(dict(ev), now=night)
        print(f"  {ev.get('object_type'):8s} -> {res['risk_level'].upper():6s} "
              f"score={res['score']:<5} packaged={res['packaged']}")
        if res["reasons"]:
            print(f"           reasons: {res['reasons']}")

    # let background packaging/upload finish
    time.sleep(0.5)
    ctrl.process_uploads_once()

    banner("PATROL SUMMARY")
    summ = ctrl.handle_command("summarize patrol")
    print("  " + summ["summary"])

    banner("HEALTH + STATS")
    rep = ctrl.health_report()
    print(f"  overall: {rep['overall'].upper()}")
    print(f"  executor: {ctrl.executor.stats()}")
    print(f"  uploads : {ctrl.uploads.status_counts()}")
    print(f"  events  : {len(ctrl.memory.recent_events(limit=100))} logged")

    ctrl.shutdown()
    banner("DONE")


if __name__ == "__main__":
    main()
