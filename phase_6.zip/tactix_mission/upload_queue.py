"""upload_queue.py — Ticket 7 (plan §5.8, §11.4, §24.2).

Queues evidence packages for upload, retries failures with backoff, and tracks
uploaded / pending / failed status in the mission_memory.upload_queue table.

Phase 2: transport="fake" simulates a send (configurable success/fail for tests). No
network, no rsync. Phase 5 swaps transport to "bridge" and calls the existing bridge
/upload/run endpoint — the queue/retry/status logic is identical either way.

Safety (§11.4): a successful upload NEVER deletes the local package unless
delete_local_after_upload is explicitly true in upload_config.yaml.
"""

from __future__ import annotations

import time
from typing import Callable, Optional

from . import config_loader


def _utcnow() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class UploadQueue:
    def __init__(self, memory, upload_cfg: Optional[dict] = None,
                 transport: Optional[Callable[[str], tuple]] = None):
        """
        memory     : a MissionMemory instance (owns the upload_queue table)
        upload_cfg : parsed upload_config.yaml (loaded if None)
        transport  : callable(package_path) -> (ok: bool, error: str). If None, a fake
                     transport from config is used. Phase 5 passes a real bridge sender.
        """
        self.memory = memory
        self.cfg = (upload_cfg if upload_cfg is not None
                    else config_loader.load_yaml("upload_config.yaml")).get("upload", {})
        self.max_attempts = self.cfg.get("max_attempts", 5)
        self.backoff = self.cfg.get("backoff_seconds", 5)
        self.backoff_mult = self.cfg.get("backoff_multiplier", 2.0)
        self.max_backoff = self.cfg.get("max_backoff_seconds", 300)
        self.delete_after = self.cfg.get("delete_local_after_upload", False)
        self.max_queue_size = self.cfg.get("max_queue_size", 100)
        self._transport = transport or self._fake_transport

    # ---- enqueue ----
    def enqueue(self, event_id: str, mission_id: str, package_path: str) -> dict:
        pending = self.memory.pending_uploads()
        if len(pending) >= self.max_queue_size:
            return {"status": "rejected", "reason": "queue full",
                    "queue_size": len(pending), "max": self.max_queue_size}
        package_id = self.memory.enqueue_upload(event_id, mission_id, package_path)
        return {"status": "queued", "package_id": package_id, "package_path": package_path}

    # ---- process one package (single attempt; caller decides scheduling) ----
    def _attempt(self, row: dict) -> dict:
        package_id = row["package_id"]
        path = row["package_path"]
        retry_count = row.get("retry_count", 0) or 0

        ok, err = self._transport(path)
        now = _utcnow()
        conn = self.memory._conn
        lock = getattr(self.memory, "_lock", None)
        if ok:
            if lock is not None:
                with lock, conn:
                    conn.execute(
                        """UPDATE upload_queue SET status='uploaded', uploaded_utc=?,
                           last_attempt_utc=?, error_message=NULL WHERE package_id=?""",
                        (now, now, package_id),
                    )
            else:
                conn.execute(
                    """UPDATE upload_queue SET status='uploaded', uploaded_utc=?,
                       last_attempt_utc=?, error_message=NULL WHERE package_id=?""",
                    (now, now, package_id),
                )
                conn.commit()
            if self.delete_after:
                self._safe_delete(path)
            return {"package_id": package_id, "status": "uploaded"}
        else:
            new_retry = retry_count + 1
            status = "failed" if new_retry < self.max_attempts else "dead"
            if lock is not None:
                with lock, conn:
                    conn.execute(
                        """UPDATE upload_queue SET status=?, retry_count=?, last_attempt_utc=?,
                           error_message=? WHERE package_id=?""",
                        (status, new_retry, now, err, package_id),
                    )
            else:
                conn.execute(
                    """UPDATE upload_queue SET status=?, retry_count=?, last_attempt_utc=?,
                       error_message=? WHERE package_id=?""",
                    (status, new_retry, now, err, package_id),
                )
                conn.commit()
            return {"package_id": package_id, "status": status,
                    "retry_count": new_retry, "error": err}

    def backoff_for(self, retry_count: int) -> float:
        """Compute backoff seconds for a given retry count (exponential, capped)."""
        delay = self.backoff * (self.backoff_mult ** max(0, retry_count - 1))
        return min(delay, self.max_backoff)

    def process_pending(self, max_packages: int = 50) -> list:
        """Run one attempt over all pending/failed packages. Returns per-package results.

        Note: this does NOT sleep between attempts — backoff scheduling is the caller's
        job (the bounded async executor in Phase 3). Here it just makes one pass so it is
        deterministic and unit-testable. 'dead' packages are skipped (never silently
        dropped — they remain in the table for operator review, §24.2/§24.3).
        """
        results = []
        for row in self.memory.pending_uploads()[:max_packages]:
            if (row.get("retry_count", 0) or 0) >= self.max_attempts:
                continue
            results.append(self._attempt(row))
        return results

    def status_counts(self) -> dict:
        conn = self.memory._conn
        lock = getattr(self.memory, "_lock", None)
        if lock is not None:
            with lock:
                rows = conn.execute(
                    "SELECT status, COUNT(*) c FROM upload_queue GROUP BY status"
                ).fetchall()
        else:
            rows = conn.execute(
                "SELECT status, COUNT(*) c FROM upload_queue GROUP BY status"
            ).fetchall()
        return {r["status"]: r["c"] for r in rows}

    # ---- transports ----
    def _fake_transport(self, package_path: str) -> tuple:
        """Default Phase 2 transport: succeed unless the path encodes a fail marker.

        For deterministic tests, a package_path containing '__FAIL__' fails; everything
        else 'uploads' successfully.
        """
        if "__FAIL__" in package_path:
            return False, "simulated upload failure"
        return True, ""

    @staticmethod
    def _safe_delete(path: str):
        import shutil
        try:
            shutil.rmtree(path)
        except Exception:
            pass
