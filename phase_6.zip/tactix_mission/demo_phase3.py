"""demo_phase3.py — runnable walkthrough of Phase 3 runtime infrastructure.

Run:  python -m tactix_mission.demo_phase3
Shows: capability manifest, mission context (after-hours derivation), the bounded async
executor running background packaging off-thread, and a health report. No network.
"""

import datetime as dt
import json
import os
import tempfile
import threading
import time

from tactix_mission import (
    mission_memory as MM,
    risk_scorer as RS,
    evidence_packager as EP,
    upload_queue as UQ,
    capability_manifest as CM,
    mission_context_builder as MCB,
    bounded_async_executor as BAE,
    health_monitor as HM,
    config_loader,
)


def main():
    tmp = tempfile.mkdtemp(prefix="tactix_demo3_")
    profile = json.loads(json.dumps(config_loader.load_yaml("mission_profile.yaml")))
    profile["paths"]["storage_root"] = tmp
    upload_cfg = config_loader.load_yaml("upload_config.yaml")
    mem = MM.MissionMemory(db_path=os.path.join(tmp, "mission_events.db"))

    print("=" * 70)
    print("PHASE 3 DEMO — Runtime Infrastructure")
    print("=" * 70)

    # 1) Capability manifest
    man = CM.CapabilityManifest(profile=profile).build()
    print(f"\n1) CAPABILITY MANIFEST for {man['vehicle_id']}")
    print(f"   tools: {man['tool_count']}  |  permissions: {man['permission_summary']}")
    print(f"   sensor modes: {man['sensor_modes']}  |  playbook: {man['active_playbook']}")

    # 2) Mission context — after-hours derivation
    builder = MCB.MissionContextBuilder(profile=profile, memory=mem)
    night = dt.datetime(2026, 1, 1, 23, 30)
    noon = dt.datetime(2026, 1, 1, 12, 0)
    print(f"\n2) MISSION CONTEXT")
    print(f"   23:30 -> after_hours = {builder.is_after_hours(night)}")
    print(f"   12:00 -> after_hours = {builder.is_after_hours(noon)}")
    raw = {"object_type": "vehicle", "zone": "yard", "zone_type": "sensitive",
           "duration_sec": 96, "confidence": 0.87}
    enriched = builder.enrich_event(raw, now=night)
    scored = RS.RiskScorer().score_event(enriched)
    print(f"   raw event enriched + scored -> {scored['risk_level'].upper()} "
          f"(reasons: {scored['reasons']})")

    # 3) Bounded async executor — background packaging off the realtime path
    print(f"\n3) BOUNDED ASYNC EXECUTOR (background work, never blocks realtime)")
    packager = EP.EvidencePackager(profile=profile, upload_cfg=upload_cfg)
    ex = BAE.BoundedAsyncExecutor(workers=2, max_queue=16)
    ex.start()
    done = threading.Event()
    box = {}
    t0 = time.time()
    accepted = ex.submit(packager.create_package, "evt_demo3", scored, enriched,
                         name="package", on_done=lambda r: (box.__setitem__("r", r), done.set()))
    submit_ms = (time.time() - t0) * 1000
    print(f"   submit() returned in {submit_ms:.2f} ms (accepted={accepted}) "
          f"<- caller not blocked by packaging")
    done.wait(timeout=3.0)
    print(f"   background package built at: {os.path.basename(box['r']['package_path'])}")
    print(f"   executor stats: {ex.stats()}")

    # 4) Health monitor
    q = UQ.UploadQueue(mem, upload_cfg=upload_cfg)
    mon = HM.HealthMonitor(profile=profile, memory=mem, executor=ex, upload_queue=q, min_free_mb=1.0)
    rep = mon.report()
    print(f"\n4) HEALTH REPORT -> overall: {rep['overall'].upper()}")
    for name, c in rep["checks"].items():
        print(f"   {name:9s}: {c['status']}")

    ex.shutdown()
    mem.close()
    print("\n" + "=" * 70)


if __name__ == "__main__":
    main()
