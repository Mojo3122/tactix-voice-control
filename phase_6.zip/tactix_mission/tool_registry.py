"""tool_registry.py — Ticket 2 (plan §7, §18.2, §21.1).

Loads tools from tool_registry.yaml, validates a tool exists before execution, and
returns a structured result. In Phase 1 execution is FAKE (no network) per the plan's
"use fake tool calls first" guidance (§18). The fake result shape matches §18.2.

The real adapter (HTTP to the bridge, ROS2 publish) is wired in Phase 5 by replacing
the executor passed to execute(); the registry/validation contract stays identical.
"""

from __future__ import annotations

import time
from typing import Callable, Optional

from . import config_loader


class ToolRegistry:
    def __init__(self, registry: Optional[dict] = None):
        data = registry if registry is not None else config_loader.load_yaml("tool_registry.yaml")
        self.base_url = data.get("base_url", "")
        self.tools = data.get("tools", {}) or {}

    # ---- lookup / introspection ----
    def has_tool(self, name: str) -> bool:
        return name in self.tools

    def get(self, name: str) -> Optional[dict]:
        return self.tools.get(name)

    def list_tools(self) -> list:
        return sorted(self.tools.keys())

    def metadata(self, name: str) -> dict:
        """Return capability metadata for a tool (permission, exec_class, timeout, etc.).

        Raises KeyError for unknown tools.
        """
        spec = self.tools[name]
        return {
            "name": name,
            "type": spec.get("type"),
            "permission": spec.get("permission"),
            "exec_class": spec.get("exec_class"),
            "timeout_ms": spec.get("timeout_ms"),
            "retry": spec.get("retry", {}),
            "blocking": spec.get("blocking", False),
            "endpoint": spec.get("endpoint"),
            "topic": spec.get("topic"),
            "method": spec.get("method"),
            "description": spec.get("description", ""),
        }

    # ---- execution ----
    def execute(self, name: str, parameters: Optional[dict] = None,
                executor: Optional[Callable[[str, dict, dict], dict]] = None) -> dict:
        """Execute a tool through the registry.

        - Unknown tool -> structured rejection (status="rejected").
        - executor=None -> FAKE execution (Phase 1 default).
        - executor provided -> called as executor(name, parameters, spec) and its dict
          result is returned (Phase 5 real adapter). The registry still owns validation.
        """
        parameters = parameters or {}
        if name not in self.tools:
            return {
                "tool": name,
                "status": "rejected",
                "message": f"unknown tool '{name}' (not in tool_registry.yaml)",
                "metadata": None,
            }

        spec = self.tools[name]
        if spec.get("type") == "blocked":
            return {
                "tool": name,
                "status": "blocked",
                "message": f"tool '{name}' is blocked by registry type",
                "metadata": self.metadata(name),
            }

        if executor is None:
            return self._fake_execute(name, parameters, spec)

        result = executor(name, parameters, spec)
        # Ensure the contract is honoured even with a custom executor.
        result.setdefault("tool", name)
        result.setdefault("status", "success")
        result.setdefault("metadata", self.metadata(name))
        return result

    def _fake_execute(self, name: str, parameters: dict, spec: dict) -> dict:
        """Phase 1 fake execution — matches §18.2 fake tool result shape."""
        t0 = time.time()
        msg = spec.get("description", f"executed {name}")
        # Friendlier fake messages for the demo workflows.
        if name == "scan_direction":
            msg = f"PTZ moved to {parameters.get('direction', 'requested heading')}"
        elif name == "scan_360":
            msg = "360-degree PTZ scan started"
        elif name in ("switch_rgb", "switch_thermal"):
            msg = f"video mode set to {parameters.get('mode', name.split('_')[-1])}"
        elif name == "track_object":
            msg = f"tracking {parameters.get('object_type', 'target')}"
        return {
            "tool": name,
            "status": "success",
            "message": msg,
            "fake": True,
            "parameters": parameters,
            "elapsed_ms": round((time.time() - t0) * 1000, 3),
            "metadata": self.metadata(name),
        }
