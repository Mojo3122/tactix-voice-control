"""risk_scorer.py — Tickets 5, 13, 14 (plan §9, §33).

Data-driven risk scorer. It INTERPRETS rules from risk_rules.yaml (+ optional playbook
overrides); it contains NO site names, zone names, or weights (§9.4 acceptance).

Confidence-aware (§9.2, §14): detection confidence scales the base score; cross-sensor
confirmation bumps it; low-confidence single-sensor events are downgraded unless the
object class is high-risk (e.g. weapon).

Returns: score, risk_level, reasons, matched_rules, confidence_adjustments.
"""

from __future__ import annotations

from typing import Optional

from . import config_loader


# ---- condition matching --------------------------------------------------------------
def _cmp(event: dict, key: str, expected) -> bool:
    """Evaluate a single condition key against the event, supporting operator suffixes."""
    if key.endswith("_gte"):
        f = key[:-4]
        v = event.get(f)
        return v is not None and _num(v) >= _num(expected)
    if key.endswith("_lte"):
        f = key[:-4]
        v = event.get(f)
        return v is not None and _num(v) <= _num(expected)
    if key.endswith("_lt"):
        f = key[:-3]
        v = event.get(f)
        return v is not None and _num(v) < _num(expected)
    if key.endswith("_gt"):
        f = key[:-3]
        v = event.get(f)
        return v is not None and _num(v) > _num(expected)
    if key.endswith("_in"):
        f = key[:-3]
        return event.get(f) in (expected or [])
    # special-case min_confidence (used as a gate inside several rules)
    if key == "min_confidence":
        v = event.get("confidence")
        return v is not None and _num(v) >= _num(expected)
    # plain equality
    return event.get(key) == expected


def _num(x) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return float("nan")


def conditions_match(event: dict, conditions: dict) -> bool:
    """ALL conditions must hold."""
    for key, expected in (conditions or {}).items():
        if not _cmp(event, key, expected):
            return False
    return True


# ---- confidence modifier -------------------------------------------------------------
def apply_confidence_modifier(base_score: float, confidence, object_type: str,
                              sensor_confirmations, cfg: dict) -> tuple:
    """Return (adjusted_score, adjustment_record) per §9.2."""
    conf = _num(confidence)
    confirmations = sensor_confirmations or []
    high_risk = (object_type in (cfg.get("high_risk_classes") or []))
    factor = cfg.get("normal_factor", 1.0)
    notes = []

    if conf == conf:  # not NaN
        if conf < cfg.get("low_confidence_lt", 0.5) and not high_risk:
            factor = cfg.get("low_confidence_factor", 0.5)
            notes.append("downgraded: low confidence, non-high-risk class")
        elif conf < cfg.get("low_confidence_lt", 0.5) and high_risk:
            notes.append("low confidence but high-risk class — not downgraded")

    if len(confirmations) >= 2:
        factor += cfg.get("cross_sensor_bonus", 0.2)
        notes.append(f"cross-sensor confirmation x{len(confirmations)}")

    adjusted = round(base_score * factor, 3)
    return adjusted, {
        "base_score": base_score,
        "confidence": None if conf != conf else conf,
        "factor": round(factor, 3),
        "adjusted_score": adjusted,
        "notes": notes,
    }


# ---- threshold mapping ---------------------------------------------------------------
def thresholds_to_risk_level(total_score: float, thresholds: dict) -> str:
    if total_score >= thresholds.get("red", 80):
        return "red"
    if total_score >= thresholds.get("yellow", 35):
        return "yellow"
    return "green"


class RiskScorer:
    def __init__(self, rules_cfg: Optional[dict] = None, playbook: Optional[dict] = None):
        self.cfg = rules_cfg if rules_cfg is not None else config_loader.load_yaml("risk_rules.yaml")
        self.rules = list(self.cfg.get("risk_rules", []) or [])
        self.thresholds = self.cfg.get("thresholds", {"red": 80, "yellow": 35, "green": 0})
        self.conf_cfg = self.cfg.get("confidence_modifier", {})
        # Playbook may override/extend base rules (§9.4, §26).
        if playbook:
            self._apply_playbook(playbook)

    def _apply_playbook(self, playbook: dict):
        # Playbook can append extra rules and/or override thresholds. Zone/rule names
        # come from the playbook YAML — still no hardcoding in Python.
        extra = playbook.get("extra_risk_rules", []) or []
        self.rules.extend(extra)
        if "thresholds" in playbook:
            self.thresholds = {**self.thresholds, **playbook["thresholds"]}

    def score_event(self, event: dict, mission_context: Optional[dict] = None) -> dict:
        total = 0.0
        reasons: list = []
        matched: list = []
        adjustments: list = []

        obj_type = event.get("object_type", "")
        confidence = event.get("confidence")
        confirmations = event.get("sensor_confirmations", [])

        for rule in self.rules:
            if conditions_match(event, rule.get("conditions", {})):
                base = rule.get("score", 0)
                adj_score, adj = apply_confidence_modifier(
                    base_score=base,
                    confidence=confidence,
                    object_type=obj_type,
                    sensor_confirmations=confirmations,
                    cfg=self.conf_cfg,
                )
                adj["rule_id"] = rule.get("id")
                total += adj_score
                matched.append(rule.get("id"))
                reasons.extend(rule.get("reasons", []))
                adjustments.append(adj)

        risk_level = thresholds_to_risk_level(total, self.thresholds)
        conf = _num(confidence)
        adjusted_conf = None
        if conf == conf:
            # report an "effective" confidence after cross-sensor bonus, capped at 1.0
            bonus = self.conf_cfg.get("cross_sensor_bonus", 0.2) if len(confirmations) >= 2 else 0.0
            adjusted_conf = round(min(1.0, conf + bonus), 3)

        return {
            "score": round(total, 3),
            "risk_level": risk_level,
            "reasons": sorted(set(reasons)),
            "matched_rules": matched,
            "confidence": None if conf != conf else conf,
            "adjusted_confidence": adjusted_conf,
            "confidence_adjustments": adjustments,
        }
