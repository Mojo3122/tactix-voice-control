"""health_monitor.py — plan §21.1, §28, and the Jetson disk constraint (§13).

Reports the mission layer's operational health so the controller and command center can
react before something fails silently. Checks:
  - background executor queue depth / rejection rate (overload signal)
  - upload backlog (pending/failed/dead counts)
  - mission DB reachability
  - free disk space at the storage root (eMMC is tight on the Jetson)

Status levels: "ok" | "degraded" | "unhealthy". Pure inspection — it never blocks and
never does heavy work itself.
"""

from __future__ import annotations

import os
import shutil
import time
from typing import Optional

from . import config_loader


def _utcnow() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class HealthMonitor:
    def __init__(self, profile: Optional[dict] = None, memory=None,
                 executor=None, upload_queue=None,
                 min_free_mb: float = 500.0,
                 queue_warn_ratio: float = 0.7,
                 upload_backlog_warn: int = 20):
        self.profile = profile if profile is not None else config_loader.load_yaml("mission_profile.yaml")
        self.memory = memory
        self.executor = executor
        self.upload_queue = upload_queue
        self.min_free_mb = min_free_mb
        self.queue_warn_ratio = queue_warn_ratio
        self.upload_backlog_warn = upload_backlog_warn
        self.storage_root = config_loader.storage_path(profile=self.profile)

    # ---- individual checks ----
    def check_disk(self) -> dict:
        try:
            target = self.storage_root if os.path.exists(self.storage_root) else os.path.dirname(self.storage_root)
            usage = shutil.disk_usage(target)
            free_mb = usage.free / (1024 * 1024)
            status = "ok" if free_mb >= self.min_free_mb else ("degraded" if free_mb >= self.min_free_mb / 2 else "unhealthy")
            return {"status": status, "free_mb": round(free_mb, 1), "min_free_mb": self.min_free_mb}
        except Exception as e:
            return {"status": "unhealthy", "error": str(e)}

    def check_executor(self) -> dict:
        if not self.executor:
            return {"status": "ok", "note": "no executor attached"}
        s = self.executor.stats()
        depth_ratio = s["queue_depth"] / max(1, s["max_queue"])
        if not s["running"]:
            status = "unhealthy"
        elif depth_ratio >= self.queue_warn_ratio or s["rejected"] > 0:
            status = "degraded"
        else:
            status = "ok"
        return {"status": status, **s, "depth_ratio": round(depth_ratio, 2)}

    def check_uploads(self) -> dict:
        if not self.upload_queue:
            return {"status": "ok", "note": "no upload queue attached"}
        counts = self.upload_queue.status_counts()
        backlog = counts.get("pending", 0) + counts.get("failed", 0)
        dead = counts.get("dead", 0)
        if dead > 0:
            status = "degraded"
        elif backlog >= self.upload_backlog_warn:
            status = "degraded"
        else:
            status = "ok"
        return {"status": status, "counts": counts, "backlog": backlog, "dead": dead}

    def check_db(self) -> dict:
        if not self.memory:
            return {"status": "ok", "note": "no memory attached"}
        try:
            lock = getattr(self.memory, "_lock", None)
            if lock is not None:
                with lock:
                    self.memory._conn.execute("SELECT 1").fetchone()
            else:
                self.memory._conn.execute("SELECT 1").fetchone()
            return {"status": "ok"}
        except Exception as e:
            return {"status": "unhealthy", "error": str(e)}

    # ---- rollup ----
    def report(self) -> dict:
        checks = {
            "disk": self.check_disk(),
            "executor": self.check_executor(),
            "uploads": self.check_uploads(),
            "db": self.check_db(),
        }
        overall = self._rollup([c["status"] for c in checks.values()])
        return {
            "overall": overall,
            "timestamp_utc": _utcnow(),
            "vehicle_id": self.profile.get("mission", {}).get("vehicle_id"),
            "checks": checks,
        }

    @staticmethod
    def _rollup(statuses) -> str:
        if "unhealthy" in statuses:
            return "unhealthy"
        if "degraded" in statuses:
            return "degraded"
        return "ok"
