"""demo_phase1.py — runnable walkthrough of the §14 first three workflows (fake mode).

Run:  python -m tactix_mission.demo_phase1
No hardware, no ROS2, no network. Everything is fake-executed and logged to a temp DB.
"""

import os
import tempfile

from tactix_mission import (
    intent_normalizer as IN,
    tool_registry as TR,
    permission_engine as PE,
    mission_memory as MM,
    risk_scorer as RS,
    summary_generator as SG,
)


def main():
    reg = TR.ToolRegistry()
    eng = PE.PermissionEngine(registry=reg)
    scorer = RS.RiskScorer()
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    mem = MM.MissionMemory(db_path=tmp.name)
    mission_id = "night_patrol_001"

    print("=" * 70)
    print("WORKFLOW 1 — Scan Direction")
    print("=" * 70)
    cmd = "Scan my 2 o'clock"
    intent = IN.normalize(cmd, source="voice")
    print(f"  command : {cmd!r}")
    print(f"  intent  : {intent}")
    dec = eng.check("scan_direction")
    print(f"  permission: {dec.level} ({dec.source})")
    res = reg.execute("scan_direction", intent["parameters"])
    print(f"  executed: {res['status']} -> {res['message']}")
    mem.save_event({"mission_id": mission_id, "source": "voice", "intent": intent["intent"],
                    "tool_name": "scan_direction", "event_json": res})
    mem.append_transcript(mission_id, "tool_execution_completed", res)
    print("  logged to mission_events + transcript ✓")

    print("\n" + "=" * 70)
    print("WORKFLOW 2 — Yellow Event Package")
    print("=" * 70)
    event = {"object_type": "vehicle", "object_color": "white", "zone": "west_gate",
             "zone_type": "sensitive", "after_hours": True, "duration_sec": 96,
             "repeat_seen_count": 3, "time_window_minutes": 10, "confidence": 0.87}
    scored = scorer.score_event(event)
    print(f"  event   : white vehicle, sensitive zone, after-hours, 96s")
    print(f"  scored  : level={scored['risk_level']} score={scored['score']}")
    print(f"  reasons : {scored['reasons']}")
    print(f"  rules   : {scored['matched_rules']}")
    summary = SG.edge_summary(scored, event)
    print(f"  summary : {summary}")
    eid = mem.save_event({"mission_id": mission_id, "risk_level": scored["risk_level"],
                          "score": scored["score"], "reasons": scored["reasons"],
                          "matched_rules": scored["matched_rules"],
                          "confidence": scored["confidence"],
                          "adjusted_confidence": scored["adjusted_confidence"],
                          "event_json": {**event, "edge_summary": summary}})
    print(f"  saved event_id={eid}; queryable as yellow ✓ "
          f"(found {len(mem.events_by_risk(('yellow',)))})")

    print("\n" + "=" * 70)
    print("WORKFLOW 3 — Share Latest Clip (approval-gated)")
    print("=" * 70)
    intent = IN.normalize("send latest clip to command", source="voice")
    print(f"  intent  : {intent['intent']}")
    dec = eng.check("share_latest_clip")
    print(f"  permission: {dec.level} ({dec.source})")
    print(f"  prompt  : {SG.approval_prompt('share_latest_clip')}")
    print("  --> operator says NO: no send, decision logged.")
    mem.append_transcript(mission_id, "tool_permission_checked",
                          {"tool": "share_latest_clip", "decision": dec.level, "approved": False})
    print("  --> operator says YES: now execute.")
    res = reg.execute("share_latest_clip", intent["parameters"])
    print(f"  executed: {res['status']} -> {res['message']}")

    print("\n" + "=" * 70)
    print(f"Mission memory rows: {len(mem.recent_events())} events, "
          f"{len(mem.transcript(mission_id))} transcript entries")
    print("Permission decisions this run:", [f"{d.tool}={d.level}" for d in eng.decisions])
    print("=" * 70)
    mem.close()
    os.unlink(tmp.name)


if __name__ == "__main__":
    main()
