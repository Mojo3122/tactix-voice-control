"""capability_manifest.py — plan §21.1, §22.

Builds a self-describing snapshot of what THIS vehicle/edge node can currently do:
which tools are available (from the registry), their permission levels and execution
classes, which sensor modes exist, the active playbook, and resource budgets.

Why it exists: the command center (and the mission controller itself) needs to reason
about capability without hardcoding it. "Can this unit share clips? Is that auto or
approval-gated? What's its scan latency budget?" — all answered from this manifest.

It is generated from the SAME configs the controller runs on (tool_registry.yaml,
permissions.yaml, mission_profile.yaml), so the manifest can never drift from actual
behaviour. Written to storage/runtime/capability_manifest.json for the MCT to pull.
"""

from __future__ import annotations

import json
import os
import time
from typing import Optional

from . import config_loader
from . import tool_registry as tr
from . import permission_engine as pe


def _utcnow() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class CapabilityManifest:
    def __init__(self, registry=None, permissions=None, profile: Optional[dict] = None):
        self.registry = registry or tr.ToolRegistry()
        self.profile = profile if profile is not None else config_loader.load_yaml("mission_profile.yaml")
        self.permissions = pe.PermissionEngine(permissions=permissions, registry=self.registry)

    def build(self) -> dict:
        mission = self.profile.get("mission", {})
        tools = []
        for name in self.registry.list_tools():
            md = self.registry.metadata(name)
            decision = self.permissions.check(name)
            tools.append({
                "name": name,
                "permission": decision.level,            # resolved, authoritative level
                "exec_class": md.get("exec_class"),
                "type": md.get("type"),
                "blocking": md.get("blocking", False),
                "timeout_ms": md.get("timeout_ms"),
                "available": md.get("type") != "blocked" and decision.level != "blocked",
                "description": md.get("description", ""),
            })

        sensor_modes = sorted((self.profile.get("edge_sources", {})
                               .get("mode_subfolders", {}) or {}).keys()) or ["rgb"]

        return {
            "schema_version": "1.0",
            "generated_utc": _utcnow(),
            "mission_id": mission.get("mission_id"),
            "vehicle_id": mission.get("vehicle_id"),
            "device_id": mission.get("device_id"),
            "active_playbook": mission.get("default_playbook"),
            "sensor_modes": sensor_modes,
            "tool_count": len(tools),
            "tools": tools,
            "permission_summary": self._permission_summary(tools),
            "edge_budget_ms": self.profile.get("edge_budget", {}),
        }

    @staticmethod
    def _permission_summary(tools: list) -> dict:
        summary = {"auto": 0, "approval_required": 0, "blocked": 0}
        for t in tools:
            summary[t["permission"]] = summary.get(t["permission"], 0) + 1
        return summary

    def write(self, path: Optional[str] = None) -> str:
        """Write the manifest to storage/runtime/capability_manifest.json (or given path)."""
        if path is None:
            rel = self.profile.get("paths", {}).get("capability_manifest",
                                                    "runtime/capability_manifest.json")
            path = config_loader.storage_path(rel, profile=self.profile)
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        manifest = self.build()
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(manifest, fh, indent=2, sort_keys=True)
        return path
