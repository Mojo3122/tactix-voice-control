"""real_upload_transport.py — Phase 5 (plan §11.4, §24.2).

Real upload transport for the UploadQueue. Where Phase 2 simulated a send, this triggers
the EXISTING bridge sync (`POST /upload/run`) which rsyncs gallery clips + SQLite DBs +
full_day_logs to the command-center PC (ai1@192.168.0.129). It adds nothing to the bridge.

Because the bridge's rsync worker already scans gallery/ (including the auto-record clips
that evidence packages link to), triggering /upload/run ships the evidence automatically.
This transport therefore signals "flush the sync" rather than uploading one folder — which
matches how your system actually moves data.

Passed to UploadQueue(transport=RealUploadTransport(...)). Returns (ok, error) per the
queue's transport contract.
"""

from __future__ import annotations

from typing import Optional

from . import config_loader

try:
    import requests
    _HAVE_REQUESTS = True
except ImportError:
    _HAVE_REQUESTS = False


class RealUploadTransport:
    def __init__(self, base_url: Optional[str] = None, force: bool = True, timeout: float = 30.0):
        cfg = config_loader.load_yaml("upload_config.yaml").get("upload", {})
        self.base_url = (base_url or cfg.get("bridge_base_url", "http://127.0.0.1:5000")).rstrip("/")
        self.endpoint = cfg.get("bridge_endpoint", "/upload/run")
        self.force = force
        self.timeout = timeout

    def __call__(self, package_path: str) -> tuple:
        if not _HAVE_REQUESTS:
            return False, "python 'requests' not installed"
        url = self.base_url + self.endpoint
        try:
            resp = requests.post(url, json={"force": self.force}, timeout=self.timeout)
        except Exception as e:
            return False, f"upload request failed: {e}"
        if resp.status_code >= 400:
            try:
                msg = resp.json().get("message", resp.text[:200])
            except Exception:
                msg = resp.text[:200]
            return False, f"bridge upload returned {resp.status_code}: {msg}"
        return True, ""
