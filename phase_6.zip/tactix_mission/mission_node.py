"""mission_node.py — Phase 5 (plan §22, §24).

The runtime process that connects the (already-tested) MissionController to the LIVE
system. It is a NEW, SEPARATE ROS2 node — it adds no publishers to your existing nodes
and changes none of your scripts. It only:

  SUBSCRIBES to topics your pipeline already publishes:
    /awareness/auto_record_trigger   (std_msgs/String)  -> detection events (reason strings)
    /tactix/ptz/pan_actual           (std_msgs/Float64) -> telemetry
    /tactix/ptz/tilt_actual          (std_msgs/Float64) -> telemetry
    /tactix/ptz/zoom_actual          (std_msgs/Float64) -> telemetry

  CALLS the bridge over HTTP for tool execution + uploads (existing endpoints only).

Run as its own terminal tab (like your other services):
    python3 -m tactix_mission.mission_node

ROS2 imports are lazy so this module is importable (and unit-testable) on machines
without ROS2. The reason-string -> structured-event conversion uses reason_event_adapter
(Phase 1), so risk scoring needs no pipeline change.
"""

from __future__ import annotations

import threading
import time
from typing import Optional

from . import config_loader
from . import mission_controller as MC
from . import reason_event_adapter as REA
from . import bridge_executor as BE
from . import real_upload_transport as RUT
from . import clip_finder as CF
from . import dashboard_forwarder as DF


class MissionNodeRunner:
    """ROS2-free core so the wiring logic is testable. The ROS2 node (below) calls into
    this. Everything here is plain Python.
    """
    def __init__(self, controller: Optional[MC.MissionController] = None,
                 profile: Optional[dict] = None):
        self.profile = profile if profile is not None else config_loader.load_yaml("mission_profile.yaml")
        if controller is None:
            executor = BE.BridgeExecutor(profile=self.profile)
            transport = RUT.RealUploadTransport()
            _clip_finder = CF.ClipFinder(profile=self.profile)
            _forwarder = DF.DashboardForwarder(profile=self.profile)
            controller = MC.MissionController(profile=self.profile,
                                              tool_executor=executor,
                                              upload_transport=transport,
                                              approval_callback=self._default_approval,
                                              clip_stability_waiter=_clip_finder.wait_until_stable,
                                              dashboard_forwarder=_forwarder)
        self.controller = controller
        # latest telemetry (filled by PTZ subscriptions)
        self._ptz = {"pan": None, "tilt": None, "zoom": None}
        self._last_trigger = ""
        self._last_trigger_time = 0.0
        self._dedup_window_s = 2.0  # ignore identical trigger strings within 2s

        # Phase 5.1: per-reason cooldown + clip linking
        self._cooldown_s = float(self.profile.get("event_cooldown_seconds", 8))
        self._last_packaged_at = {}   # reason_token -> epoch of last packaged event
        self.clip_finder = CF.ClipFinder(profile=self.profile)

    # ---- approval policy for the live node ----
    def _default_approval(self, tool, params, prompt) -> bool:
        # Live default: do NOT auto-approve approval-gated tools. A real operator UI hook
        # would override this. Fail-safe: returns False so nothing sensitive auto-fires.
        return False

    # ---- detection event from /awareness/auto_record_trigger ----
    def on_auto_record_trigger(self, reason_string: str):
        now = time.time()
        # de-duplicate repeated identical triggers (the pipeline can re-fire)
        if (reason_string == self._last_trigger and
                now - self._last_trigger_time < self._dedup_window_s):
            return []
        self._last_trigger = reason_string
        self._last_trigger_time = now

        events = REA.reason_string_to_events(reason_string, profile=self.profile)
        results = []
        for ev in events:
            token = ev.get("source_reason_token", ev.get("object_type", "event"))

            # per-reason cooldown: skip packaging a fresh near-identical event too soon.
            # We still SCORE + LOG it (so counts stay accurate), but suppress the heavy
            # evidence package + upload when within the cooldown window for this reason.
            last = self._last_packaged_at.get(token, 0.0)
            in_cooldown = self._cooldown_s > 0 and (now - last) < self._cooldown_s

            # attach current telemetry as context (ptz)
            ev.setdefault("ptz", dict(self._ptz))

            # find the matching auto-record clip (newest fresh file for this sensor)
            clip_path = ""
            if not in_cooldown:
                clip_path = self.clip_finder.newest_fresh_clip(ev.get("sensor", ""), now=now) or ""

            res = self.controller.handle_detection(
                ev, clip_path=clip_path, suppress_packaging=in_cooldown)
            res["cooldown_suppressed"] = in_cooldown
            res["clip_linked"] = bool(clip_path)
            results.append(res)

            # record the time we actually packaged (only when not suppressed and elevated)
            if not in_cooldown and res.get("packaged"):
                self._last_packaged_at[token] = now
        return results

    # ---- telemetry from /tactix/ptz/*_actual ----
    def on_pan(self, v: float):
        self._ptz["pan"] = float(v)

    def on_tilt(self, v: float):
        self._ptz["tilt"] = float(v)

    def on_zoom(self, v: float):
        self._ptz["zoom"] = float(v)

    # ---- operator command entrypoint (e.g. from a future voice/UI hook) ----
    def on_command(self, text: str, source: str = "voice"):
        return self.controller.handle_command(text, source=source)

    # ---- periodic upload cadence ----
    def tick_uploads(self):
        return self.controller.process_uploads_once()

    def shutdown(self):
        self.controller.shutdown()


# ============================================================================
# ROS2 node — only imported/constructed when actually run on the Jetson.
# ============================================================================
def main():
    import rclpy
    from rclpy.node import Node
    from std_msgs.msg import String, Float64

    class MissionNode(Node):
        def __init__(self):
            super().__init__("tactix_mission_controller")
            self.runner = MissionNodeRunner()
            # SUBSCRIBE ONLY — no publishers added to the graph
            self.create_subscription(String, "/awareness/auto_record_trigger",
                                     self._cb_trigger, 10)
            self.create_subscription(Float64, "/tactix/ptz/pan_actual",
                                     lambda m: self.runner.on_pan(m.data), 10)
            self.create_subscription(Float64, "/tactix/ptz/tilt_actual",
                                     lambda m: self.runner.on_tilt(m.data), 10)
            self.create_subscription(Float64, "/tactix/ptz/zoom_actual",
                                     lambda m: self.runner.on_zoom(m.data), 10)
            # upload cadence timer (every 30s; the bridge's own SSID gate still applies)
            self.create_timer(30.0, self._cb_uploads)
            self.get_logger().info(
                "✅ TACTIX mission controller node up — subscribing to "
                "/awareness/auto_record_trigger and /tactix/ptz/*_actual (no publishers).")
            # write a fresh capability manifest for the command center to read
            try:
                path = self.runner.controller.write_capability_manifest()
                self.get_logger().info(f"capability manifest written: {path}")
            except Exception as e:
                self.get_logger().warn(f"capability manifest write failed: {e}")

        def _cb_trigger(self, msg):
            try:
                results = self.runner.on_auto_record_trigger(msg.data)
                for r in results:
                    self.get_logger().info(
                        f"[mission] {r.get('risk_level','?').upper()} "
                        f"score={r.get('score')} packaged={r.get('packaged')}")
            except Exception as e:
                self.get_logger().error(f"trigger handling failed: {e}")

        def _cb_uploads(self):
            try:
                self.runner.tick_uploads()
            except Exception as e:
                self.get_logger().warn(f"upload tick failed: {e}")

        def destroy_node(self):
            try:
                self.runner.shutdown()
            finally:
                super().destroy_node()

    rclpy.init()
    node = MissionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
