"""config_loader.py — shared YAML/config access for the mission package.

Resolves paths relative to the package root so the whole tree can be relocated by
editing mission_profile.yaml's storage_root. No external deps beyond PyYAML.
"""

from __future__ import annotations

import os
import functools

try:
    import yaml
except ImportError as e:  # pragma: no cover - dependency guard
    raise ImportError(
        "PyYAML is required for tactix_mission. Install with: pip install pyyaml"
    ) from e


# Package root = directory that CONTAINS the `tactix_mission/` package and `config/`.
# __file__ is .../tactix_mission/tactix_mission/config_loader.py
_PKG_DIR = os.path.dirname(os.path.abspath(__file__))           # .../tactix_mission (inner)
_ROOT_DIR = os.path.dirname(_PKG_DIR)                            # .../tactix_mission (outer)
_CONFIG_DIR = os.path.join(_ROOT_DIR, "config")


def config_dir() -> str:
    """Absolute path to the config/ directory."""
    return _CONFIG_DIR


def root_dir() -> str:
    """Absolute path to the package root (parent of config/ and storage/)."""
    return _ROOT_DIR


def load_yaml(name: str) -> dict:
    """Load a YAML file from config/ by filename, e.g. 'risk_rules.yaml'."""
    path = os.path.join(_CONFIG_DIR, name)
    if not os.path.exists(path):
        raise FileNotFoundError(f"config file not found: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    if not isinstance(data, dict):
        raise ValueError(f"config {name} must be a mapping at top level, got {type(data)}")
    return data


@functools.lru_cache(maxsize=None)
def load_yaml_cached(name: str) -> dict:
    """Cached variant for hot paths (configs are read-only at runtime)."""
    return load_yaml(name)


def storage_path(*parts: str, profile: dict | None = None) -> str:
    """Resolve a path under the configured storage_root.

    storage_root from mission_profile.yaml may be relative (resolved against the
    package root) or absolute (used as-is).
    """
    prof = profile if profile is not None else load_yaml_cached("mission_profile.yaml")
    paths = prof.get("paths", {})
    storage_root = paths.get("storage_root", "storage")
    if not os.path.isabs(storage_root):
        storage_root = os.path.join(_ROOT_DIR, storage_root)
    return os.path.join(storage_root, *parts)
