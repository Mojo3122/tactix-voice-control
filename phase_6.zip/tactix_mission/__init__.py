"""TACTIX Mission Controller — lightweight edge mission-control layer.

This package sits ON TOP of the existing TACTIX ROS2/Hailo/PTZ/voice pipeline and
coordinates it. It does NOT run heavy inference, does NOT process raw frames, and does
NOT modify the existing scripts. See tactix_plan_v3 for the full design.

Phase 1 scope (pure logic, no ROS2/Flask, fully unit-testable):
    intent_normalizer, tool_registry, permission_engine, mission_memory,
    risk_scorer, summary_generator.
"""

__version__ = "0.6.0-phase6"
