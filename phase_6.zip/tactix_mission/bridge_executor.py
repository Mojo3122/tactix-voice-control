"""bridge_executor.py — Phase 5 (plan §22, §24.1).

The REAL tool executor. Where Phase 1-4 faked tool calls, this performs the actual HTTP
request against the EXISTING tactix bridge endpoints (the same ones the UI already calls).
It is passed to MissionController(tool_executor=...) — the controller logic is unchanged.

CRITICAL: this adds NO new endpoints to the bridge and changes none of its logic. Every
endpoint and body below already exists in tactix_ptz_http_bridge31_*.py:

  scan_360        -> POST /scan                {}
  scan_direction  -> POST /set_pan             {"value": <pan_degrees>}
  switch_rgb      -> POST /set_video_mode       {"mode": "rgb"}
  switch_thermal  -> POST /set_video_mode       {"mode": "thermal"}
  track_object    -> POST /voice_command        {"command": "...", "status": "processing"}
  stop_tracking   -> POST /stop_tracking        {}
  save_clip       -> POST /record               {}
  upload_package  -> POST /upload/run           {"force": <bool>}
  share_latest_clip -> POST /upload/run         {"force": true}   (reuses the rsync sync)

`requests` is the only dependency; if it is missing the executor degrades to a clear
error result instead of crashing the controller.
"""

from __future__ import annotations

from typing import Optional

from . import config_loader

try:
    import requests
    _HAVE_REQUESTS = True
except ImportError:
    _HAVE_REQUESTS = False


class BridgeExecutor:
    def __init__(self, base_url: Optional[str] = None, profile: Optional[dict] = None,
                 timeout: float = 5.0):
        reg = config_loader.load_yaml("tool_registry.yaml")
        self.base_url = (base_url or reg.get("base_url", "http://127.0.0.1:5000")).rstrip("/")
        self.profile = profile if profile is not None else config_loader.load_yaml("mission_profile.yaml")
        self.timeout = timeout
        self.clock_to_pan = self.profile.get("clock_to_pan_deg", {})

    # the callable the controller/registry expects: executor(name, params, spec) -> dict
    def __call__(self, name: str, parameters: dict, spec: dict) -> dict:
        if not _HAVE_REQUESTS:
            return self._err(name, "python 'requests' not installed (pip install requests)")
        try:
            method, path, body = self._map(name, parameters, spec)
        except Exception as e:
            return self._err(name, f"could not map tool to endpoint: {e}")
        if path is None:
            return self._err(name, f"tool '{name}' has no real endpoint mapping")

        url = self.base_url + path
        try:
            if method == "POST":
                resp = requests.post(url, json=body, timeout=self.timeout)
            else:
                resp = requests.get(url, timeout=self.timeout)
        except Exception as e:
            return self._err(name, f"request failed: {e}", url=url)

        ok = resp.status_code < 400
        try:
            payload = resp.json()
        except Exception:
            payload = {"raw": resp.text[:200]}
        return {
            "tool": name,
            "status": "success" if ok else "error",
            "http_status": resp.status_code,
            "url": url,
            "request_body": body,
            "response": payload,
            "message": payload.get("message", payload.get("error", "")) if isinstance(payload, dict) else "",
            "fake": False,
        }

    def _map(self, name: str, params: dict, spec: dict):
        """Return (method, path, body) for a tool. Uses the registry's declared endpoint
        where the body is trivial, and special-cases the few that need a shaped body.
        """
        params = params or {}
        if name == "scan_360":
            return "POST", "/scan", {}
        if name == "scan_direction":
            direction = params.get("direction", "12_oclock")
            pan_deg = float(self.clock_to_pan.get(direction, 0))
            return "POST", "/set_pan", {"value": pan_deg}
        if name == "switch_rgb":
            return "POST", "/set_video_mode", {"mode": "rgb"}
        if name == "switch_thermal":
            return "POST", "/set_video_mode", {"mode": "thermal"}
        if name == "track_object":
            obj = params.get("object_type", "target")
            idx = params.get("index")
            cmd = f"track {obj}" + (f" {idx}" if idx else "")
            return "POST", "/voice_command", {"command": cmd, "status": "processing"}
        if name == "stop_tracking":
            return "POST", "/stop_tracking", {}
        if name == "save_clip":
            return "POST", "/record", {}
        if name in ("upload_package",):
            return "POST", "/upload/run", {"force": bool(params.get("force", False))}
        if name == "share_latest_clip":
            # operator-approved share -> force past the home-WiFi gate, reuse rsync sync
            return "POST", "/upload/run", {"force": True}
        # fall back to the registry's declared endpoint with an empty body
        endpoint = spec.get("endpoint")
        method = (spec.get("method") or "POST").upper()
        return method, endpoint, {}

    @staticmethod
    def _err(name, msg, url=None):
        return {"tool": name, "status": "error", "message": msg, "url": url, "fake": False}
