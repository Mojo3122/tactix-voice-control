# Phase 5 — Integrating with the live system (Jetson)

This is the first phase that connects the mission controller to your running system.
It changes NONE of your five scripts. The controller runs as its own process and only:
  - calls bridge endpoints that already exist (over HTTP), and
  - subscribes to ROS2 topics your pipeline already publishes.

## What it touches in your system

NOTHING is modified. The mission node is a NEW, SEPARATE ROS2 node. Specifically:

It SUBSCRIBES to (read-only; your nodes are unchanged):
  /awareness/auto_record_trigger   std_msgs/String   (detection reason strings)
  /tactix/ptz/pan_actual           std_msgs/Float64  (telemetry)
  /tactix/ptz/tilt_actual          std_msgs/Float64  (telemetry)
  /tactix/ptz/zoom_actual          std_msgs/Float64  (telemetry)

It CALLS these existing bridge endpoints over HTTP (no new endpoints added):
  scan_360        -> POST /scan
  scan_direction  -> POST /set_pan          {"value": <deg>}
  switch_rgb      -> POST /set_video_mode    {"mode": "rgb"}
  switch_thermal  -> POST /set_video_mode    {"mode": "thermal"}
  track_object    -> POST /voice_command     {"command": "...", "status": "processing"}
  stop_tracking   -> POST /stop_tracking
  save_clip       -> POST /record
  upload_package / share_latest_clip -> POST /upload/run   {"force": ...}

Evidence + DB + logs reach the command center through your EXISTING rsync sync
(/upload/run -> ai1@192.168.0.129). The mission layer just triggers that sync; it does not
invent a new transport. Live Valkey alerts (escalate_alert) are intentionally deferred to
Phase 6, where the dashboard/Valkey code lives.

## Prerequisites

```bash
pip install -r requirements.txt --break-system-packages   # adds 'requests'
```

## How to run it

The mission node is just one more terminal tab, exactly like your other services. Start
your normal stack first (run_tactix_all.sh), THEN start the mission node:

```bash
cd /home/tds-jetson3/cam/workflow_29_04_2026/<your_package_folder>
python3 -m tactix_mission.mission_node
```

You should see:
  ✅ TACTIX mission controller node up — subscribing to /awareness/auto_record_trigger ...

When the pipeline fires a weapon/crouching trigger, the node logs the scored result and
(for yellow/red) builds an evidence package in storage/evidence/ and queues an upload.

## Optional: add it to run_tactix_all.sh

Append ONE tab at the end of the launch section (after the pipeline is up). This is the
only change to your launch script, and it is additive:

```bash
gnome-terminal --tab -- bash -c "source ~/.bashrc; \
  cd /home/tds-jetson3/cam/workflow_29_04_2026/<your_package_folder>; \
  python3 -m tactix_mission.mission_node; exec bash"
```

Put it AFTER the full_pipeline tab so the topics exist when the node subscribes.

## Safety / rollback

- The node is a separate process. If you don't start it, your system behaves exactly as
  before. If it crashes, your live system is unaffected (it only reads topics + calls the
  same HTTP API the UI uses).
- Approval-gated tools (share_latest_clip, escalate_alert) do NOT auto-fire: the live
  node's default approval callback returns False. Wire a real operator prompt later.
- To stop using it: close its tab (or remove the line from run_tactix_all.sh). Nothing
  else to undo.

## Verifying without the live system

```bash
python -m unittest tactix_mission.tests.test_phase5 -v   # mock-bridge tests
python -m tactix_mission.demo_phase5                     # mock-bridge demo
```

These prove the wiring (endpoints, bodies, detection flow) without ROS2 or the real bridge.
