# TACTIX Mission Controller — Phases 0 & 1

Lightweight edge mission-control layer that sits **on top of** the existing TACTIX
ROS2 / Hailo / PTZ / voice pipeline and coordinates it. It does **not** run heavy
inference, does **not** process raw frames, and **does not modify any existing script**.
See `tactix_plan_v3` for the full design.

## What is in this delivery

**Phase 0 — scaffolding**
```
tactix_mission/
  config/
    tool_registry.yaml      # §7  — maps to your REAL bridge endpoints/topics
    permissions.yaml        # §8  — auto/approval_required/blocked + hard safety blocks
    risk_rules.yaml         # §9  — data-driven rules (no zone names in code)
    mission_profile.yaml    # §23 — identity, paths, edge defaults (relocate here)
  storage/                  # mission_events.db + evidence/summaries/upload/audit/runtime
```

**Phase 1 — pure-logic core (no ROS2/Flask, fully unit-testable)**
```
tactix_mission/tactix_mission/
  config_loader.py          # shared YAML/path access
  intent_normalizer.py      # Ticket 1 — §6  command string -> intent JSON
  tool_registry.py          # Ticket 2 — §7  load tools, validate, FAKE-execute
  permission_engine.py      # Ticket 3 — §8  auto/approval/blocked + hard blocks
  mission_memory.py         # Ticket 4 — §10 SQLite events/tracks/summaries/queue/transcript
  risk_scorer.py            # Tickets 5/13/14 — §9/§33 data-driven, confidence-aware
  summary_generator.py      # Ticket 8 — §5.9 template summaries + approval prompts
  reason_event_adapter.py   # v1 bridge: pipeline reason strings -> scorer events
  demo_phase1.py            # runnable §14 three-workflow walkthrough
  tests/test_phase1.py      # 37 tests: §16.1 units + §14 integration + §9.4 acceptance
```

## Run it

```bash
pip install -r requirements.txt          # just PyYAML
python -m unittest tactix_mission.tests.test_phase1 -v      # 37 tests
python -m tactix_mission.demo_phase1                        # see the 3 workflows
```

Run both from the **outer** `tactix_mission/` directory (the one containing `config/`).

## Relocating the package

Everything path-related is in `config/mission_profile.yaml`. To move onto the Jetson,
set `paths.storage_root` to e.g.
`/home/tds-jetson3/cam/workflow_29_04_2026/tactix_mission/storage`. No code change.

## Important design notes

- **Nothing here touches your existing scripts.** Tools run in FAKE mode in Phase 1.
  The registry already records the real endpoints (`/scan`, `/set_video_mode`, `/record`,
  `/stop_tracking`, `/upload/run`, …) and topics so Phase 5 only swaps the executor.
- **`share_latest_clip` / `escalate_alert`** point at endpoints your bridge does **not**
  have yet. Those are added **additively** in Phase 5 — never as rewrites.
- **v1 risk input** is the pipeline's existing `/awareness/auto_record_trigger` reason
  strings, converted by `reason_event_adapter.py` with a configurable nominal confidence
  (`mission_profile.yaml: reason_string_confidence`). No pipeline change required. If you
  later add real per-detection confidence to that payload, it's an additive change and
  the adapter is simply bypassed.
- **No hardcoded zone names / weights** in `risk_scorer.py` (enforced by a test).

## Phase 2 — evidence packaging + integrity + upload queue

Turns a scored yellow/red event into a sealed, verifiable evidence package and queues it
for upload. Still standalone: no ROS2, no network, no change to your existing scripts.

```
config/upload_config.yaml          # upload retry/backoff + optional signing settings
tactix_mission/
  evidence_packager.py    # Ticket 6      — §11   build the evidence/<event_id>/ folder
  evidence_integrity.py   # Tickets 15/16 — §11.4 SHA-256 hashing, manifest hash, signing, verify
  upload_queue.py         # Ticket 7      — §24.2 queue + retry/backoff + status tracking
  demo_phase2.py          # runnable end-to-end walkthrough
  tests/test_phase2.py    # 14 tests: packaging, integrity, tamper detection, queue
```

What a package contains (under `storage/evidence/<event_id>/`):
`clip.mp4` (LINKED from your existing gallery auto-record clip — never moved or deleted),
`event.json`, `telemetry.json`, `edge_summary.txt`, `file_hashes.json` (SHA-256 of every
file), `upload_manifest.json` (includes `manifest_sha256` + signature descriptor), and
`manifest.sig` only if signing is enabled.

Run it:
```bash
python -m unittest tactix_mission.tests.test_phase2 -v     # 14 tests
python -m tactix_mission.demo_phase2                       # builds a real package + verifies
```

Key safety properties (all enforced by tests):
- A missing clip does NOT crash packaging — the rest of the package is still built.
- The original gallery clip is hardlinked in (cheap) and never deleted (§11.4).
- The manifest hash is computed AFTER file hashes are written.
- Failed uploads retry with exponential backoff and are never silently dropped.
- A successful upload does NOT delete the local package (unless explicitly configured).
- `verify_package()` recomputes hashes and flags any tampering — this is exactly what the
  command center (MCT) will run before trusting a SITREP.

Signing is OFF by default (hashing is always on). To enable later, set `signing.enabled:
true` and a key path in `upload_config.yaml`; signing uses PyNaCl only if installed, and
degrades gracefully (still hashes) if it is not.

## Phase 3 — runtime infrastructure

The plumbing that lets the controller run safely on the Jetson without ever hurting the
camera/inference loop. Still standalone: no ROS2, no network, no change to your scripts.

```
config/playbooks/<id>.yaml         # site context: night window, sensitive/gate zones
tactix_mission/
  capability_manifest.py      # §21.1 — self-describing snapshot of what this unit can do
  mission_context_builder.py  # §23   — derives after_hours / zone_type / recent history
  bounded_async_executor.py   # §24.2 — runs background work OFF the realtime path, bounded queue
  health_monitor.py           # §28   — disk / executor / upload / DB health (ok/degraded/unhealthy)
  demo_phase3.py              # runnable walkthrough
  tests/test_phase3.py        # 18 tests
```

What each one is for, plainly:
- **capability_manifest** — a JSON snapshot of every tool, its resolved permission, and
  sensor modes, generated from the SAME configs the controller runs on (so it can't drift).
  The command center reads it to know what this unit can be asked to do.
- **mission_context_builder** — turns the bare clock + playbook into context: it answers
  "is it after hours?", "is this zone sensitive?", "have we seen this track before?". This
  is what makes risk scoring contextual instead of hardcoded.
- **bounded_async_executor** — a small thread pool with a BOUNDED queue. Background work
  (packaging, hashing, uploads) is submitted here and runs off-thread; `submit()` returns
  in microseconds so your realtime loop is never blocked. When the queue is full, work is
  rejected (backpressure) rather than piling up and starving the Jetson.
- **health_monitor** — reports ok/degraded/unhealthy across disk (eMMC is tight),
  executor backlog, upload backlog, and DB reachability.

Run it:
```bash
python -m unittest tactix_mission.tests.test_phase3 -v     # 18 tests
python -m tactix_mission.demo_phase3                       # shows submit() not blocking
```

## Phase 4 — the mission controller (everything wired together)

One object, `MissionController`, that runs the whole flow. Still standalone: tool calls
are FAKE, uploads are FAKE, nothing touches ROS2/Flask or your existing scripts.

```
tactix_mission/
  mission_controller.py   # §4/§20 — orchestrates all phases into two flows
  demo_phase4.py          # runnable end-to-end patrol
  tests/test_phase4.py    # 17 tests incl. §29 PARITY tests
```

Two flows:
- `handle_command(text, source)` — normalize → permission check → (approval gate) →
  execute via registry → log. Auto tools run; approval-required tools wait for an
  approval callback (fail-safe: no callback = not executed); blocked tools are refused.
- `handle_detection(event)` — enrich with context → risk score → log → if yellow/red,
  package evidence + queue upload **on the background executor** (caller never blocks) →
  edge summary.

PARITY tests (§29) prove the wired controller makes the SAME decisions (intent,
permission level, risk level) as calling the individual modules directly — so wiring
them together didn't change any behaviour.

Phase 5 readiness: the controller takes an injectable `tool_executor` and
`upload_transport`. Passing real adapters (HTTP to the bridge, real rsync) is all Phase 5
needs — the controller logic here does not change. A test proves an injected executor is
used and routed to the right endpoint (`scan_360 -> /scan`).

Run it:
```bash
python -m unittest tactix_mission.tests.test_phase4 -v     # 17 tests
python -m tactix_mission.demo_phase4                       # full patrol end-to-end
```

## Phase 5 — live integration (first phase that connects to the real system)

Connects the controller to your running system WITHOUT changing any of your five scripts.
The controller runs as its own process: it calls existing bridge endpoints over HTTP and
subscribes to ROS2 topics your pipeline already publishes. Full details + run instructions
are in `PHASE5_INTEGRATION.md`.

```
tactix_mission/
  bridge_executor.py        # real tool execution -> existing bridge endpoints (HTTP)
  real_upload_transport.py  # evidence upload -> existing POST /upload/run (rsync sync)
  mission_node.py           # NEW ROS2 node: subscribes to existing topics, runs controller
  demo_phase5.py            # runnable demo against a MOCK bridge (no real system needed)
  tests/test_phase5.py      # 13 tests via a mock bridge server
PHASE5_INTEGRATION.md       # how to run on the Jetson + the one optional launch line
```

Nothing of yours is modified. The node SUBSCRIBES (read-only) to
`/awareness/auto_record_trigger` and `/tactix/ptz/*_actual`, and CALLS existing endpoints
(`/scan`, `/set_pan`, `/set_video_mode`, `/voice_command`, `/stop_tracking`, `/record`,
`/upload/run`). Evidence/DB/logs reach the command center through your EXISTING rsync sync.
Live Valkey alerts (`escalate_alert`) are deferred to Phase 6 where that code lives.

Run on the Jetson (after your normal stack is up):
```bash
pip install -r requirements.txt --break-system-packages
python3 -m tactix_mission.mission_node
```

Verify anywhere (no ROS2 / no real bridge needed):
```bash
python -m unittest tactix_mission.tests.test_phase5 -v
python -m tactix_mission.demo_phase5
```

### v0.5.1 fix — concurrent-write safety (found in first live run)
The first live run surfaced a SQLite threading bug: the mission DB was written from the
main ROS2 thread AND from background packaging threads at the same time, causing
`cannot commit - no transaction is active` / `not an error` under rapid detections.
Fixed by serializing all DB access with a re-entrant lock and using atomic
`with conn:` transactions (plus a 30s busy_timeout). A 120-thread concurrency regression
test now guards this. No behaviour or schema changed.

### v0.5.2 — Phase 5.1 tuning (clips in packages + per-reason cooldown)
From the first clean live run, two improvements (both additive, config-driven, no change
to your five scripts):
- **Clips now linked into packages.** The mission node finds the newest fresh clip in the
  matching `gallery/<mode>/auto-record/` folder (the bridge already writes it there) and
  links it into the evidence package as `clip.mp4`. `clip_finder.py` reads files on disk —
  no bridge coupling. A freshness window (`clip_link.freshness_seconds`) avoids attaching
  stale clips.
- **Per-reason cooldown** (`event_cooldown_seconds`, default 8s, mirrors the bridge's
  auto-record cooldown). The same repeated detection (e.g. a crouching person re-firing
  every ~2s) is still scored and logged, but only packaged once per cooldown window — so
  you no longer get dozens of near-identical packages filling the eMMC. Different reasons
  (weapon vs crouching) cool down independently. Set to 0 to disable.

Both are tunable in `config/mission_profile.yaml`. Guarded by `tests/test_phase5_1.py`.

### v0.5.3 — Phase 5.2 fix (clip hash matched the FINAL clip)
The first 5.1 live run produced a clip whose recorded SHA-256 was the hash of *empty
bytes* (`e3b0c442…b855`) even though the file later held real video. Cause: the bridge
records a ~5s clip with ffmpeg; the mission node was hashing it while it was still being
written (0 bytes). Fixed by waiting for the clip's size to stabilize (non-empty, unchanged
for `clip_link.stability_quiet_seconds`, up to `stability_wait_seconds`) on the BACKGROUND
thread before hashing. If a clip never stabilizes, it is omitted rather than sealed with a
mismatched hash. Verified by reproducing the empty-then-growing scenario: the recorded hash
now matches the final clip. Tunable in `config/mission_profile.yaml`.

## Phase 6 — Command-center integration

Connects the edge controller to your existing TactixGlobalMCT dashboard. Both pieces are
additive — nothing in the dashboard or the five Jetson scripts changes. Full steps in
`PHASE6_INTEGRATION.md`.

Key finding: the dashboard's existing `POST /api/events` already dedupes, stores in
TimescaleDB, publishes the live Valkey alert, pushes over WebSocket, inserts into the AGE
graph, and escalates posture. Phase 6 reuses all of it.

```
tactix_mission/
  dashboard_forwarder.py   # Piece A — POSTs elevated events to the dashboard /api/events
  tests/test_phase6.py     # 5 tests (mock dashboard)
evidence_receiver.js       # Piece B — dashboard-side Express router: receives + RE-VERIFIES
                           #   SHA-256 seals of rsync'd packages; GET /api/evidence
PHASE6_INTEGRATION.md      # how to enable A (one YAML flag) and mount B (two lines in index.js)
```

- **Piece A** (edge): set `dashboard_forward.enabled: true` + the PC's IP in
  `mission_profile.yaml`; the mission node then forwards yellow/red events live. Runs on
  the background executor, best-effort (dashboard is a live mirror, not the record).
- **Piece B** (dashboard): drop `evidence_receiver.js` into `server/`, mount it with two
  lines next to `report_llm` in `index.js`, and point `EVIDENCE_DIR` at the rsync target.
  It re-checks every package's hashes — the receiving end of the integrity chain (sealed
  in Python on the edge, verified in Node at the command center; tamper detection proven).

The full loop: detection → score → (forward live alert) + (package + rsync) → re-verify on
arrival → operator sees the alert instantly and pulls the verified clip moments later.

## Status

Phases 0–6 built. 118 tests passing. Edge side (0–5.2) running live on the Jetson.
Phase 6 Piece B (evidence_receiver.js) verified against real packages incl. tamper detection.
